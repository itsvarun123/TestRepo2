# Databricks notebook source
searchservice_url = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-url")
searchservice_apiKey = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-apikey")

COG_SERVICES_NAME= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cog-service-name")  
COG_SERVICES_KEY= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cog-service-key")    
#COG_SERVICE_ENDPOINT= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-url")  
OPENAI_SERVICE_NAME= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "openai-service-name") 
OpenAI_Service_Key= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "openai-service-key")   
ApplicationId= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "applicationid")   

datasource_name = "datasource-genai-sp-a695-vector"
skillset_name = "skillset-genai-sp-a695-vector"
index_name ="index-genai-sp-a695-vector"   
indexer_name = "indexer-genai-sp-a695-vector"

AZURE_SEARCH_ENDPOINT=f"{searchservice_url}"
AZURE_SEARCH_KEY=f"{searchservice_apiKey}"
AZURE_SEARCH_API_VERSION="2023-10-01-Preview"
headers = {'Content-Type': 'application/json','api-key': AZURE_SEARCH_KEY}
params = {'api-version': AZURE_SEARCH_API_VERSION}

##################
print(searchservice_url)
url = f"{searchservice_url}/datasources?api-version=2023-10-01-Preview"   # 2023-07-01-Preview
print(url)

api_key = f'{searchservice_apiKey}'
print(api_key)

#credentials = f"{cosdb_connString}"
#print(credentials)

datasrc_name= f"{datasource_name}"
print(datasrc_name)
print(skillset_name)
ind_name= f"{index_name}"
print(ind_name)
indexer_name= f"{indexer_name}"
print(indexer_name)

print (headers)
print(params)

import requests
import json
import os

# COMMAND ----------

# MAGIC %md # Drop Cosmos Index , datasource ,Skillset, Indexer in Azure Search Service

# COMMAND ----------

import requests

# Replace these placeholders with your actual values
searchservice_url = f"{searchservice_url}"
data_source_name=f"{datasource_name}"
skillset_name=f"{skillset_name}"
index_name=f"{index_name}"
indexer_name = f"{indexer_name}"
api_key = f'{searchservice_apiKey}'

headers = {
    'Content-Type': 'application/json',
    'api-key': f'{searchservice_apiKey}'
}

url_datasource = f"{searchservice_url}/datasources/{data_source_name}?api-version=2023-10-01-Preview" 
url_skillset = f"{searchservice_url}/skillsets/{skillset_name}?api-version=2023-10-01-Preview" 
url_index = f"{searchservice_url}/indexes/{index_name}?api-version=2023-10-01-Preview" 
url_indexer = f"{searchservice_url}/indexers/{indexer_name}?api-version=2023-10-01-Preview"

response_datasource = requests.delete(url_datasource, headers=headers)
response_skillset = requests.delete(url_skillset, headers=headers)
response_index = requests.delete(url_index, headers=headers)
response_indexer = requests.delete(url_indexer, headers=headers)

# if response.status_code == 202:
#     print(f"Indexer '{data_source_name}' Deleted Succesfully.")
# else:
#     print(f"Failed to delete indexer '{data_source_name}'. Status code: {response.status_code}, Error: {response.text}")

# COMMAND ----------

import requests
import json
#url = "https://search-ai-platform-q-1.search.windows.nett/datasources?api-version=2020-06-30-Preview" 
url=f"{searchservice_url}/datasources?api-version=2023-10-01-Preview"    #  2020-06-30-Preview  2023-07-01-Preview
payload = json.dumps({
  "name": datasource_name,
  "type": "sharepoint",
  "credentials": {   
    "connectionString": f"SharepointOnlineEndpoint=https://kimberlyclark.sharepoint.com/sites/A695;ApplicationId={ApplicationId}"
  },
  "container": {
    "name": "useQuery",
    "query" : "includeLibrary=https://kimberlyclark.sharepoint.com/teams/A695/_layouts/15/viewlsts.aspx"
  }
})
headers = {
  'Content-Type': 'application/json',
  'api-key': f'{searchservice_apiKey}'
}
response = requests.request("POST", url, headers=headers, data=payload)

print(response.text)


# COMMAND ----------

# Create an index
# Queries operate over the searchable fields and filterable fields in the index
index_payload = {
    "name": index_name,
    "fields": [
        {"name": "id", "type": "Edm.String", "key": "true", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false","analyzer":"keyword"},
        {"name": "title", "type": "Edm.String", "searchable": "true", "retrievable": "true", "facetable": "false", "filterable": "true", "sortable": "false"},
        {"name": "content", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false"},
        {"name": "chunk","type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        #{"name": "language", "type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "true", "filterable": "true", "facetable": "true"},
        {"name": "name", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "location", "type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "vectorized", "type": "Edm.Boolean", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "images_text", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        #{"name": "keyPhrases", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "true"},
        #{"name": "persons", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        #{"name": "urls", "type": "Collection(Edm.String)", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        #{"name": "organizations", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "true"},
        #{"name": "emails", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "false"},
        {"name": "chunkVector", "type": "Collection(Edm.Single)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false","dimensions":1536,"vectorSearchProfile":"myHnswProfile"},
        
    ],
    "semantic": {
      "configurations": [
        {
          "name": "my-semantic-config",
          "prioritizedFields": {
            "titleField": 
                {
                    "fieldName": "title"
                },
            "prioritizedContentFields": [
                {
                    "fieldName": "content"
                }
                ]
          }
        }
      ]
    },
  "vectorSearch": {
    "algorithms": [
      {
        "name": "myHnsw",
        "kind": "hnsw",
        "hnswParameters": {
          "metric": "cosine",
          "m": 4,
          "efConstruction": 400,
          "efSearch": 100
        },
        "exhaustiveKnnParameters": None
      },
      {
        "name": "myExhaustiveKnn",
        "kind": "exhaustiveKnn",
        "hnswParameters": None,
        "exhaustiveKnnParameters": {
          "metric": "cosine"
        }
      }
    ],
    "profiles": [
      {
        "name": "myHnswProfile",
        "algorithm": "myHnsw",
        "vectorizer": "myOpenAI"
      },
      {
        "name": "myExhaustiveKnnProfile",
        "algorithm": "myExhaustiveKnn",
        "vectorizer": "myOpenAI"
      }
    ],
    "vectorizers": [
      {
        "name": "myOpenAI",
        "kind": "azureOpenAI",
        "azureOpenAIParameters": {
          "resourceUri": OPENAI_SERVICE_NAME,
          "deploymentId": "text-embedding-ada-002",
          "apiKey": OpenAI_Service_Key,
          "authIdentity": None
        },
        "customWebApiParameters": None
      }
    ]
  }
}

r = requests.put(AZURE_SEARCH_ENDPOINT + "/indexes/" + index_name,
                 data=json.dumps(index_payload), headers=headers, params=params)
print(r.status_code)
# print(r.content)
print(r.ok)
#print(r.text) 

# COMMAND ----------

# Edit the null value in the skillset payload
# Replcae "null" with None in the last few lines of code

# Create a skillset
skillset_payload = {
    "name": skillset_name,
    "description": "Extract entities, detect language and extract key-phrases",
    "skills":
    [
        {
            "@odata.type": "#Microsoft.Skills.Vision.OcrSkill",
            "description": "Extract text (plain and structured) from image.",
            "context": "/document/normalized_images/*",
            "defaultLanguageCode": "en",
            "detectOrientation": True,
            "inputs": [
                {
                  "name": "image",
                  "source": "/document/normalized_images/*"
                }
            ],
                "outputs": [
                {
                  "name": "text",
                  "targetName" : "images_text"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.MergeSkill",
            "description": "Create merged_text, which includes all the textual representation of each image inserted at the right location in the content field. This is useful for PDF and other file formats that supported embedded images.",
            "context": "/document",
            "insertPreTag": " ",
            "insertPostTag": " ",
            "inputs": [
                {
                  "name":"text", "source": "/document/content"
                },
                {
                  "name": "itemsToInsert", "source": "/document/normalized_images/*/images_text"
                },
                {
                  "name":"offsets", "source": "/document/normalized_images/*/contentOffset"
                }
            ],
            "outputs": [
                {
                  "name": "mergedText", 
                  "targetName" : "merged_text"
                }
            ]
        },
        # {
        #     "@odata.type": "#Microsoft.Skills.Text.LanguageDetectionSkill",
        #     "context": "/document",
        #     "description": "If you have multilingual content, adding a language code is useful for filtering",
        #     "inputs": [
        #         {
        #           "name": "text",
        #           "source": "/document/content"
        #         }
        #     ],
        #     "outputs": [
        #         {
        #           "name": "languageCode",
        #           "targetName": "language"
        #         }
        #     ]
        # },
        {
            "@odata.type": "#Microsoft.Skills.Text.SplitSkill",
            "context": "/document",
            "textSplitMode": "pages",
            "maximumPageLength": 5000, # 5000 is default
            "pageOverlapLength": 200,
            "defaultLanguageCode": "en",
            "inputs": [
                {
                    "name": "text",
                    "source": "/document/merged_text"
                },
                {
                    "name": "languageCode",
                    "source": "/document/language"
                }
            ],
            "outputs": [
                {
                    "name": "textItems",
                    "targetName": "pages"
                }
            ]
        },
        # {
        #     "@odata.type": "#Microsoft.Skills.Text.KeyPhraseExtractionSkill",
        #     "context": "/document/pages/*",
        #     "maxKeyPhraseCount": 2,
        #     "defaultLanguageCode": "en",
        #     "inputs": [
        #         {
        #             "name": "text", 
        #             "source": "/document/pages/*"
        #         },
        #         {
        #             "name": "languageCode",
        #             "source": "/document/language"
        #         }
        #     ],
        #     "outputs": [
        #         {
        #             "name": "keyPhrases",
        #             "targetName": "keyPhrases"
        #         }
        #     ]
        # },
        # {
        #     "@odata.type": "#Microsoft.Skills.Text.V3.EntityRecognitionSkill",
        #     "context": "/document/pages/*",
        #     "categories": ["Person", "URL", "Email"],
        #     "minimumPrecision": 0.5, 
        #     "defaultLanguageCode": "en",
        #     "inputs": [
        #         {
        #             "name": "text", 
        #             "source":"/document/pages/*"
        #         },
        #         {
        #             "name": "languageCode",
        #             "source": "/document/language"
        #         }
        #     ],
        #     "outputs": [
        #         {
        #             "name": "persons", 
        #             "targetName": "persons"
        #         },                
        #         {
        #             "name": "locations",
        #             "targetName": "locations"
        #         },
        #         {
        #             "name": "organizations",
        #             "targetName": "organizations"
        #         },
        #         {
        #             "name": "dateTimes",
        #             "targetName": "dateTimes"
        #         },
        #         {
        #             "name": "urls", 
        #             "targetName": "urls"
        #         },
        #         {
        #             "name": "emails", 
        #             "targetName": "emails"
        #         }
        #     ]
        # },
        {
            "@odata.type": "#Microsoft.Skills.Text.AzureOpenAIEmbeddingSkill",
            "name": "EmbeddingSkill",
            "description": "Skill to generate embeddings via Azure OpenAI",
            "context": "/document/pages/*",
            "resourceUri": OPENAI_SERVICE_NAME,
            "apiKey": OpenAI_Service_Key,
            "deploymentId": "text-embedding-ada-002",
            "inputs": [
                {
                    "name": "text",
                    "source": "/document/pages/*"
                }
            ],
                "outputs": [
                    {
                        "name": "embedding",
                        "targetName": "embedding"
                    }
                ],
            "authIdentity": None
        },
    
    ],
    "cognitiveServices": {
        "@odata.type": "#Microsoft.Azure.Search.CognitiveServicesByKey",
        "description": COG_SERVICES_NAME,
        "key": COG_SERVICES_KEY
    },

  "knowledgeStore": None,
  "indexProjections": {
    "selectors": [
      {
        "targetIndexName": index_name,
        "parentKeyFieldName": "title",
        "sourceContext": "/document/pages/*",
        "mappings": [
          {
            "name": "content",
            "source": "/document/merged_text",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "chunkVector",
            "source": "/document/pages/*/embedding",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "chunk",
            "source": "/document/pages/*",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "images_text",
            "source": "/document/normalized_images/*/images_text",
            "sourceContext": None,
            "inputs": []
          },
          # {
          #   "name": "language",
          #   "source": "/document/language",
          #   "sourceContext": None,
          #   "inputs": []
          # },
          # {
          #   "name": "keyPhrases",
          #   "source": "/document/pages/*/keyPhrases/*",
          #   "sourceContext": None,
          #   "inputs": []
          # },{
          #   "name": "persons",
          #   "source": "/document/pages/*/persons/*",
          #   "sourceContext": None,
          #   "inputs": []
          # },{
          #   "name": "urls",
          #   "source": "/document/pages/*/urls/*",
          #   "sourceContext": None,
          #   "inputs": []
          # },
          # {
          #   "name": "emails",
          #   "source": "/document/pages/*/emails/*",
          #   "sourceContext": None,
          #   "inputs": []
          # },
          {
            "name": "name",
            "source": "/document/metadata_spo_item_name", #/document/pages/*   , metadata_storage_name , metadata_spo_item_name
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "location",
            "source": "/document/metadata_spo_item_weburi",  #  /document/pages/* ,  metadata_storage_path  , metadata_spo_item_weburi
            "sourceContext": None,
            "inputs": []
          },
        ]
      }
    ],
    "parameters": {
      "projectionMode": "skipIndexingParentDocuments"
    }
  },
  "encryptionKey": None
}

r = requests.put(AZURE_SEARCH_ENDPOINT + "/skillsets/" + skillset_name,
                 data=json.dumps(skillset_payload), headers=headers, params=params)
print(r.status_code)
# print(r.content)
print(r.ok) 
#print(r.text) 


# COMMAND ----------

# Create an indexer
indexer_payload = {
    "name": indexer_name,
    "dataSourceName": datasource_name,
    "targetIndexName": index_name,
    "skillsetName": skillset_name,
    #"schedule" : { "interval" : "PT24H"}, # How often do you want to check for new content in the data source
    "fieldMappings": [
        {
          "sourceFieldName" : "metadata_spo_site_library_item_id",  #  metadata_spo_site_library_item_id , metadata_storage_path
          "targetFieldName" : "id",
          "mappingFunction" : { "name" : "base64Encode" }
        },
        {
          "sourceFieldName" : "metadata_title",
          "targetFieldName" : "title"
        },
        {
          "sourceFieldName" : "metadata_spo_item_name", #   metadata_storage_name , metadata_spo_item_name
          "targetFieldName" : "name"
        },
        {
          "sourceFieldName" : "metadata_spo_item_weburi", #   metadata_storage_path , metadata_spo_item_weburi
          "targetFieldName" : "location"
        }
    ],
    "outputFieldMappings":
    [
      
        
    ],
    "parameters":
    {
        "maxFailedItems": -1,
        "maxFailedItemsPerBatch": -1,
        "configuration":
        {
            "dataToExtract": "contentAndMetadata",
            "indexedFileNameExtensions" : ".csv,.txt,.pdf,.docx,.pptx,.png,.jpg,.jpeg",
            "imageAction": "generateNormalizedImages",
            "executionEnvironment": "private"
        }
    }
}

r = requests.put(AZURE_SEARCH_ENDPOINT+ "/indexers/" + indexer_name,
                 data=json.dumps(indexer_payload), headers=headers, params=params)
print(r.status_code)
print(r.ok)
print(r.text)

