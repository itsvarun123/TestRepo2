# Databricks notebook source
#install Event-hub libraries in Python
#Link to Python program capturing the Streaming data from 
#https://github.com/Azure/azure-event-hubs-spark/blob/master/docs/PySpark/structured-streaming-pyspark.md#deploying

#ehConf['eventhubs.connectionString'] = connectionString
#val namespaceName = "ehns-ykdefect-qa-ncus-1"
#val eventHubName = "ehub-ykdefect-tj22"
#val sasKeyName = "RootManageSharedAccessKey"
#val sasKey = "GTauPDTnbEiQJu74WulrxgJhhXbFU6ge5HgN1tJg8Ts="

#connectionString = "Endpoint=sb://{NAMESPACE}.servicebus.windows.net/{EVENT_HUB_NAME};EntityPath={EVENT_HUB_NAME};SharedAccessKeyName={ACCESS_KEY_NAME};SharedAccessKey={ACCESS_KEY}"

%pip install azure-eventhub
%pip install azure-eventhub-checkpointstoreblob-aio

# COMMAND ----------


import asyncio
import os
from azure.eventhub.aio import EventHubConsumerClient
from azure.eventhub.extensions.checkpointstoreblobaio import BlobCheckpointStore
import datetime
from datetime import datetime as dt
import json
# dbutils.fs.mkdirs("Sample/pyCheckPoint/")   # one time Creation

# COMMAND ----------

connectionString = "Endpoint=sb://ehns-ykdefect-qa-ncus-1.servicebus.windows.net/ehub-ykdefect-tj22;EntityPath=ehub-ykdefect-tj22;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=GTauPDTnbEiQJu74WulrxgJhhXbFU6ge5HgN1tJg8Ts="

ehConf = {'eventhubs.connectionString' : connectionString }

ehConf['eventhubs.connectionString'] = sc._jvm.org.apache.spark.eventhubs.EventHubsUtils.encrypt(connectionString)

checkpointPath="/Sample/pyCheckPoint/"
startOffset = "-1"
endTime = dt.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")

startingEventPosition = {
  "offset": startOffset,  
  "seqNo": -1,            #not in use
  "enqueuedTime": None,   #not in use
  "isInclusive": True
}
endingEventPosition = {
  "offset": None,           #not in use
  "seqNo": -1,              #not in use
  "enqueuedTime": endTime,
  "isInclusive": True
}

ehConf["eventhubs.startingPosition"] = json.dumps(startingEventPosition)
ehConf["eventhubs.endingPosition"] = json.dumps(endingEventPosition)

receiverTimeoutDuration = datetime.time(0,3,20).strftime("PT%HH%MM%SS")
operationTimeoutDuration = datetime.time(0,1,0).strftime("PT%HH%MM%SS")

ehConf["eventhubs.receiverTimeout"] = receiverTimeoutDuration

ehConf["eventhubs.receiverTimeout"] = receiverTimeoutDuration

df = spark.readStream.format("eventhubs").options(**ehConf).load()

df = df.withColumn("body", df["body"].cast("string"))
df=df.select("body")
df.writeStream.format("delta").outputMode("append").option("checkpointLocation", checkpointPath).toTable("events")

#df.writeStream.format("parquet").outputMode("append").option("path", "azure_streaming_test").option("checkpointLocation", #"azure_streaming_checkpoint").start().query.awaitTermination()

# COMMAND ----------

df.createOrReplaceTempView('eventhubdata')

# COMMAND ----------

# MAGIC %sql
# MAGIC select body from eventhubdata

# COMMAND ----------

connectionString = "Endpoint=sb://ehns-ykdefect-qa-ncus-1.servicebus.windows.net/ehub-ykdefect-tj22;EntityPath=ehub-ykdefect-tj22;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=GTauPDTnbEiQJu74WulrxgJhhXbFU6ge5HgN1tJg8Ts="
ehConf = {'eventhubs.connectionString' : connectionString }

ehConf['eventhubs.connectionString'] = sc._jvm.org.apache.spark.eventhubs.EventHubsUtils.encrypt(connectionString)

startOffset = "-1"
endTime = dt.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")

ehName = "ehub-ykdefect-tj22"

positionKey1 = {
  "ehName": ehName,
  "partitionId": 0
}

eventPosition1 = {
  "offset": "@latest",    
  "seqNo": -1,            
  "enqueuedTime": None,   
  "isInclusive": True
}

positionKey2 = {
  "ehName": ehName,
  "partitionId": 2
}
eventPosition2 = {
  "offset": None,     
  "seqNo": 1000000000000,   #135489734      
  "enqueuedTime": None,
  "isInclusive": True
}
positionMap = {
  json.dumps(positionKey1) : eventPosition1,
  json.dumps(positionKey2) : eventPosition2
}

ehConf["eventhubs.startingPositions"] = json.dumps(positionMap)
#
receiverTimeoutDuration = datetime.time(0,3,20).strftime("PT%HH%MM%SS")   # 200 secs
operationTimeoutDuration = datetime.time(0,1,0).strftime("PT%HH%MM%SS")  # 60 secs

ehConf["eventhubs.startingPositions"] = json.dumps(positionMap)
#
receiverTimeoutDuration = datetime.time(0,3,20).strftime("PT%HH%MM%SS")  
operationTimeoutDuration = datetime.time(0,1,0).strftime("PT%HH%MM%SS")
ehConf["eventhubs.receiverTimeout"] = receiverTimeoutDuration

ehConf["eventhubs.receiverTimeout"] = receiverTimeoutDuration
df1 = spark.read.format("eventhubs").options(**ehConf).load()
df1 = df.withColumn("body", df["body"].cast("string"))


# COMMAND ----------

df1=df1.select("body")
df1.createOrReplaceTempView('eventhubdata1')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from eventhubdata1

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from events