# Databricks notebook source
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
dataset = pd.read_csv("Data.csv")

# COMMAND ----------

# MAGIC %fs ls /FileStore/
# MAGIC

# COMMAND ----------

dataset= spark.read.csv(f'/mnt/researchwork/Data.csv',sep=',',header=True,inferSchema=True)
x=dataset.iloc[:, :-1].values

# COMMAND ----------

dataset = pd.read_csv("/mnt/researchwork/Data.csv")

# COMMAND ----------

s="bollywood"
s.capitalize()
print(s.capitalize())