# Databricks notebook source
# MAGIC %md
# MAGIC #### Regular Expressions:
# MAGIC * If we want to represent group of string according to perticular pattern then we should go for regular expression concept.
# MAGIC * To implement validation framework.
# MAGIC * To develop pattern matching applications.
# MAGIC *  To develop translators like compilers, interpreters.

# COMMAND ----------

# MAGIC %md
# MAGIC * __`[]`__	A set of characters	__`"[a-m]"`__
# MAGIC * __`\`__	Signals a special sequence (can also be used to escape special characters)	__`"\d"`__
# MAGIC * __`.`__	Any character (except newline character)	__`"he..o"`__
# MAGIC * __`^`__	Starts with	__`"^hello"`__
# MAGIC * __`$`__	Ends with	__`"world$""`__	
# MAGIC * __`*`__	Zero or more occurrences	__`"aix*"`__
# MAGIC * __`+`__	One or more occurrences	__`"aix+"	`__
# MAGIC * __`{}`__	Exactly the specified number of occurrences	__`"al{2}"	`__
# MAGIC * __`|`__	Either or	__`"falls|stays"`__

# COMMAND ----------

import re
help(re)

# COMMAND ----------

# MAGIC %md
# MAGIC * __`\A`__	Returns a match if the specified characters are at the beginning of the string	"\AThe"	
# MAGIC

# COMMAND ----------

import re

txt = "The Python in Spark pyspark"

#Check if the string starts with "The":

x = re.findall("\AThe", txt)

print(x)

if x:
  print("Yes, there is a match!",x)
else:
  print("No match")

# COMMAND ----------

# MAGIC %md
# MAGIC * __`\b`__	Returns a match where the specified characters are at the beginning or at the end of a word (the "r" in the beginning is making sure that the string is being  treated as a "raw string")	r"\bain" or r"ain\b"

# COMMAND ----------

import re

txt = "The rain in india"

#Check if "in" is present at the beginning of a WORD:
# in python how to store more than one value or item. [1,2,3,]

x = re.findall(r"\bin", txt)

print(x)

if x:
  print("Yes, there is at least one match!",x)
else:
  print("No match")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC * __`\B`__	Returns a match where the specified characters are present, but NOT at the beginning (or at the end) of a word (the "r" in the beginning is making sure that the string is being treated as a "raw string")	r"\Bain" r"ain\B"	
# MAGIC

# COMMAND ----------


import re

txt = "The Python in Spark pyspark"

#Check if "park" is present, but NOT at the beginning of a word:

x = re.findall(r"\Bpark", txt)

print(x)

if x:
  print("Yes, there is at least one match!",x)
else:
  print("No match")


# COMMAND ----------

# MAGIC %md
# MAGIC * __`\d`__	Returns a match where the string contains digits (numbers from 0-9)	"\d"	
# MAGIC

# COMMAND ----------

import re

txt = "check this number 9 if exists return 66 if not 88 other wise 4333"

#Check if the string contains any digits (numbers from 0-9):

x = re.findall("\d+", txt)

print(x)

if x:
  print("Yes, there is at least one match!",x)
else:
  print("No match")


# COMMAND ----------

# MAGIC %md
# MAGIC * __`\D`__	Returns a match where the string DOES NOT contain digits	"\D"	
# MAGIC

# COMMAND ----------

import re

txt = "can you verify 77 if not 99 other wise 66 else 22"

#Return a match at every no-digit character [^0-9]:

x = re.findall("\D+", txt)

print(x)

if x:
  print("Yes, there is at least one match!")
else:
  print("No match")


# COMMAND ----------

# MAGIC %md
# MAGIC * __`\s`__	Returns a match where the string contains a white space character	"\s"	
# MAGIC

# COMMAND ----------

import re

txt = """hey r u there if space is available return that space \n
\t
\r"""

#Return a match at every white-space character which includes [ \t\n\r\f\v]

x = re.findall("\s", txt)

print(x)

if x:
  print("Yes, there is at least one match!")
else:
  print("No match")


# COMMAND ----------

# MAGIC %md
# MAGIC * __`\S`__	Returns a match where the string DOES NOT contain a white space character	"\S"	
# MAGIC

# COMMAND ----------

import re

txt = """Hey are you there \n \t $ *
verify this string in python \n
if you have time"""

#Return a match at every NON white-space character:

x = re.findall("\S+", txt)

print(x)

if x:
  print("Yes, there is at least one match!")
else:
  print("No match")


# COMMAND ----------

# MAGIC %md
# MAGIC * __`\w`__	Returns a match where the string contains any word characters (characters from a to Z, digits from 0-9, and the underscore _ character)	"\w"	
# MAGIC

# COMMAND ----------

import re

txt = """ just verify this string 99
using \w if 4 you have 3 time pls 55"""

#Return a match at every word character (characters from a to Z, digits from 0-9, and the underscore _ character):

x = re.findall("\w+", txt)

print(x)

if x:
  print("Yes, there is at least one match!")
else:
  print("No match")


# COMMAND ----------

# MAGIC %md
# MAGIC * __`\W`__	Returns a match where the string DOES NOT contain any word characters	"\W"	
# MAGIC

# COMMAND ----------

import re

txt = "Is everything 4 is 5 fine? 55 \t 66 \n 77 this is sample string \r \n"

#Return a match at every NON word character (characters NOT between a and Z. Like "!", "?" white-space etc.):

x = re.findall("\W", txt)

print(x)

if x:
  print("Yes, there is at least one match!")
else:
  print("No match")


# COMMAND ----------

# MAGIC %md
# MAGIC * __`\Z`__	Returns a match if the specified characters are at the end of the string	"city\Z"

# COMMAND ----------

import re

txt = "IS it raining outside city"

#Check if the string ends with "city":

x = re.findall("it\Z", txt)

print(x)

if x:
  print("Yes, there is a match!")
else:
  print("No match")


# COMMAND ----------

import re
pattern = re.compile('ab')
matcher = pattern.finditer('babbbbaabaaaabaab')
count=0
for i in matcher:
    count+=1
    print("Match is found at start index:",i.start())
print("The number of ocuurances of 'ab'(Count):",count)   

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

import re
matcher = re.finditer('ab','babaaababaaab')
                  #  pattern  target_string
count=0
for m in matcher:
    count+=1
    print("start:{} end:{} group:{}".format(m.start(),m.end(),m.group()))
print("Count:",count)

# COMMAND ----------

# MAGIC %md
# MAGIC #### character classes :
# MAGIC
# MAGIC * a or b or c
# MAGIC
# MAGIC * any alphabate symbol
# MAGIC
# MAGIC * any digit
# MAGIC
# MAGIC * __`[abc]`__ ===> either a or b or c
# MAGIC
# MAGIC * __`[^abc]`__ ====>Except a and b and c
# MAGIC
# MAGIC * __`[a-z]`__ ====> Any lower case alphabate symbols
# MAGIC
# MAGIC * __`[A-Z]`__ ====> Any upper case alphabate symbols
# MAGIC
# MAGIC * __`[a-zA-Z]`__ ====> Any alphabate symbol
# MAGIC
# MAGIC * __`[0-9]`__ =====> Any digit
# MAGIC
# MAGIC * __`[a-zA-Z0-9]`__ ====> any alphanumeric character
# MAGIC
# MAGIC *__` [^a-zA-Z0-9]`__ ====> other than alphanumeric character
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

import re
matcher = re.finditer('[abc]','a7b@k9z') # a or b or c
for m in matcher:
    print(m.start(),'-------',m.group()) # group() return current matching item



# COMMAND ----------

import re
matcher = re.finditer('[^abc]','a7b@k9z')# except a or b or c
for m in matcher:
    print(m.start(),'-------',m.group())

# COMMAND ----------

import re
matcher = re.finditer('[a-z]','a7b@k9z')
for m in matcher:
    print(m.start(),'-------',m.group())

# COMMAND ----------

import re
matcher = re.finditer('[0-9]','a7b@k9z')
for m in matcher:
    print(m.start(),'-------',m.group())

# COMMAND ----------

import re
matcher = re.finditer('[a-zA-Z0-9]','a7b@k9z')
for m in matcher:
     print(m.start(),'----------',m.group())

# COMMAND ----------

import re
matcher = re.finditer('[^a-zA-Z0-9]','a7b@k9z')
for m in matcher:
     print(m.start(),'----------',m.group())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Few examples on character classes

# COMMAND ----------

# MAGIC %md
# MAGIC * __`\s`__ ---> space character
# MAGIC
# MAGIC * __`\S`__ -----> except space character
# MAGIC
# MAGIC * __`\d`__ ----> any digit
# MAGIC
# MAGIC * __`\D`__ -----> except digit
# MAGIC
# MAGIC * __`\w`__ ------> any word character(alpha numeric character) [a-zA-Z0-9]
# MAGIC
# MAGIC * __`\W`__ ---> Any character except word(special characters)  [^a-zA-Z0-9]
# MAGIC
# MAGIC * __`.`__ ------> Every character
# MAGIC

# COMMAND ----------

import re
matcher = re.finditer('\s','a7b @k9z') # \s space character
for m in matcher:
    print(m.start(),'--------',m.group())

# COMMAND ----------

import re
matcher = re.finditer('\S','a7b @k9z') # except space character
for m in matcher:
    print(m.start(),'--------',m.group())

# COMMAND ----------

import re
matcher = re.finditer('\w','a7b @k9z')#alpha-numeric characters
for m in matcher:
    print(m.start(),'---------',m.group())

# COMMAND ----------

import re
matcher = re.finditer('\W','a7b @k9z')#Except alphan-umeric character
for m in matcher:
    print(m.start(),'---------',m.group())

# COMMAND ----------

import re
matcher = re.finditer('.','a7b @k9z') # every character
for m in matcher:
    print(m.start(),'--------',m.group())

# COMMAND ----------

import re
matcher = re.finditer('\d','a7b @k9z') # any digit
for m in matcher:
    print(m.start(),'--------',m.group())

# COMMAND ----------

import re
matcher = re.finditer('\D','a7b @k9z') # except digits
for m in matcher:
    print(m.start(),'--------',m.group())

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Quantifiers:
# MAGIC * Quantifiers can be used to specify the number of occurances to match

# COMMAND ----------

# MAGIC %md
# MAGIC * a ----> exectly one 'a'
# MAGIC
# MAGIC * a+ ----> atleast one 'a'
# MAGIC
# MAGIC * a* -----> any number of a's including zero number also
# MAGIC
# MAGIC * a? ------> atmost one a (meaning either one a or zero number of a's)
# MAGIC
# MAGIC * a{n} -------> Exactly n number of a's
# MAGIC
# MAGIC * a{m,n} ------> Minimum m number of a's and maximum n number of a's
# MAGIC
# MAGIC * [^a] -------> Except 'a' all the remaining
# MAGIC
# MAGIC * ^a ------> It will check whether the given target string starts with 'a' or not
# MAGIC
# MAGIC * a$ ----> It will check whether the given target string ends with 'a' or not

# COMMAND ----------

# exactly one 'a'

import re
matcher = re.finditer('a','abaabaaab')
for m in matcher:
    print(m.start(),'--------',m.group())

# COMMAND ----------

# atleast one 'a'
import re
matcher = re.finditer('a+','abaabaaab')
for m in matcher:
    print(m.start(),'-------',m.group())

# COMMAND ----------

# a* -----> any number of a's including zero number also

import re
matcher = re.finditer('a*','abaabaaab')
for m in matcher:
    print(m.start(),'-------',m.group())

# COMMAND ----------

# a? ------> atmost one a (meaning either one a or zero number of a's)

import re
matcher = re.finditer('a?','abaabaaab')
for m in matcher:
    print(m.start(),'-------',m.group())


# COMMAND ----------

# a{n} -------> Exactly n number of a's


import re
matcher = re.finditer('a{3}','abaabaaab')
for m in matcher:
    print(m.start(),'-------',m.group())


# COMMAND ----------

# a{m,n} ------> Minimum m number of a's and maximum n number of a's

import re
matcher = re.finditer('a{2,3}','abaabaaab')
for m in matcher:
    print(m.start(),'----------',m.group())


# COMMAND ----------

import re
matcher = re.finditer('a{1}','abaabaaab')
for m in matcher:
    print(m.start(),'--------',m.group())

# COMMAND ----------

import re
matcher = re.finditer('a{1,3}','abaabaaabaaaabaaaaab') # length of string starting and ending {1,3}
for m in matcher:
    print(m.start(),'---------',m.group())

# COMMAND ----------

 # [^a] -------> Except 'a' all the remaining

    
import re
matcher = re.finditer('[^a]','abaabaaab')
for m in matcher:
    print(m.start(),'---------',m.group())

# COMMAND ----------

# ^a ------> 
# It will check whether the given target string starts with 'a' or not

import re
matcher = re.finditer('^a','a will verify')
for m in matcher:
    print(m.start(),'---------',m.group())

# COMMAND ----------

# a$ ----> 
# It will check whether the given target string ends with 'a' or not
# if it not ends with 'a' then it will return nothing and if
# it ends with 'a' it will return index of that match

import re
matcher = re.finditer('a$','porapora')
for m in matcher:
    print(m.start(),'---------',m.group())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Important functions of re module
# MAGIC
# MAGIC ##### 1. match()
# MAGIC
# MAGIC ##### 2. fullmatch()
# MAGIC
# MAGIC ##### 3. search()
# MAGIC
# MAGIC ##### 4. findall()
# MAGIC
# MAGIC ##### 5. finditer()
# MAGIC
# MAGIC ##### 6. sub()
# MAGIC
# MAGIC ##### 7. subn()
# MAGIC
# MAGIC ##### 8. split()
# MAGIC
# MAGIC ##### 9. compile()
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### 1. match()
# MAGIC *  to check the given pattern at the beginning of the target string
# MAGIC * If then returns Match object otherwise returns None.

# COMMAND ----------

import re
string = 'abcdefgh'
matcher = re.match(string,'abcdefgh')
print(matcher)

if matcher != None :
    print("Match is available at the beginning of the string")
    print('Start index:{} and End Index:{}'.format(matcher.start(),matcher.end()))
else:
    print('Match is not available at the beginning of the string')

# COMMAND ----------

# MAGIC %md
# MAGIC #### 2. fullmatch()
# MAGIC * Total target string should be match according to the given string.

# COMMAND ----------

import re
s = 'sample text'
m =re.fullmatch(s,'sample text')

print(m) # match object

if m != None:
    print("Full string is matched :" ,m)
else:
    print("Full string is not matched : ",m)

# COMMAND ----------

# MAGIC %md
# MAGIC #### 3. search()
# MAGIC * Match object of the first occurance
# MAGIC * If match not found returns None.
# MAGIC

# COMMAND ----------

import re
s = 'ab'
m = re.search(s,'abaabaaab')
print(m)

if m != None :
    print("Search is available at start index:{} and end index:{}".format(m.start(),m.end()))
else:
    print("search is not available")

# COMMAND ----------

# MAGIC %md
# MAGIC #### 4. findall()
# MAGIC * Find all the matches and return into the list

# COMMAND ----------

import re
l = re.findall('[0-9]','a7b9k6z')
print(l)

# COMMAND ----------

import re
l = re.findall('\W','a7# sfj$9')# '\W' except alpha-numeric characters
print(l)

# COMMAND ----------

import re
l = re.findall('\d','a7# sfj$9') # '\d'--> all digits
print(l)

# COMMAND ----------

import re
l = re.findall('[a-z]', 'a7# sfj$9')
print(l)

# COMMAND ----------

# MAGIC %md
# MAGIC #### 5. finditer():
# MAGIC * It returns iterator of matched objects.

# COMMAND ----------

import re
matcher = re.finditer('\d','a7bk9z6')
print(matcher)
for m in matcher:
    print(type(m))
    print(m.start(),'------',m.group()) # index with value

# COMMAND ----------

import re
matcher = re.finditer('\D','a7bk9z6')
for m in matcher:
    print(m.start(),'------',m.group()) # index with value

# COMMAND ----------

# MAGIC %md
# MAGIC #### 6.sub()
# MAGIC * substitution or replacement
# MAGIC * re.sub('pattern','replacement','target_string')

# COMMAND ----------

import re
s = re.sub('\d','#','a7b9k5t9k')
print(s)

# COMMAND ----------

import re
s =re.sub('.','*','!@#Suresh012345')
print(s)

# COMMAND ----------

# MAGIC %md
# MAGIC #### 8.subn()
# MAGIC #### `re.subn(regex,replacement,targetstring)`
# MAGIC
# MAGIC * n ---> No of replacement happens we will get in the form of tuple.
# MAGIC * The first value in the tuple is resultstring and second value is number of replacements.
# MAGIC * (resultstring,number of replacements)
# MAGIC * Return type of subn method is tuple

# COMMAND ----------

import re
t = re.subn('\d','xxxx','a7b9k5t9k')
print(type(t))
print(t)
print('The result string:',t[0])
print('The number of replacements happened are:',t[1])

# COMMAND ----------

# MAGIC %md
# MAGIC #### 9.split()
# MAGIC

# COMMAND ----------

import re
l = re.split('-','10-20-30-40-50')
print(l)

# COMMAND ----------

import re
l = re.split('\.','www.ap.gov.in')
print(l)

# COMMAND ----------

import re
y = re.split('[.]','www.ap.gov.in')
print(y)

# COMMAND ----------

# re.IGNORECASE ignore the case(lower case or upper case)
import re
s = "Learning Python is very easyy"
result = re.search("Easyy$",s,re.IGNORECASE)
if result != None :
    print("Target string ends with Easyy")
else:
    print("Target string is not ends with Easyy")

# COMMAND ----------

import re
s = "Learning Python is very easyy"
result = re.search("python",s) # not matching with case it will return if we search initcap Python
if result != None :
    print("Target string ends with Easyy",result)
else:
    print("Target string is not ends with Easyy",result)

# COMMAND ----------

import re
s ='Learning python is very easy'
m = re.search('Learn*',s)
if m != None:
    print("Target string starts with Learn",m)
else:
    print("Not start with Learn")

# COMMAND ----------

# MAGIC %md
# MAGIC ####  write a regular expression to represent all  10 digit mobile Number.

# COMMAND ----------

# [6-9][0-9]{9} or [6-9]\d{9}

import re
s = '6988938829'
m = re.fullmatch('[6-9]\d{9}',s)
if m != None :
    print(s,'is valid mobile number',m)
else:
    print(s,'is not valid number',m)


# COMMAND ----------

# MAGIC %md
# MAGIC #### Web scraping by using Regular Expression
# MAGIC * The process of collecting data from the web pages is called as web scraping.

# COMMAND ----------

import re,urllib
sites = ['http://google.com','http://rediff.com']
for s in sites:
    print('Searchig...',s)
    u = urllib.request.urlopen(s)
    text = u.read()
    title = re.findall('<title>.*</title>',str(text),re.IGNORECASE)
    print(title[0])

# COMMAND ----------

import re,urllib
import urllib.request
u = urllib.request.urlopen('http://www.redbus.in/info/contactus')
text = u.read()
numbers = re.findall('[+]\d[0-9]{11}',str(text))
for n in numbers:
    print(n)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Write a python program to check whether given maid id's are valid or not.

# COMMAND ----------

import re
s = 'pysparktelugu@gmail.com'
m = re.fullmatch('\w[a-zA-Z0-9_.]*@(gmail|rediffmail)[.]com+',s)
if m != None:
    print("Valid mail id")
else:
    print("Invalid email id")

# COMMAND ----------

