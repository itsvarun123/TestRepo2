# Databricks notebook source
# Python code to get the Cumulative sum of a list 
def Cumulative(lists): 
    cum_list = [] 
    length = len(lists) 
    cum_list = [sum(lists[0:x]) for x in range(0, length+1)] 
    return cum_list[1:]

lists = [10, 20, 30, 40, 50] 
print (Cumulative(lists)) 

# COMMAND ----------

lists =[1,2,3,4,5,6,7,8,9,10]
for x in range(0, 10+1):
  #print(x)
  print(sum(lists[0:x]))


# COMMAND ----------

# get sum of all values in list
my_list = [1,2,3,4,5,6,7,8,9,10]
sum(my_list)

# COMMAND ----------

# Get sum of values from 1 To N without using  sum function
# Using For loop and Range we can achive this.
def sum_all(n):
  a=0
  for i in range(1,n+1):
    a+=i # keep adding i into the sum - same as sum = sum +i
  return a
sum_all(10)

# COMMAND ----------

df = spark.createDataFrame([( 1, 1), ( 2, 0), ( 3, 2), (4, 1), ( 5, 2)],['id', 'value'])
display(df)

# COMMAND ----------

#cumulative using pyspark

from pyspark.sql.functions import expr
 
df =df.withColumn('cumsum',expr('sum(value) over (order by id)'))
display(df)

# COMMAND ----------

from pyspark.sql.functions import sum
from pyspark.sql import Window
 
df = df.withColumn('cumsum1',sum('value').over(Window.orderBy('id')))
display(df)

# COMMAND ----------

# MAGIC %%time
# MAGIC my_rdd = sc.parallelize([1,2,3,4,5,6,7,8,9,10],4)
# MAGIC my_rdd.map(lambda x: x+11).collect()

# COMMAND ----------

baby_df = spark.read.csv("dbfs:/babynames.csv",header=True,inferSchema=True)

# COMMAND ----------

display(baby_df)

# COMMAND ----------

# MAGIC %%time
# MAGIC from pyspark.sql import functions as f
# MAGIC baby_df.select('*').filter(f.col('year')=='2010').groupBy(f.col('sex')).count().show()

# COMMAND ----------

# MAGIC %%time
# MAGIC #my_rdd.cache()
# MAGIC my_rdd.map(lambda x: x+11).collect()

# COMMAND ----------

# 1. Python program to check if a string is palindrome or not
# Input : malayalam
# Output : Yes
# Input : KITIKI
# Output : No
def palindrome(word):
    for i in range(0, int(len(word)/2)):
            if word[i] != word[len(word) - i - 1]:
                return False
    else:
        return True
        

word = 'malayalam'
output = palindrome(word)

if output:
    print("Yes")
else:
    print("No")

# COMMAND ----------

# Reverse words in a given String in Python
def reverseString(str):
    words = str.split(" ")
    
    rev_sentence = (" ").join(reversed(words))
    
    return rev_sentence

str = "string reverse sample is this"
reverseString(str)

# COMMAND ----------

# 3. Ways to remove i’th character from string in Python

test_str = "TESTREPLACESTRING"

n = 2

new_str = test_str[:n] + test_str[n+1:]
print("Using approach 1 :", new_str)

# another approach using join
newString = ''.join([test_str[i] for i in range(len(test_str)) if i != n])
print("Using approach 2 :", newString)



# COMMAND ----------

# 4. Python | Check if a Substring is Present in a Given String

# Input : s1 = TEST s2=TESTS for STRNGS
# Output : yes

# Input : s1 = TEST s2=TESTS for STRINGS
# Output : yes

def subPresent(s1, s2):
    if s1 in s2:
        print("Yes")
    else:
        print("No")
    
s1 = "TESTS"
s2 = "TESTS for STRINGS"

subPresent(s1, s2)


# COMMAND ----------

#Find length of a string in python without using len function
def lengthStr(word):
    count = 0    
    for i in word:
        count += 1        
    return count

word = 'hello world !'
lengthStr(word)

# COMMAND ----------

# 6. Python program to print even length words in a string

# Input: s = "This is a python language"
# Output: This
#         is
#         python
#         language 
 

def evenLengthWords(s):
    splitWord = s.split(" ")
    print(splitWord)

    for i in splitWord:
        if len(i) % 2 == 0:
            print(i)
            
s = "my name is ravi"

evenLengthWords(s)
        