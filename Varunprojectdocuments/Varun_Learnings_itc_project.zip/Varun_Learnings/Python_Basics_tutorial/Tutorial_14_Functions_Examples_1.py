# Databricks notebook source
# MAGIC %md
# MAGIC ###### `Booleans` : Python implements all of the usual operators for Boolean logic, but uses English words rather than symbols (&&, ||, etc.):

# COMMAND ----------

t = True
f = False
print(type(t)) # Prints "<class 'bool'>"
print(t and f) # Logical AND; prints "False"
print(t or f)  # Logical OR; prints "True"
print(not t)   # Logical NOT; prints "False"
print(t != f)  # Logical XOR; prints "True"

# COMMAND ----------

# MAGIC %md
# MAGIC ##### `Strings` : Python has great support for strings

# COMMAND ----------

hello = 'hello'    # String literals can use single quotes
world = "world"    # or double quotes; it does not matter.
print(hello)       # Prints "hello"
print(len(hello))  # String length; prints "5"
hw = hello + ' ' + world  # String concatenation
print(hw)  # prints "hello world"
st = '%s %s %d' % (hello, world, 12)  # sprintf style string formatting
print(st)  # prints "hello world 12"

# COMMAND ----------

s = "hello"
# Capitalize a string; prints "Hello"
print(s.capitalize())  
# Convert a string to uppercase; prints "HELLO"
print(s.upper())       
# Right-justify a string, padding with spaces; prints "  hello"
print(s.rjust(7))
# Center a string, padding with spaces; prints " hello "
print(s.center(7)) 
# Replace all instances of one substring with another; # prints "he(ell)(ell)o"
print(s.replace('l', '(ell)'))  
                                
# Strip leading and trailing whitespace; prints "world"
print('  world '.strip())  

# COMMAND ----------

#upper()
print('upper string : ',st.upper())
#lower()
print('Lower string : ',st.lower())
#len()
print('length of string :' ,len(st))

#Using reveresed() in string, tuple, list, and range
print('Reversed the String : ',list(reversed([1,4,3,8,5])))
#sorted
print('sorted the String : ',sorted([1,4,3,8,5]))
print('sorted the String : ',sorted(st))
print('sorted the String : ',sorted([st]))


# COMMAND ----------

# MAGIC %md
# MAGIC ##### this code gives the numbers of integers, floats, and strings present in the list
# MAGIC

# COMMAND ----------

a= ['Raj',35,'b',45.5,'Ravi',60,True,False]
i=f=s=b=o=0
for j in a:
    if isinstance(j,int):
        print('integers',j)
        i=i+1
    elif isinstance(j,float):
        f=f+1
    elif isinstance(j,str):
        s=s+1
    elif isinstance(j,bool):
        b=b+1
    else:
        o=0+1
print('Number of integers are:',i)
print('Number of Floats are:',f)
print("numbers of strings are:",s)
print("numbers of booleans are:",b)

# COMMAND ----------

#this code gives the numbers of integers, floats, and strings present in the list


a= ['Raj',35,'b',45.5,'Ravi',60,True,False]
i=f=s=b=o=0
for j in a:
    if type(j)==int:
        print('integer values',j)
        i=i+1
    elif type(j)==float:
        print('float values :',j)
        f=f+1
    elif type(j)==str:
        print('String Values :',j)
        s=s+1
    elif type(j)==bool:
        print('Boolean Values :',j)
        b=b+1
    else:
        o=0+1
print('Number of integers are:',i)
print('Number of Floats are:',f)
print("numbers of strings are:",s)
print("numbers of booleans are:",b)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### *args : Variable number of arguments
# MAGIC *   `*`  single * for passing only parameter values.
# MAGIC *   `**` for passing paramenter Name and Values we can use `**`
# MAGIC * As per naming standard we will singe `*args` for only argument values  And `**kwargs` for passing argument name with values.

# COMMAND ----------

def adder(*onlyvalue):
    sum = 0
    
    for n in onlyvalue:
        sum = sum + n

    print("Sum:",sum)

adder(1,2,3)
adder(4,5,6,7)
adder(1,2,3,5,6)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Variable number of arguments with `keys` And `Values`
# MAGIC *  `**` for passing variable Name with Values.

# COMMAND ----------

def adder(**key_value):
    
    for k,v in key_value.items():
      print("Variable Name : {0} And Variable Value is :{1}  ".format(k,v))

adder(a=1,b=2,c=3) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### 1. Python program to add two numbers

# COMMAND ----------

#Creating function with arguments
def sum_of(a,b):
  sum = a + b
  print("Sum of {} and {} is {}". format(a, b, sum))

# Calling a function with parameters
sum_of(5,6)

# COMMAND ----------

# MAGIC %md
# MAGIC #### 2. Python Program for factorial of a number
# MAGIC

# COMMAND ----------

num = 10

def fact(n):
  """
  Python Program for factorial of a number
  Arguemnts:
  n : any number to generate Factorial
  """
  if n < 0: 
    return 0
  elif n == 0 or n == 1:
    return 1
  else:
    fact = 1
    while(n > 1):
      fact = fact * n
      n = n -1
    return fact
  
print("Fact of", num, "is :", fact(num))

# COMMAND ----------

# MAGIC %md
# MAGIC #### 3. Python Program for simple interest

# COMMAND ----------



# SI = (P * R * T) / 100
def simple_interest(P, R, T):
    print("The principal amount is:", P)
    print("The rate of interest is:", R)
    print("The time in years is:", T)
    
    SI = (P * R * T)/100
    
    print("Simple Interest is :", SI)
    return SI


# COMMAND ----------

simple_interest(10000, 8.0, 12)

# COMMAND ----------

# MAGIC %md
# MAGIC #### 4. Python Program for compound interest
# MAGIC

# COMMAND ----------


def amount(p, r, t):
    print("Principal amount = ", p)
    print("Rate of interest = ", r)
    print("Time duration in years = ", t)
    
    A = p * (pow((1 + r/100), t))
    
    Compound_Interest = A - p
    print("Compound Interest = ", Compound_Interest)
    
amount(10000, 10.25, 5)

# COMMAND ----------

# MAGIC %md
# MAGIC #### 5. Python Program to check Armstrong Number
# MAGIC

# COMMAND ----------


## 153 is an Armstrong number.
## 1*1*1 + 5*5*5 + 3*3*3 = 153

## 1253 is not a Armstrong Number
## 1*1*1*1 + 2*2*2*2 + 5*5*5*5 + 3*3*3*3 = 723

# taking input from user
num = 153

#to make it suitable for all cases.
order = len(str(num))

# initialise the sum to be 0
sum = 0

# declare a temp variable equal to num
temp = num

while(temp > 0):
    digit = temp % 10
    sum = sum + (digit)**order
    temp = temp // 10
    
if num == sum:
    print("{} is an Armstrong number.".format(num))

else:
    print("{} is not an Armstrong number.".format(num))

# COMMAND ----------

# MAGIC %md
# MAGIC #### 6. Python Program to find area of a circle
# MAGIC

# COMMAND ----------


# Area of circle = pi * r**2

def area_of_circle(r):
    pi = 3.14
    area = pi*(r)**2
    return area

radius = 55
print("Area of circle : ", area_of_circle(radius))


# COMMAND ----------

# MAGIC %md
# MAGIC #### 7. Python program to print all Prime numbers in an Interval
# MAGIC

# COMMAND ----------


# Given two positive integer start and end. The task is to write a Python program to
# print all Prime numbers in an Interval.

def find_prime_numbers(a, b):
    for num in range(a, b+1):
        if num > 1:
            for i in range(2, num):
                if (num % i) == 0:
                    break
            else:
                print("{} is a prime number.".format(num))



# COMMAND ----------

# MAGIC %md
# MAGIC #### 8. Python program to check whether a number is Prime or not
# MAGIC

# COMMAND ----------


def check_prime_number(num):
    if num > 1:
        for i in range(2, num):
            if (num % i) == 0:
                print("{} is not a prime number.".format(num))
                break
        else:
            print("{} is a prime number.".format(num))
    else:
        print("{} is not a prime number.".fromat(num))



# COMMAND ----------

check_prime_number(7)

# COMMAND ----------

# MAGIC %md
# MAGIC #### 9. Python Program for n-th Fibonacci number
# MAGIC

# COMMAND ----------


def fibonacci(num):
    n1, n2 = 0, 1
    count = 0
    
    if num <= 0:
        print("Enter a positive integer.")
    elif num == 1:
        print("Fibonacci series is : ", n1)
    else:
        while count < num:
            print(n1)
            # swapping values
            nth = n1 + n2
            n1 = n2
            n2 = nth
            count += 1

num = 55
fibonacci(num)  

# COMMAND ----------

# MAGIC %md
# MAGIC #### 10. Python Program for Fibonacci numbers
# MAGIC

# COMMAND ----------

# Find the nth term of fibonacci series.

def sum_fibonacci(num):
    n1, n2 = 0, 1
    count = 0
    
    if num <= 0:
        print("Please enter a positive integer value.")
    elif num == 1:
        print("Nth term of fibanacci series is:", n1)
    else:
        for i in range(num-2):
            new_fib = n1 + n2
            n1 = n2
            n2 = new_fib
        print(num,"th term of fibonacci series is :", n2)
        
num = 66
sum_fibonacci(num)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 11. Python Program to check if a given number is Fibonacci number? 
# MAGIC

# COMMAND ----------


# A number is Fibonacci if and only if one or both of (5*n2 + 4) or (5*n2 – 4) is a perfect square.

import math

def isPerfectSquare(x):
    s = int(math.sqrt(x))
    return s*s == x

def isFibanacci(n):
    return isPerfectSquare(5*n*n + 4) or isPerfectSquare(5*n*n - 4)

num = 77
for i in range(1, num+1):
    if(isFibanacci(i) == True):
        print(i, "is a fibonacci number.")
    else:
        print(i, "is not a fibonacci number.")

# COMMAND ----------

# MAGIC %md
# MAGIC #### 12. Python Program for nth multiple of a number in Fibonacci Series
# MAGIC

# COMMAND ----------


# Given two integers n and k. Find position the n\’th multiple of K in the Fibonacci series.

def findPosition(k, n): 
    f1 = 0
    f2 = 1
    i =2;  
    
    while i!=0: 
        f3 = f1 + f2; 
        f1 = f2; 
        f2 = f3; 
  
        if f2%k == 0: 
            return n*i 
        i+=1     
    return 
   
n = 5
# Number of whose multiple we are finding 
k = 7
  
print("Position of", n,"th multiple of",k,"in Fibonacci Series is", findPosition(k,n)); 

# COMMAND ----------

# 13. Program to print ASCII Value of a character

# For this problem we'll use ord() function in Python accepts a string of length 1 as an argument and returns
# the unicode code point representation of the passed argument.

char = 'R'

print("ASCII value of input character *",char,"* is:", ord(char))

# COMMAND ----------

# MAGIC %md
# MAGIC #### 14. Python Program for Sum of squares of first n natural numbers
# MAGIC

# COMMAND ----------


def sum_of_square(n) : 
  
    # Iterate i from 1  
    # and n finding  
    # square of i and 
    # add to sum. 
    sum = 0
    for i in range(1, n+1) : 
        sum = sum + (i * i) 
      
    return sum 
  
n =55
sum_of_square(n)

# COMMAND ----------

# MAGIC %md
# MAGIC #### 15. Python Program for cube sum of first n natural numbers
# MAGIC

# COMMAND ----------


def sum_of_cube(n):
    sum = 0
    
    for i in range(0, n+1):
        sum = sum + (i*i*i)
        
    return sum

num = 44
sum_of_cube(num)

# COMMAND ----------

# MAGIC %md
# MAGIC #### 16. Python code to demonstrate star pattern 
# MAGIC

# COMMAND ----------

  
# Function to demonstrate printing pattern 
def pypart(n): 
      
    # outer loop to handle number of rows 
    # n in this case 
    for i in range(0, n): 
      
        # inner loop to handle number of columns 
        # values changing acc. to outer loop 
        for j in range(0, i+1): 
          
            # printing stars 
            print("* ",end="") 
       
        # ending line after each row 
        print("\r") 
  
# Driver Code 
n = 5
pypart(n) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### 17. This is the example of print simple reversed right angle pyramid pattern  
# MAGIC

# COMMAND ----------

rows =10
k = 2 * rows - 2  # It is used for number of spaces  
for i in range(0, rows):  
    for j in range(0, k):  
        print(end=" ")  
    k = k - 2   # decrement k value after each iteration  
    for j in range(0, i + 1):  
        print("* ", end="")  # printing star  
    print("")  

# COMMAND ----------

# MAGIC %md
# MAGIC #### 18. Printing Downward half - Pyramid  
# MAGIC

# COMMAND ----------

rows = 10
#The outer loop is executing in reversed order 
for i in range(rows + 1, 0, -1):    
    for j in range(0, i - 1):  
        print("*", end=' ')  
    print(" ") 

# COMMAND ----------

# MAGIC %md
# MAGIC #### 19. Pattern - Printing Triangle Pyramid
# MAGIC

# COMMAND ----------

n = 10  
m = (2 * n) - 2  
for i in range(0, n):  
    for j in range(0, m):  
        print(end=" ")  
    m = m - 1  # decrementing m after each loop  
    for j in range(0, i + 1):  
        # printing full Triangle pyramid using stars  
        print("* ", end=' ')  
    print(" ")

# COMMAND ----------

# MAGIC %md
# MAGIC #### 20. Pattern - Downward Triangle Pattern
# MAGIC

# COMMAND ----------

rows = 10
  
# It is used to print space  
k = 2 * rows - 2  
# Outer loop in reverse order  
for i in range(rows, -1, -1):  
    # Inner loop will print the number of space.  
    for j in range(k, 0, -1):  
        print(end=" ")  
    k = k + 1  
    # This inner loop will print the number o stars  
    for j in range(0, i + 1):  
        print("*", end=" ")  
    print("")  

# COMMAND ----------

# MAGIC %md
# MAGIC #### 21. Diamond Shaped Pattern

# COMMAND ----------

rows = 10
  
# It is used to print the space  
k = 2 * rows - 2  
# Outer loop to print number of rows  
for i in range(0, rows):  
    # Inner loop is used to print number of space  
    for j in range(0, k):  
        print(end=" ")  
    # Decrement in k after each iteration  
    k = k - 1  
    # This inner loop is used to print stars  
    for j in range(0, i + 1):  
        print("* ", end="")  
    print("")  
  
# Downward triangle Pyramid  
# It is used to print the space  
k = rows - 2  
# Output for downward triangle pyramid  
for i in range(rows, -1, -1):  
    # inner loop will print the spaces  
    for j in range(k, 0, -1):  
        print(end=" ")  
    # Increment in k after each iteration  
    k = k + 1  
    # This inner loop will print number of stars  
    for j in range(0, i + 1):  
        print("* ", end="")  
    print("")  

# COMMAND ----------

# MAGIC %md
# MAGIC #### 22. Print two pyramid in a single pattern

# COMMAND ----------

rows = 10 
  
# Outer loop will print the number of rows  
for i in range(0, rows):  
    # This inner loop will print the stars  
    for j in range(0, i + 1):  
        print("*", end=' ')  
    # Change line after each iteration  
    print(" ")  
# For second pattern  
for i in range(rows + 1, 0, -1):  
    for j in range(0, i - 1):  
        print("*", end=' ')  
    print(" ")  

# COMMAND ----------

# MAGIC %md
# MAGIC #### 23.Hourglass Pattern

# COMMAND ----------

rows = 10  
k = rows - 2  
# This is used to print the downward pyramid  
for i in range(rows, -1 , -1):  
    for j in range(k , 0 , -1):  
        print(end=" ")  
    k = k + 1  
    for j in range(0, i+1):  
        print("* " , end="")  
    print()  
  
# This is used to print the upward pyramid  
k = 2 * rows  - 2  
for i in range(0 , rows+1):  
    for j in range(0 , k):  
        print(end="")  
    k = k - 1  
    for j in range(0, i + 1):  
        print("* ", end="")  
    print()  

# COMMAND ----------

# MAGIC %md
# MAGIC #### 24. Number Pattern in Python

# COMMAND ----------

rows = 10 
# Outer loop will print number of rows  
for i in range(rows+1):  
    # Inner loop will print the value of i after each iteration  
    for j in range(i):  
        print(i, end=" ")  # print number  
    # line after each row to display pattern correctly  
    print(" ")  

# COMMAND ----------

# MAGIC %md
# MAGIC #### 25. Half pyramid pattern with the number

# COMMAND ----------

rows = 10
  
# This will print the rows  
for i in range(1, rows+1):  
    # This will print number of column  
    for j in range(1, i + 1):  
        print(j, end=' ')  
    print("")  

# COMMAND ----------

# MAGIC %md
# MAGIC #### 26. Inverted Pyramid Pattern

# COMMAND ----------

rows = 10
k = 0  
# Reversed loop for downward inverted pattern  
for i in range(rows, 0, -1):  
    # Increment in k after each iteration  
    k += 1  
    for j in range(1, i + 1):  
        print(k, end=' ')  
    print()

# COMMAND ----------

# MAGIC %md
# MAGIC #### 27.  Same number Inverted Pyramid

# COMMAND ----------

rows = 10
# rows value assign to n variable  
n = rows  
# Download reversed loop  
for i in range(rows, 0, -1):  
    for j in range(0, i):  
        # this will print the same number  
        print(n, end=' ')  
    print()  

# COMMAND ----------

# MAGIC %md
# MAGIC #### 28. Descending Order of Number

# COMMAND ----------

rows = 10 
# Downward loop for inverse loop  
for i in range(rows, 0, -1):  
    n = i   # assign value to n of i after each iteration  
    for j in range(0, i):  
        # print reduced value in each new line  
        print(n, end=' ')  
    print("\r")

# COMMAND ----------

# MAGIC %md
# MAGIC #### 29. Print 1 to 10 numbers in Pattern

# COMMAND ----------

current_Number = 1  
stop = 2  
rows = 3  # Number of rows to print numbers  
  
for i in range(rows):  
    for j in range(1, stop):  
        print(current_Number, end=' ')  
        current_Number += 1  
    print("")  
    stop += 2 

# COMMAND ----------

# MAGIC %md
# MAGIC #### 30. Reverse Pattern from 10 to 1

# COMMAND ----------

rows = 10  
for i in range(0, rows + 1):  
    # inner loop for decrement in i values  
    for j in range(rows - i, 0, -1):  
        print(j, end=' ')  
    print() 

# COMMAND ----------

# MAGIC %md
# MAGIC #### 31. Square Pattern using with number

# COMMAND ----------

rows = 10
for i in range(1, rows + 1):  
    for j in range(1, rows + 1):  
        # Check condition if value of j is smaller or equal than  
        # the j then print i otherwise print j  
        if j <= i:  
            print(i, end=' ')  
        else:  
            print(j, end=' ')  
    print()  

# COMMAND ----------

# MAGIC %md
# MAGIC #### 32. Multiplication Number in Column

# COMMAND ----------

rows = 10  
for i in range(1, rows):  
    for j in range(1, i + 1):  
        # It prints multiplication or row and column  
        print(i * j, end='  ')  
    print() 

# COMMAND ----------

# MAGIC %md
# MAGIC #### 33. Right-angled pattern with characters

# COMMAND ----------

print("The character pattern ")  
asciiValue = 65     #ASCII value of A  
for i in range(0, 5):  
    for j in range(0, i + 1):  
        # It will convert the ASCII value to the character  
        alphabate = chr(asciiValue)  
        print(alphabate, end=' ')  
        asciiValue += 1  
    print()  

# COMMAND ----------

# MAGIC %md
# MAGIC ##### This program shows an example of selection sort
# MAGIC

# COMMAND ----------

#Selection sort iterates all the elements and if the smallest element in the list is found then that number
#is swapped with the first

#Best O(n^2); Average O(n^2); Worst O(n^2)

def selectionSort(List):
    for i in range(len(List) - 1): #For iterating n - 1 times
        minimum = i
        for j in range( i + 1, len(List)): # Compare i and i + 1 element
            if(List[j] < List[minimum]):
                minimum = j
        if(minimum != i):
            List[i], List[minimum] = List[minimum], List[i]
    return List

List = [3, 4, 2, 6, 5, 7, 1, 9]
print('Sorted List:',selectionSort(List))

# COMMAND ----------

# MAGIC %md
# MAGIC #### This program checks for the character frequency in the given string
# MAGIC

# COMMAND ----------

#This program checks for the character frequency in the given string

def charFrequency(userInput):
    '''This fuction helps to count the char frequency in the given string '''
    userInput = userInput.lower() #covert to lowercase
    dict = {}
    for char in userInput:
        keys = dict.keys()
        if char in keys:
            dict[char] += 1
        else:
            dict[char] = 1
    return dict

userInput = 'This is sample string'
print(charFrequency(userInput))

# COMMAND ----------

# MAGIC %md
# MAGIC #### This program converts the given binary number to its decimal equivalent
# MAGIC

# COMMAND ----------


def binaryToDecimal(binary):
    '''This function calculates the decimal equivalent to given binary number'''
    binary1 = binary
    decimal, i, n = 0, 0, 0
    while(binary != 0):
        dec = binary % 10
        decimal = decimal + dec * pow(2, i)
        binary = binary//10
        i += 1
    print('Decimal equivalent of {} is {}'.format(binary1, decimal))

userInput = 100
binaryToDecimal(userInput)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Program to convert decimal to its equivalent binary
# MAGIC

# COMMAND ----------


def decimalToBinary(n):
  """
   unction to print binary number for the input decimal using recursion
   """
  if n > 1:
    decimalToBinary(n//2)
    print(n % 2,end = '')
    
#Enter the decimal number to find its binary equivalent:
userInput = 534
decimalToBinary(userInput)
print()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### This program counts the vowels present in the user input
# MAGIC

# COMMAND ----------

def countVowels(sentence):
    '''This function counts the vowels'''
    count = 0
    sentence = sentence.lower()
    for c in sentence:
        if c in ['a', 'e', 'i', 'o', 'u']:
            count += 1
    return count


userInput = "Enter the string to check for vowels"
count = countVowels(userInput)
print('Vowel Count: ',count)

# COMMAND ----------

#  Best = Average = Worst = O(nlog(n))

def merge(a,b):
    """ Function to merge two arrays """
    c = []
    while len(a) != 0 and len(b) != 0:
        if a[0] < b[0]:
            c.append(a[0])
            a.remove(a[0])
        else:
            c.append(b[0])
            b.remove(b[0])
    if len(a) == 0:
        c += b
    else:
        c += a
    return c

# Code for merge sort
def mergeSort(x):
    """ Function to sort an array using merge sort algorithm """
    if len(x) == 0 or len(x) == 1:
        return x
    else:
        middle = len(x)//2
        a = mergeSort(x[:middle])
        b = mergeSort(x[middle:])
        return merge(a,b)

List = [3, 4, 2, 6, 5, 7, 1, 9]
print('Sorted List:',mergeSort(List))

# COMMAND ----------

#This program illustrates the example for os module in short

import os
import time

print(os.getcwd()) #Prints the current working directory

os.mkdir('newDir1')
for i in range(1,10):
    print('Here i is',i)
    os.rename('newDir' + str(i),'newDir' + str(i + 1))
    time.sleep(2)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### This program guesses the randomnly generated number
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ##### This program gives a demo of how can you pass arguments while running python programs
# MAGIC

# COMMAND ----------

#This program gives a demo of how can you pass arguments while running python programs

import sys

def arguments(a):
    '''This function prints the argruments passed while running the python program'''
    try:
        
        print('This is the name of the script:', sys.argv[0])
        print('First argument:', sys.argv[1])
        print('Second argument:', sys.argv[2])
        print(a)
    except IndexError:
        print('Give only two arguments')
        
        
arguments(33)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### This program guesses the randomnly generated number
# MAGIC ### Stopping infinite loop using `sys.exit` function

# COMMAND ----------

#This program guesses the randomnly generated number
# for exit program importing sys module
import sys
import random

def guess(num):
    ''' This function guesses the randomnly generated number '''
    randomNumber = random.randint(0, 21)
    count = 0

    while True:
        count += 1
        number = num
        if number < randomNumber:
            print('Too small')
        elif number > randomNumber:
            print('Too large ',number)
            if count<20:
              sys.exit("exiting python program from infine loop")
            
        else:
            print('You have got it in', count, 'tries')
            break
            
            

guess(55)

 
 