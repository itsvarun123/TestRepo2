# Databricks notebook source
gv_anme=33
SOURCE_FILE_LOCATION='/FileStore/tables'
TARGET_FILE_LOCATION='/tmp/files'