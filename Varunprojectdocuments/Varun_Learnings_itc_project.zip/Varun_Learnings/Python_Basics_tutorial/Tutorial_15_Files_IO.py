# Databricks notebook source
# MAGIC %md
# MAGIC #### File Handling
# MAGIC * The key function for working with files in Python is the open() function.
# MAGIC
# MAGIC * The open() function takes two parameters; filename, and mode.
# MAGIC * There are four different methods (modes) for opening a file
# MAGIC
# MAGIC * * "r" - Read - Default value. Opens a file for reading, error if the file does not exist
# MAGIC
# MAGIC * * "a" - Append - Opens a file for appending, creates the file if it does not exist
# MAGIC
# MAGIC * * "w" - Write - Opens a file for writing, creates the file if it does not exist
# MAGIC
# MAGIC * * "x" - Create - Creates the specified file, returns an error if the file exists

# COMMAND ----------

# MAGIC
# MAGIC %md
# MAGIC * Open a file
# MAGIC * Read or write (perform operation)
# MAGIC * Close the file

# COMMAND ----------

# MAGIC %fs ls file:/tmp/abc.txt

# COMMAND ----------

with open("/tmp/abc.txt") as readfile:
  print(readfile.read())
  readfile.close()

# COMMAND ----------

with open("/tmp/abc.txt","x") as textfile:
  textfile.write("this is sample text file and i am writing some text data here")
  textfile.write("this is another line")
  #textfile.close()
  # a- append will allow if file is available or not (appending)
  # w- overwrite will allow if file is available or not (overwriting)
  # x-creation will allow only if file is not available -if file available it will throw exception

# COMMAND ----------

# MAGIC %fs ls file:/tmp/samplenewfile2.txt
# MAGIC
# MAGIC

# COMMAND ----------

dbutils.fs.head("file:/tmp/newfile.txt")

# COMMAND ----------

with open("/tmp/newfile.txt","r") as readfile:
  readfile.read()
  readfile.close()

# COMMAND ----------

data = " this is sample data file "
with open("/tmp/sample.txt","x") as fwrite:
  fwrite.write(data)
  fwrite.write("This is another line of data")
  #fwrite.read()
  fwrite.close()

# COMMAND ----------



# COMMAND ----------

f = open("myfile.txt")      # equivalent to 'r' or 'rt'
f = open("myfile.txt",'w')  # write in text mode 

# COMMAND ----------

f = open("/demofile2.txt", "w")
f.write("Now the file has more content! its append method or mode  \n")
f.write("this is another line writing into file using append mode")
f.close()

# COMMAND ----------

# MAGIC %fs ls file:/demofile2.txt

# COMMAND ----------

# MAGIC %md
# MAGIC #### File operation methods 
# MAGIC * write() - writing data
# MAGIC * read()  -  reading data
# MAGIC * close() - closing opend file

# COMMAND ----------

#open and read the file after the appending:
f = open("/demofile2.txt")
print(f.read())
f.close()

# COMMAND ----------

#open and read the file after the appending:
f = open("demofile2.txt","r")
print(f.readline())
f.close()

# COMMAND ----------

f = open("demofile.txt", "r")
print(f.read())

# COMMAND ----------

f = open("D:\\myfiles\welcome.txt", "r")
print(f.read())

# COMMAND ----------

f = open("demofile.txt", "r")
print(f.read(5))

# COMMAND ----------

# MAGIC %sh
# MAGIC %sql
# MAGIC %scala
# MAGIC %r
# MAGIC %python
# MAGIC %md
# MAGIC %fs

# COMMAND ----------

# MAGIC %fs - databricks distributed file system command
# MAGIC # dbutils.fs. - databricks distributed file system command same as hadoop file system (hdfs- fs -cp,rm,mkdirs,mv,head...)

# COMMAND ----------

# os commans
import os

# COMMAND ----------

#previous command
status='success'

# COMMAND ----------

if status=='success':
  