# Databricks notebook source
#lists
##single list can have multiple datatypes
alist=["1","2",3,4,5,["pak","eng"],True,("hello","world")]
print(alist)
type(alist)

# COMMAND ----------

##append():can add any one element to last index
list_1=["khi","lhr","quta","isl","pshwr"]
list_1.append("gwdr")
print(list_1)

# COMMAND ----------

#exetnd():can add multiple items in a list ata time
list_1.extend(["fsl","mult","hyd"])
print(list_1)


# COMMAND ----------

#sort(): arrange in alphabetical order
list_1.sort()
print(list_1)


# COMMAND ----------

#sort(reverese=true) :arranges in alpha order (reverse)
list_1.sort(reverse=True)
print(list_1)

# COMMAND ----------

#.pop(): deletes last item of list
a=list_1.pop()
print(a)
print(list_1)

# COMMAND ----------

#deletes  element at a particular index
del list_1[4]
print(list_1)

# COMMAND ----------

#index(): gives index of particular element
print(list_1.index("isl"))

# COMMAND ----------

#max() gives maximum of the list
print(max(list_1))

# COMMAND ----------

#pops 2nd index element of list
print(list_1.pop(2))

# COMMAND ----------

#checking something
if "pshwr" in list_1:
  print('True');
else:
  print('False');

# COMMAND ----------

#count(): counting occourrences of particular elements
print(list_1.count("isl"))

# COMMAND ----------

#insert(ind,elem) inserts at given position
list_1.insert(4,"insert")
print(list_1)


# COMMAND ----------

#remove(): removes any particular element
list_1.remove("isl")
print(list_1)


# COMMAND ----------

#to iterate  in list
for i in list_1:
 print(f"THE CITIES ARE: {i}")
for i in list_1:
 print("THE CITIES ARE:",i)

# COMMAND ----------

#to have all iterated elemrnts also in a list
lab=[]
for i in list_1:
    lab.append(i)
print(lab)

# COMMAND ----------

a=55
b=66
if a!=55:
  print('print A value : ',a)
else:
  print('print B Value : ',b)

# COMMAND ----------

a=5
for i in range(0,a):
  for j in range(0,i+1):
    print("*",end="")
  print("\r")

# COMMAND ----------

a=5
for i in range(a,-1,-1):
  for j in range(0,i+1):
    print("*",end="")
  print("\r")

# COMMAND ----------

rows = 6
for num in range(rows):
    for i in range(num):
        print(num, end=" ")  # print number
    # line after each row to display pattern correctly
    print(" ")

# COMMAND ----------

n = 5
for i in range(1, n+1):
    for j in range(1, i + 1):
        print(j, end=' ')
    print("")

# COMMAND ----------

rows = 5
b = 0
for i in range(rows, 0, -1):
    b += 1
    for j in range(1, i + 1):
        print(b, end=' ')
    print('\r')

# COMMAND ----------

rows = 5
num = rows
for i in range(rows, 0, -1):
    for j in range(0, i):
        print(num, end=' ')
    print("\r")

# COMMAND ----------

rows = 5
for i in range(rows, 0, -1):
    num = i
    for j in range(0, i):
        print(num, end=' ')
    print("\r")

# COMMAND ----------

rows = 5
for i in range(rows, 0, -1):
    for j in range(0, i + 1):
        print(j, end=' ')
    print("\r")

# COMMAND ----------

rows = 9
for i in range(1, rows):
    for j in range(-1+i, -1, -1):
        print(format(2**j, "4d"), end=' ')
    print("")

# COMMAND ----------

rows = 9
for i in range(1, rows):
    for i in range(0, i, 1):
        print(format(2 ** i, "4d"), end=' ')
    for i in range(-1 + i, -1, -1):
        print(format(2 ** i, "4d"), end=' ')
    print("")

# COMMAND ----------

a=5
for i in range(a,-1,-1):
  for k in (i,0):
    print(end="")
    for j in range(0,i+1):
      print("*",end="")
    print("\r")
    

# COMMAND ----------

set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}
print(set1.union(set2))

# COMMAND ----------

,0