# Databricks notebook source
# MAGIC %md
# MAGIC This is sample Markdown text which we can use for giving information 

# COMMAND ----------

# MAGIC %run
# MAGIC

# COMMAND ----------

var ="this is sample python variable"
print(var)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- this is sample sql script which we can use for listing databases
# MAGIC show databases
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC This is a *markdown* cell.
# MAGIC
# MAGIC To create a markdown cell you need to use a **"magic"** command which is the short name of a Databricks magic command. 
# MAGIC
# MAGIC Magic commands start with ``%``. 
# MAGIC
# MAGIC The magic for markdown is `%md`. 
# MAGIC
# MAGIC The magic commmand must always be the first text within the cell.
# MAGIC
# MAGIC The following provides the list of supported magics:
# MAGIC * `%python` - Allows you to execute **Python** code in the cell.
# MAGIC * `%r` - Allows you to execute **R** code in the cell.
# MAGIC * `%scala` - Allows you to execute **Scala** code in the cell.
# MAGIC * `%sql` - Allows you to execute **SQL** statements in the cell.
# MAGIC * `sh` - Allows you to execute **Bash Shell** commmands and code in the cell.
# MAGIC * `fs` - Allows you to execute **Databricks Filesystem** commands in the cell.
# MAGIC * `md` - Allows you to render **Markdown** syntax as formatted content in the cell.
# MAGIC * `run` - Allows you to **[run another notebook](https://docs.azuredatabricks.net/user-guide/notebooks/notebook-use.html#run-a-notebook-from-another-notebook)** from a cell in the current notebook.
# MAGIC
# MAGIC To read more about magics see [here](https://docs.azuredatabricks.net/user-guide/notebooks/notebook-use.html#develop-notebooks).

# COMMAND ----------

# MAGIC %md ## Running multiple notebook cells

# COMMAND ----------

# MAGIC %md It is not uncommon to need to run (or re-run) a subset of all notebook cells in top to bottom order.
# MAGIC
# MAGIC There are a few ways you can accomplish this. You can:
# MAGIC - Run all cells in the notebook. Select __`Run All`__ in the notebook toolbar to run all cells starting from the first.
# MAGIC - Run cells above or below your current cell. To run all cells above or below a cell, go to the cell actions menu at the far right, select Run Menu, and then select Run All Above or Run All Below. ![](https://docs.azuredatabricks.net/_images/cmd-run.png)

# COMMAND ----------

# MAGIC %md ### Keyboard shortcuts for adding and removing cells

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC When a cell is in command mode press the following keys:
# MAGIC
# MAGIC * `A` (insert a cell above)
# MAGIC * `B` (insert a cell below)
# MAGIC * `D`,`D` (delete current cell)
# MAGIC
# MAGIC Try the following in your notebook:
# MAGIC 1. Insert a cell below this cell (`B`)
# MAGIC 2. Insert a cell above that new cell (`Esc`, `A`)
# MAGIC 3. Delete both new cells (`Esc`, `D`,`D`)

# COMMAND ----------

# MAGIC %md ### Adding and removing cells using the UI

# COMMAND ----------

# MAGIC %md You can also add and remove cells using the UI. 
# MAGIC
# MAGIC To add a cell, mouse over a cell at the top or bottom and click the ![Add Cell icon](https://docs.azuredatabricks.net/_images/add-cell.png).
# MAGIC
# MAGIC Alternately, access the notebook cell menu at the far right, select the down `caret`, and select `Add Cell Above` or `Add Cell Below` ![](https://docs.azuredatabricks.net/_images/cmd-edit.png)
# MAGIC
# MAGIC  

# COMMAND ----------

# MAGIC %md ## Understanding notebook state

# COMMAND ----------

# MAGIC %md When you execute notebook cells, their execution is backed by a process running on a cluster. The state of your notebook, such as the values of variables, is maintained in the process. All variables default to a global scope (unless you author your code so it has nested scopes) and this global state can be a little confusing at first when you re-run cells.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Clearing state and output
# MAGIC
# MAGIC You can use the **Clear** dropdown on the notebook toolbar remove output (results) or remove output and clear the underlying state. ![](https://docs.databricks.com/_images/clear-notebook.png)
# MAGIC
# MAGIC * Clear -> Clear Results (removes the displayed output for all cells)
# MAGIC * Clear -> Clear State (removes all cell states)
# MAGIC
# MAGIC You typically do this when you want to cleanly re-run a notebook you have been working on and eliminate any accidental changes to the state that may have occured while you were authoring the notebook.
# MAGIC
# MAGIC Read more about execution context [here](https://docs.azuredatabricks.net/user-guide/notebooks/notebook-use.html#run-notebooks).
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Introduction to Spark RDD
# MAGIC

# COMMAND ----------

rdd = sc.parallelize([1,2,3,4,5])
rdd.collect()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Introducing Spark DataFrames
# MAGIC

# COMMAND ----------

df = spark.range(1000).toDF("number")
print(display(df))
df_person = spark.createDataFrame([(1,'Ravi','Bangalore'),(2,'Raj','Chennai'), (3,'Vikrnath','Hyderabad'),(4,'Reshwanth','Pune')],["id","name","loc"])
print(display(df_person))

# COMMAND ----------

df.describe().show()