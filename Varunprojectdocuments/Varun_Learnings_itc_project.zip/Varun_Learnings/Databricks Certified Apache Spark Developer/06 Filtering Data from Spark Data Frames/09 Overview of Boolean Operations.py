# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC Boolean Operations
# MAGIC * Boolean OR
# MAGIC * Boolean AND
# MAGIC * Negation

# COMMAND ----------

True or True

# COMMAND ----------

True or False

# COMMAND ----------

False or True

# COMMAND ----------

False or False

# COMMAND ----------

True and True

# COMMAND ----------

False and True

# COMMAND ----------

True and False

# COMMAND ----------

False and False

# COMMAND ----------

not True

# COMMAND ----------

not False