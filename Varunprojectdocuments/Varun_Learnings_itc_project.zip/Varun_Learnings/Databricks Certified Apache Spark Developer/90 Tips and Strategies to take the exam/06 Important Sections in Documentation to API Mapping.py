# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC Here is the mapping between important sections in provided documentation to API Mapping.
# MAGIC * `pyspark.sql.functions`