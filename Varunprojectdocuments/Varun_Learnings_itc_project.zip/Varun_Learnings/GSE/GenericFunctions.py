# Databricks notebook source
from pyspark.sql.functions import split,when,col,to_date,unix_timestamp,expr

# COMMAND ----------

sfUtils = sc._jvm.net.snowflake.spark.snowflake.Utils
snowflake_url = dbutils.secrets.get(scope = "azurekeyvault_secretscope", key = "SnowflakeUrl") 
snowflake_username = dbutils.secrets.get(scope = "azurekeyvault_secretscope", key = "SnowflakeUsername") 
snowflake_password = dbutils.secrets.get(scope = "azurekeyvault_secretscope", key = "SnowflakePassword") 
snowflake_database = dbutils.secrets.get(scope = "azurekeyvault_secretscope", key = "SnowflakeDBname") 
snowflake_warehouse = dbutils.secrets.get(scope = "azurekeyvault_secretscope", key = "SnowflakeWHname")
snowflake_schemaname = dbutils.secrets.get(scope = "azurekeyvault_secretscope", key = "SnowflakeSchemaName")

# snowflake connection options

scoptions = {
  "sfUrl": snowflake_url,
  "sfUser": snowflake_username,
  "sfPassword": snowflake_password,
  "sfDatabase": snowflake_database,
  "sfSchema": snowflake_schemaname,
  "sfWarehouse": snowflake_warehouse,
  "truncate_table" : "ON",
  "usestagingtable" : "OFF"
}

# COMMAND ----------

def get_run_date(wf_id):
    _date_=sqlContext.read.format("net.snowflake.spark.snowflake").options(**scoptions).option("query" , f"SELECT translate(cast(dateadd(day,1,LAST_RUN_DATE) as String),'-','') as run_date from AUDIT.SNAPSHOT_CONTROL where WF_ID='{wf_id}'").load().first()['RUN_DATE']
    print(int(_date_))
    return int(_date_)

# COMMAND ----------

databricks_url = dbutils.secrets.get(scope = "azurekeyvault_secretscope", key = "dbworkspaceurl")

def get_url():
  import json
  context_str = dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson()
  context = json.loads(context_str)
  run_id_obj = context.get('currentRunId', {})
  run_id = run_id_obj.get('id', None) if run_id_obj else None
  job_id = context.get('tags', {}).get('jobId', None)  
  return f"{databricks_url}#job/{job_id}/run/1"

def update_tracking_url(task_id,run_date,tracking_url):
  sfUtils.runQuery(scoptions, f"""Update AUDIT.WORKFLOW_TASK_DETAILS  
  set TRACKING_URL='{tracking_url}',UPDATED_DATE=current_timestamp WHERE TASK_ID='{task_id}' and RUN_DATE={run_date}""")
  
# run_date=get_run_date("WF0001")
# tracking_url=get_url()
# update_tracking_url("WF0001_01",20210111,tracking_url)
  