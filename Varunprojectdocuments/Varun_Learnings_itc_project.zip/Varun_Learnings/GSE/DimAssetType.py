# Databricks notebook source
wf_id=dbutils.widgets.get("wf_id")
task_id=dbutils.widgets.get("task_id")

# COMMAND ----------

# MAGIC %run ./GenericFunctions

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC alter table unifi_hr_bronze.asset_type recover partitions;
# MAGIC REFRESH table unifi_hr_bronze.asset_type; 

# COMMAND ----------

#run_date=20220215

run_date=get_run_date(wf_id)
tracking_url=get_url()
update_tracking_url(task_id,run_date,tracking_url)


# COMMAND ----------

key=spark.sql("""select nvl(max(AssetType_Skey),1000) as max_skey from unifi_hr_gold.DimGSEAssetType""").first()['max_skey']

# COMMAND ----------

spark.sql(f"""

SELECT 
Distinct
a1.AssetType,
a1.LegacyType,
a1.subcategory,
to_date(substring(a1.Assetworks_InsertDate,1,8),'yyyyMMdd') Assetworks_InsertDate ,
current_timestamp() CreatedDate,
cast(null as timestamp) UpdatedDate,
a1.load_date
from unifi_hr_bronze.asset_type a1 Left outer join unifi_hr_gold.DimGSEAssetType a2
on(a1.AssetType= a2.ASSET_TYPE and a1.LegacyType = a2.LEGACY_TYPE and a1.subcategory = a2.SUBCATEGORY  )
where a1.load_date={run_date}

--and  a1.AssetType in ('RAIL') 

""").createOrReplaceTempView('AssetTypetemp')


# COMMAND ----------

delete_df=spark.sql(f"""
delete from unifi_hr_gold.DimGSEAssetType
 where to_date(createdDate) = to_date (CURRENT_TIMESTAMP) AND load_date = {run_date}
""")

display(delete_df)

# revert_df=spark.sql(f"""
# update unifi_hr_gold.DimGSEAssetType 
#   SET EffectiveToDate = to_date('2199-12-31'),
#       UpdatedDate = CURRENT_TIMESTAMP
#       where  to_date(UpdatedDate) = to_date (CURRENT_TIMESTAMP) AND EffectiveToDate = date_add (to_date(CAST({run_date} AS string),'yyyyMMdd'),-1)
# """)

# display(revert_df)

# COMMAND ----------

update_df=spark.sql(f"""

MERGE INTO unifi_hr_gold.DimGSEAssetType A1
USING AssetTypetemp T1 on (A1.ASSET_TYPE = T1.AssetType )
When MATCHED  THEN UPDATE
set A1.UpdatedDate=CURRENT_TIMESTAMP,
A1.LEGACY_TYPE = T1.LegacyType ,
A1.SUBCATEGORY = T1.subcategory ,
A1.Assetworks_InsertDate = T1.Assetworks_InsertDate

""")
display(update_df)



# COMMAND ----------

insert_df=spark.sql(f"""
insert into unifi_hr_gold.DimGSEAssetType
select 
{key} + monotonically_increasing_id() +1 AssetType_Skey,
a1.AssetType,
a1.LegacyType,
a1.subcategory,
a1. Assetworks_InsertDate ,
current_timestamp() CreatedDate,
cast(null as timestamp) UpdatedDate,
a1.load_date
from AssetTypetemp a1 Left outer join unifi_hr_gold.DimGSEAssetType a2
on(a1.AssetType= a2.ASSET_TYPE)
where a2.ASSET_TYPE is null

         """)

display(insert_df)

# COMMAND ----------

snowflaketable_df=spark.sql("select * from unifi_hr_gold.DimGSEAssetType")

# COMMAND ----------

snowflaketable_df.write.format("snowflake").options(**scoptions).option("dbtable", "EDW.DimGSEAssetType").mode("overwrite").save()

# COMMAND ----------

dbuutils