# Databricks notebook source
wf_id=dbutils.widgets.get("wf_id")
task_id=dbutils.widgets.get("task_id")

# COMMAND ----------

# MAGIC %run ./GenericFunctions

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC alter table unifi_hr_bronze.GseProvider recover partitions;
# MAGIC REFRESH table unifi_hr_bronze.GseProvider;

# COMMAND ----------

# run_date =20220308

run_date=get_run_date(wf_id)
tracking_url=get_url()
update_tracking_url(task_id,run_date,tracking_url)


# COMMAND ----------

key=spark.sql("""select nvl(max(Provider_skey),1000) as max_skey from unifi_hr_gold.DimGseProvider""").first()['max_skey']

# COMMAND ----------

spark.sql(f"""

select  
Distinct
nvl(trim(split(RM,'/')[0]),'-1') as RegionManager ,
nvl(trim(split((split((split(a1.RM,'/')[1]),'\n ')[0]),'\n')[0]),'-1') as RMPhone ,
nvl(trim(split((split((split(a1.RM,'/')[1]),'\n ')[0]),'\n')[1]),'-1') as RMEmail ,
--nvl(trim(a1.Station),'-1') as StationCode1,
explode(split(trim(STATION),'/')) as StationCode,
nvl(trim(a1.Address),'-1') as Address ,
nvl(trim(a1.ContactsMechanics),'-1') as MechanicContact ,
nvl(trim(a1.ContactsVendors),'-1') as VendorContact ,
a1.Load_date as load_date
from unifi_hr_bronze.GseProvider a1
where a1.load_date={run_date}
""").createOrReplaceTempView('GseProvidertemp')

# COMMAND ----------

spark.sql(f"""

select  

distinct
nvl(a1.RegionManager,'-1') as RegionManager ,
nvl(a1.RMPhone,'-1') as RMPhone ,
nvl(a1.RMEmail,'-1') as RMEmail  ,
a1.StationCode as StationCode ,
p1.StationCode as finbus_stationCode ,
nvl(trim(bs.CostCenter),'-1') as CostCenter ,
nvl(trim(bs.ServiceTypeCode),'-1') as ServiceTypeCode,
nvl(trim(bs.CustomerCode),'-1') as CustomerCode,
nvl(trim(bs.ContractCode),'-1') as ContractCode,
nvl(bs.BS_Finance_Skey,'-1') as BS_Finance_Skey ,
nvl(a1.Address,'-1') as Address ,
nvl(a1.MechanicContact,'-1') as MechanicContact ,
nvl(a1.VendorContact,'-1') as VendorContact ,
bs.EffectiveFromDate as DimFinEff_fromDate ,
bs.EffectiveToDate as DimFinEff_ToDate ,
current_timestamp() CreatedDate,
cast(null as timestamp) UpdatedDate,
a1.load_date ,
case
    when 
    nvl(trim(a1.StationCode),'-1') = nvl(trim(p1.StationCode),'-1')
    and  nvl(trim(a1.RegionManager),'-1') = p1.RegionManager
    and nvl(trim(a1.RMPhone),'-1') = p1.RMPhone
    and nvl(trim(a1.RMEmail),'-1') = p1.RMEmail
    and  nvl(trim(bs.CostCenter),'-1') = nvl(trim(p1.CostCenter),'-1')
    and  nvl(trim(bs.ServiceTypeCode),'-1') = nvl(trim(p1.ServiceTypeCode),'-1')
    and  nvl(trim(bs.CustomerCode),'-1') = nvl(trim(p1.CustomerCode),'-1')
    and  nvl(trim(bs.ContractCode),'-1') = nvl(trim(p1.ContractCode),'-1')
    and  nvl(trim(a1.Address),'-1') = nvl(trim(p1.Address),'-1')
    and  nvl(trim(a1.MechanicContact),'-1') = nvl(trim(p1.MechanicContact),'-1')
    and  nvl(trim(a1.VendorContact),'-1') = nvl(trim(p1.VendorContact),'-1')
    then 1 
    else 0
    end as update_status
from GseProvidertemp a1

left outer join unifi_hr_gold.DimFinanceBusinessStructure bs  on (nvl(trim(a1.StationCode),'-1') = nvl(trim(bs.StationCode),'-1') and  bs.EffectiveToDate='2199-12-31')
Left Outer join unifi_hr_gold.DimGseProvider p1 on (
                                                   trim(a1.RegionManager)=p1.RegionManager and
                                                   trim(a1.RMPhone)=p1.RMPhone and
                                                   trim(a1.RMEmail)=p1.RMEmail and
                                                    nvl(trim(a1.StationCode),'-1')= nvl(trim(p1.StationCode),'-1') and 
                                                    nvl(bs.CostCenter,'-1')= nvl(p1.CostCenter,'-1')  and 
                                                     nvl(bs.ServiceTypeCode,'-1') = p1.ServiceTypeCode and
                                                    nvl( bs.CustomerCode,'-1') = p1.CustomerCode and
                                                   nvl(bs.ContractCode,'-1') = p1.ContractCode and
                                                     nvl(trim(a1.Address),'-1')=p1.Address  and
                                                     nvl(trim(a1.MechanicContact),'-1') = p1.MechanicContact and
                                                      nvl(trim(a1.VendorContact),'-1') = p1.VendorContact
                                                      )
 where a1.load_date={run_date} 
 

""").createOrReplaceTempView('Providertemp')

# COMMAND ----------

delete_df=spark.sql(f"""
delete from unifi_hr_gold.DimGseProvider
 where to_date(createdDate) = to_date (CURRENT_TIMESTAMP) AND load_date = {run_date}
""")

display(delete_df)

# revert_df=spark.sql(f""" 
# update unifi_hr_gold.FactGSEEquipmentJob 
#   SET EffectiveToDate = to_date('2199-12-31'),
#       UpdatedDate = CURRENT_TIMESTAMP
#       where  to_date(UpdatedDate) = to_date (CURRENT_TIMESTAMP) AND EffectiveToDate = date_add (to_date(CAST({run_date} AS string),'yyyyMMdd'),-1)
# """)

# display(revert_df)

# COMMAND ----------


updatefinal_df = spark.sql(
  '''
  
  MERGE INTO unifi_hr_gold.DimGseProvider p1
  USING Providertemp t1 
 ON p1.StationCode = t1.StationCode and p1.CostCenter=t1.costcenter and  t1.BS_Finance_Skey = p1.BS_Finance_Skey
             
WHEN MATCHED and t1.update_status=0 THEN 
     UPDATE SET 
       p1.IsLatest = 0,
       p1.UpdatedDate = current_timestamp 
       
  ''')
display(updatefinal_df)

# COMMAND ----------

insert_df=spark.sql(f"""
insert into   unifi_hr_gold.DimGseProvider

select 
{key} + monotonically_increasing_id() +1 Provider_skey ,
RegionManager ,
RMPhone ,
RMEmail ,
StationCode ,
CostCenter ,
ServiceTypeCode,
CustomerCode,
ContractCode,
BS_Finance_Skey ,
Address ,
MechanicContact ,
VendorContact ,
DimFinEff_fromDate ,
DimFinEff_ToDate ,
1 as IsLatest,
current_timestamp() CreatedDate,
cast(null as timestamp) UpdatedDate,
load_date 
from 
Providertemp t where t.update_status=0

""")

display(insert_df)

# COMMAND ----------

snowflaketable_df=spark.sql("select * from unifi_hr_gold.DimGseProvider")

# COMMAND ----------

snowflaketable_df.write.format("snowflake").options(**scoptions).option("dbtable", "EDW.DimGseProvider").mode("overwrite").save()