# Databricks notebook source
wf_id=dbutils.widgets.get("wf_id")
task_id=dbutils.widgets.get("task_id")

# COMMAND ----------

# MAGIC %run ./GenericFunctions

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC alter table unifi_hr_bronze.GseEquipmentjob recover partitions;
# MAGIC REFRESH table unifi_hr_bronze.GseEquipmentjob;

# COMMAND ----------

#run_date=20220216

run_date=get_run_date(wf_id)
tracking_url=get_url()
update_tracking_url(task_id,run_date,tracking_url)


# COMMAND ----------

key=spark.sql("""select nvl(max(EquipmentJob_skey),1000) as max_skey from unifi_hr_gold.FactGSEEquipmentJob""").first()['max_skey']

# COMMAND ----------

spark.sql(f"""

select  
distinct
nvl(trim(a1.EQ_EQUIP_NO),'-1') as EQUIPMENT_NUMBER ,
to_date(substring(a1.DATETIME_CLOSED,1,8),'yyyyMMdd') as ClosedDate ,
nvl(dt.Date_Skey,-1) as ClosedDate_skey ,
to_date(substring(a1.DATETIME_DUE,1,8),'yyyyMMdd') as DueDate ,
nvl(dt1.Date_Skey,-1) as DueDate_skey ,
to_date(substring(a1.DATETIME_ESTIMATE,1,8),'yyyyMMdd') as EstimateDate ,
nvl(dt2.Date_Skey,-1) as EstimateDate_skey , 
to_date(substring(a1.DATETIME_EST_APPROVD,1,8),'yyyyMMdd') as ApprovedDate ,
nvl(dt3.Date_Skey,-1) as ApprovedDate_Skey , 
to_date(substring(a1.DATETIME_FINISHED,1,8),'yyyyMMdd') as FinishedDate ,
nvl(dt4.Date_Skey,-1) as FinishedDate_skey , 
to_date(substring(a1.DATETIME_IN_SERVICE,1,8),'yyyyMMdd') as ServiceInDate ,
nvl(dt5.Date_Skey,-1) as ServiceInDate_skey , 
to_date(substring(a1.DATETIME_OUT_SERVICE,1,8),'yyyyMMdd') as ServiceOutDate ,
nvl(dt6.Date_Skey,-1) as ServiceOutDate_skey , 
to_date(substring(a1.DATETIME_PM_SCHED,1,8),'yyyyMMdd') as PM_ScheduledDate ,
nvl(dt7.Date_Skey,-1) as PM_ScheduledDate_skey , 
to_date(substring(a1.DATETIME_UNIT_IN,1,8),'yyyyMMdd') as UnitInDate ,
nvl(dt8.Date_Skey,-1) as UnitInDate_skey , 
to_date(substring(a1.DATE_PM_NEXT_DUE,1,8),'yyyyMMdd') as PM_NextDueDate ,
nvl(dt9.Date_Skey,-1) as PM_NextDueDate_skey , 
nvl(trim(a1.EQUIP_STATUS_CODE),'-1') as  STATUS_CODE ,
nvl(trim(a1.WORK_ORDER_NO),'-1') as Work_OrderNo ,
nvl(trim(a1.WORK_ORDER_STATUS),'-1') as WO_Status ,
nvl(trim(a1.X_DATETIME_INSERT),'-1') as DatetimeInsert ,
nvl(trim(a1.X_DATETIME_UPDATE),'-1') as DatetimeUpdate ,
nvl(trim(ec.AssetName),'-1') as AssetName ,
nvl(trim(ec.CostCenter),'-1') as CostCenter,
nvl(trim(ec.StationCode),'-1')  as StationCode,
nvl(trim(ec.ServiceTypeCode),'-1') as ServiceTypeCode,
nvl(trim(ec.CustomerCode),'-1') as CustomerCode,
nvl(trim(ec.ContractCode),'-1') as ContractCode,
nvl(ec.BS_Finance_Skey,'-1') as BS_Finance_Skey ,
current_timestamp() CreatedDate,
cast(null as timestamp) UpdatedDate,
a1.load_date ,
case
    when trim(a1.EQ_EQUIP_NO) = e1.EQUIPMENT_NUMBER
   -- and to_date(substring(a1.DATETIME_CLOSED,1,8),'yyyyMMdd')= e1.ClosedDate
   -- and to_date(substring(a1.DATETIME_DUE,1,8),'yyyyMMdd')= e1.DueDate
   -- and to_date(substring(a1.DATETIME_ESTIMATE,1,8),'yyyyMMdd')= e1.EstimateDate
   -- and to_date(substring(a1.DATETIME_EST_APPROVD,1,8),'yyyyMMdd')= e1.ApprovedDate
   -- and to_date(substring(a1.DATETIME_FINISHED,1,8),'yyyyMMdd')= e1.FinishedDate
   -- and to_date(substring(a1.DATETIME_IN_SERVICE,1,8),'yyyyMMdd')= e1.ServiceInDate
    -- and to_date(substring(a1.DATETIME_OUT_SERVICE,1,8),'yyyyMMdd')= e1.ServiceOutDate
   -- and to_date(substring(a1.DATETIME_PM_SCHED,1,8),'yyyyMMdd')= e1.PM_ScheduledDate
   -- and to_date(substring(a1.DATETIME_UNIT_IN,1,8),'yyyyMMdd')= e1.UnitInDate
  --  and to_date(substring(a1.DATE_PM_NEXT_DUE,1,8),'yyyyMMdd')= e1.PM_NextDueDate
    and nvl(trim(a1.EQUIP_STATUS_CODE),'-1') = nvl(trim(e1.STATUS_CODE),'-1')
    and nvl(trim(a1.WORK_ORDER_NO),'-1') = nvl(trim(e1.Work_OrderNo),'-1')
    and nvl(trim(a1.WORK_ORDER_STATUS),'-1') = nvl(trim(e1.WO_Status),'-1')
    and nvl(trim(ec.CostCenter),'-1') = nvl(e1.CostCenter,'-1')
    and nvl(trim(ec.BS_Finance_Skey),'-1') = nvl(trim(e1.BS_Finance_Skey),'-1') 
    and nvl(trim(a1.X_DATETIME_INSERT),'-1') = nvl(trim(e1.DatetimeInsert),'-1')
    and nvl(trim(a1.X_DATETIME_UPDATE),'-1') = nvl(trim(e1.DatetimeUpdate),'-1')
   then 1 
    else 0
  end as update_status
from unifi_hr_bronze.GseEquipmentjob a1
Left outer join unifi_hr_gold.DimDate dt on(to_date(substring(a1.DATETIME_CLOSED,1,8),'yyyyMMdd')=dt.Date)
Left outer join unifi_hr_gold.DimDate dt1 on(to_date(substring(a1.DATETIME_DUE,1,8),'yyyyMMdd')=dt1.Date)
Left outer join unifi_hr_gold.DimDate dt2 on(to_date(substring(a1.DATETIME_ESTIMATE,1,8),'yyyyMMdd')=dt2.Date)
Left outer join unifi_hr_gold.DimDate dt3 on(to_date(substring(a1.DATETIME_EST_APPROVD,1,8),'yyyyMMdd')=dt3.Date)
Left outer join unifi_hr_gold.DimDate dt4 on(to_date(substring(a1.DATETIME_FINISHED,1,8),'yyyyMMdd')=dt4.Date)
Left outer join unifi_hr_gold.DimDate dt5 on(to_date(substring(a1.DATETIME_IN_SERVICE,1,8),'yyyyMMdd')=dt5.Date)
Left outer join unifi_hr_gold.DimDate dt6 on(to_date(substring(a1.DATETIME_OUT_SERVICE,1,8),'yyyyMMdd')=dt6.Date)
Left outer join unifi_hr_gold.DimDate dt7 on(to_date(substring(a1.DATETIME_PM_SCHED,1,8),'yyyyMMdd')=dt7.Date)
Left outer join unifi_hr_gold.DimDate dt8 on(to_date(substring(a1.DATETIME_UNIT_IN,1,8),'yyyyMMdd')=dt8.Date)
Left outer join unifi_hr_gold.DimDate dt9 on(to_date(substring(a1.DATE_PM_NEXT_DUE,1,8),'yyyyMMdd')=dt9.Date)

Left outer join unifi_hr_gold.DimEquipmentToContract ec on( nvl(trim(a1.EQ_EQUIP_NO),'-1') = nvl(trim(ec.EQUIPMENT_NUMBER),'-1')  )
Left outer Join unifi_hr_gold.FactGSEEquipmentJob e1 on
(
nvl(trim(a1.EQ_EQUIP_NO),'-1') = nvl(trim(e1.EQUIPMENT_NUMBER),'-1')
and nvl(trim(a1.WORK_ORDER_NO),'-1') = nvl(trim(e1.Work_OrderNo),'-1')
and nvl(trim(a1.EQUIP_STATUS_CODE),'-1') = nvl(trim(e1.STATUS_CODE),'-1')
and nvl(trim(ec.CostCenter),'-1')= nvl(trim(e1.CostCenter),'-1')
and nvl(trim(a1.WORK_ORDER_STATUS),'-1') = nvl(trim(e1.WO_Status),'-1')
and nvl(trim(ec.BS_Finance_Skey),'-1') = nvl(trim(e1.BS_Finance_Skey),'-1')
and nvl(trim(a1.X_DATETIME_INSERT),'-1') = nvl(trim(e1.DatetimeInsert),'-1')
and nvl(trim(a1.X_DATETIME_UPDATE),'-1') = nvl(trim(e1.DatetimeUpdate),'-1')
)

where a1.load_date={run_date} 
and a1.EQ_EQUIP_NO is not null  and a1.EQ_EQUIP_NO <>0 and a1.WORK_ORDER_NO is not null



""").createOrReplaceTempView('Equipmentjobtemp1')




# COMMAND ----------

spark.sql(f"""

select * from 
(select *,row_number() over(partition by EQUIPMENT_NUMBER,CostCenter,Work_OrderNo,WO_Status,STATUS_CODE,BS_Finance_Skey order by DatetimeUpdate desc)as rank
from Equipmentjobtemp1  ) as a where a.rank=1

""").createOrReplaceTempView('Equipmentjobtemp')

# COMMAND ----------

delete_df=spark.sql(f"""
delete from unifi_hr_gold.FactGSEEquipmentJob
 where to_date(createdDate) = to_date (CURRENT_TIMESTAMP) AND load_date = {run_date}
""")

display(delete_df)

revert_df=spark.sql(f""" 
update unifi_hr_gold.FactGSEEquipmentJob 
  SET EffectiveToDate = to_date('2199-12-31'),
      UpdatedDate = CURRENT_TIMESTAMP
      where  to_date(UpdatedDate) = to_date (CURRENT_TIMESTAMP) AND EffectiveToDate = date_add (to_date(CAST({run_date} AS string),'yyyyMMdd'),-1)
""")

display(revert_df)

# COMMAND ----------

updatefinal_df=spark.sql(f"""

  
  MERGE INTO unifi_hr_gold.FactGSEEquipmentJob f1
  USING Equipmentjobtemp t1 
  ON ( f1.EQUIPMENT_NUMBER = t1.EQUIPMENT_NUMBER AND 
     f1.CostCenter = t1.CostCenter
     AND f1.Work_OrderNo = t1.Work_OrderNo
    -- and nvl(trim(f1.STATUS_CODE),'-1') = nvl(trim(t1.STATUS_CODE),'-1')
     and nvl(trim(f1.WO_Status),'-1') = nvl(trim(t1.WO_Status),'-1')
     and nvl(f1.BS_Finance_Skey,'-1') = nvl(t1.BS_Finance_Skey,'-1')
     and f1.DatetimeInsert = t1.DatetimeInsert
   --  and f1.DatetimeUpdate = t1.DatetimeUpdate
   and to_date(f1.EffectiveToDate) = to_date('2199-12-31')
   )
WHEN MATCHED and t1.update_status=0 THEN
     UPDATE SET f1.IsLatest = 0,
           f1.EffectiveToDate = date_add(to_date(cast({run_date} as string),'yyyyMMdd'),-1) ,
           f1.UpdatedDate=current_timestamp
       
 """)

display(updatefinal_df)


# COMMAND ----------

insert_df=spark.sql(f"""
insert into   unifi_hr_gold.FactGSEEquipmentJob

select  
{key} + monotonically_increasing_id() +1 EquipmentJob_skey ,
a1.EQUIPMENT_NUMBER ,
a1.ClosedDate,
a1.ClosedDate_skey ,
a1.DueDate ,
a1.DueDate_skey ,
a1.EstimateDate ,
a1.EstimateDate_skey , 
a1.ApprovedDate ,
a1.ApprovedDate_Skey , 
a1.FinishedDate ,
a1.FinishedDate_skey , 
a1.ServiceInDate ,
a1.ServiceInDate_skey , 
a1.ServiceOutDate ,
a1.ServiceOutDate_skey , 
a1.PM_ScheduledDate ,
a1.PM_ScheduledDate_skey , 
a1.UnitInDate ,
a1.UnitInDate_skey , 
a1.PM_NextDueDate ,
a1.PM_NextDueDate_skey , 
a1.STATUS_CODE ,
a1.Work_OrderNo , 
a1.WO_Status ,
a1.DatetimeInsert ,
a1.DatetimeUpdate ,
a1.AssetName ,
a1.CostCenter ,
a1.StationCode  as StationCode,
a1.ServiceTypeCode as ServiceTypeCode,
a1.CustomerCode as CustomerCode,
a1.ContractCode as ContractCode,
a1.BS_Finance_Skey as BS_Finance_Skey ,
1 as IsLatest ,
case WHEN (c1.EffectiveToDate) IS null THEN '2021-01-01'
 ELSE (to_date(cast({run_date} as string),'yyyyMMdd')) 
  END AS EffectiveFromDate ,
 
 '2199-12-31' as EffectiveToDate,
current_timestamp() CreatedDate,
cast(null as timestamp) UpdatedDate,
a1.load_date

from Equipmentjobtemp a1 
Left outer Join 
(Select EQUIPMENT_NUMBER,Work_OrderNo,WO_Status,CostCenter,BS_Finance_Skey,DatetimeInsert,DatetimeUpdate,MAX(EffectiveToDate) OVER (PARTITION BY EQUIPMENT_NUMBER) AS EffectiveToDate
from unifi_hr_gold.FactGSEEquipmentJob ) c1 on
(a1.EQUIPMENT_NUMBER = c1.EQUIPMENT_NUMBER
and a1.Work_OrderNo=c1.Work_OrderNo
and a1.WO_Status=c1.WO_Status
and a1.CostCenter = c1.CostCenter 
and  a1.BS_Finance_Skey = c1.BS_Finance_Skey
and a1.DatetimeInsert = c1.DatetimeInsert 
and a1.DatetimeUpdate = c1.DatetimeUpdate) 
where
  a1.update_status = 0 

""")

display(insert_df)

# COMMAND ----------

snowflaketable_df=spark.sql("select * from unifi_hr_gold.FactGSEEquipmentJob ")

# COMMAND ----------

snowflaketable_df.write.format("snowflake").options(**scoptions).option("dbtable", "EDW.FactGSEEquipmentJob").mode("overwrite").save()