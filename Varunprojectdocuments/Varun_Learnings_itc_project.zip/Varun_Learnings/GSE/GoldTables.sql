-- Databricks notebook source
Create table unifi_hr_gold.DimGSEAssetType (
AssetType_Skey	BIGINT   ,
ASSET_TYPE STRING   ,
LEGACY_TYPE STRING   ,
SUBCATEGORY STRING   ,
Assetworks_InsertDate  date ,   
CreatedDate   TIMESTAMP ,
UpdatedDate TIMESTAMP ,
Load_Date INT 
)
USING DELTA 
LOCATION "/mnt/gold/gse/assettype/";

-- COMMAND ----------


Create table unifi_hr_gold.DimGSEEquipmentMain (
EquipmentType_Skey	BIGINT   ,
ASSET_ID STRING ,
EQUIPMENT_NUMBER String ,
ASSET_TYPE STRING ,
AssetType_skey BIGINT ,
ASSET_COLOR STRING ,
ADDED_DATE STRING ,
Added_dateskey INT ,
DELIVERY_DATE STRING , 
Delivery_dateskey INT ,
EQUIPMENT_CATEGORY STRING ,
EQUIPMENT_TYPE STRING , 
SERVICEIN_DATE STRING ,
ServiceIn_dateskey INT ,
PM_LASTSCHEDULEDATE STRING ,
PM_LastSchedule_dateskey INT,
LAST_PM_SLOT STRING , 
PM_LASTSTARTDATE STRING,
PM_LastSTARTDATE_dateskey INT ,
PM_NEXTSCHEDULEDATE STRING ,
PM_NextSchedule_dateskey INT ,
ORIGINAL_COST STRING ,
PARKING_STALL STRING ,
SLA_STATUS STRING ,
WORK_ORDERS_OK STRING ,
WORK_ORDER_STATUS STRING ,
Proc_Status String ,
year STRING ,
Assetworks_InsertDate STRING ,
Assetworks_UpdateDate STRING ,
ContractCode STRING ,
Costcenter  STRING ,
IsLatest  INT ,
EffectiveFromDate  DATE ,
EffectiveToDate DATE ,
CreatedDate TIMESTAMP ,
UpdatedDate TIMESTAMP ,
Load_Date INT

)
USING DELTA 
LOCATION "/mnt/gold/gse/equipmentmain/";

-- COMMAND ----------

--Drop table unifi_hr_gold.DimEquipmentToContract ;
Create table unifi_hr_gold.DimEquipmentToContract (
EquipmentToContract_skey	BIGINT   ,
EQUIPMENT_NUMBER STRING ,
INTERNALID  STRING ,
COSTCENTER STRING ,
STATIONCODE STRING ,
SERVICETYPECODE STRING ,
CUSTOMERCODE STRING ,
CONTRACTCODE STRING ,
BS_FINANCE_SKEY BIGINT ,
ASSETNAME STRING ,
ASSETTYPE STRING ,
IsLatest  INT ,
EffectiveFromDate  DATE ,
EffectiveToDate DATE ,
CreatedDate TIMESTAMP ,
UpdatedDate TIMESTAMP ,
Load_Date INT
)
USING DELTA 
LOCATION "/mnt/gold/gse/EquipmentToContract/";

-- COMMAND ----------

-- DROP TABLE unifi_hr_gold.FactGSEEquipmentJob
create table unifi_hr_gold.FactGSEEquipmentJob
(
EquipmentJob_skey BIGINT ,
EQUIPMENT_NUMBER STRING ,
ClosedDate  STRING ,
ClosedDate_skey  INT ,
DueDate  STRING ,
DueDate_skey INT ,
EstimateDate  STRING ,
EstimateDate_skey INT , 
ApprovedDate  STRING ,
ApprovedDate_Skey INT ,
FinishedDate  STRING ,
FinishedDate_skey INT ,
ServiceInDate  STRING ,
ServiceInDate_skey INT ,
ServiceOutDate  STRING ,
ServiceOutDate_skey INT ,
PM_ScheduledDate  STRING ,
PM_ScheduledDate_skey INT ,
UnitInDate  STRING , 
UnitInDate_skey INT ,
PM_NextDueDate  STRING , 
PM_NextDueDate_skey INT ,
STATUS_CODE  STRING ,
Work_OrderNo STRING ,
WO_Status  STRING ,
DatetimeInsert STRING ,
DatetimeUpdate String ,
AssetName  STRING ,
Costcenter  STRING , 
StationCode  STRING ,
ServiceTypeCode  STRING ,
CustomerCode  STRING ,
ContractCode  STRING , 
BS_Finance_skey  BIGINT ,
IsLatest  INT ,
EffectiveFromDate  DATE ,
EffectiveToDate DATE ,
CreatedDate   TIMESTAMP ,
UpdatedDate TIMESTAMP ,
Load_Date INT 
)
USING DELTA 
LOCATION "/mnt/gold/gse/GSEEquipmentJob";

-- COMMAND ----------

Create table unifi_hr_gold.DimGseProvider (

Provider_skey BIGINT   ,
RegionManager STRING ,
RMPhone STRING ,
RMEmail STRING,
StationCode STRING ,
CostCenter STRING ,
ServiceTypeCode STRING ,
CustomerCode STRING ,
ContractCode STRING ,
BS_Finance_skey  BIGINT ,
Address STRING ,
MechanicContact STRING ,
VendorContact STRING ,
DimFinEff_fromDate  DATE ,
DimFinEff_ToDate DATE ,
IsLatest INT ,
CreatedDate TIMESTAMP ,
UpdatedDate TIMESTAMP ,
Load_Date INT
)
USING DELTA 
LOCATION "/mnt/gold/gse/GseProvider/";