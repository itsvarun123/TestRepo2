# Databricks notebook source
wf_id=dbutils.widgets.get("wf_id")
task_id=dbutils.widgets.get("task_id")

# COMMAND ----------

# MAGIC %run ./GenericFunctions

# COMMAND ----------

#run_date=20220312

run_date=get_run_date(wf_id)
tracking_url=get_url()
update_tracking_url(task_id,run_date,tracking_url)

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC alter table unifi_hr_bronze.gse_equipment recover partitions;
# MAGIC REFRESH table unifi_hr_bronze.gse_equipment;

# COMMAND ----------

key=spark.sql("""select nvl(max(EquipmentType_Skey),1000) as max_skey from unifi_hr_gold.DimGSEEquipmentMain""").first()['max_skey']

# COMMAND ----------

original_df=spark.sql(f"""

Select 
DISTINCT
nvl(trim(a1.Assetno),'-1') as ASSET_ID, 
trim(a1.Eqequipno) as EQUIPMENT_NUMBER ,
nvl(trim(a1.Assettype),'-1') as ASSET_TYPE ,
nvl(a1.Color,'-1') as ASSET_COLOR  ,
a1.Dateadded as ADDED_DATE  ,
nvl(dt.Date_Skey,-1) as Added_dateskey ,
a1.Deliverydate as DELIVERY_DATE  ,
nvl(dt1.Date_Skey,-1) as Delivery_dateskey ,
nvl(trim(a1.Eqcatequipcategory),'-1') as EQUIPMENT_CATEGORY  ,
nvl(trim(a1.Eqtypequiptype),'-1') as EQUIPMENT_TYPE ,
a1.Inservicedate as SERVICEIN_DATE ,
nvl(dt2.Date_Skey,-1) as ServiceIn_dateskey ,
a1.Lastpmscheddate as PM_LASTSCHEDULEDATE  ,
nvl(dt3.Date_Skey,-1) as PM_LastSchedule_dateskey ,
a1.Lastpmslot as LAST_PM_SLOT  ,
a1.Lastpmstartdate as PM_LASTSTARTDATE  ,
nvl(dt4.Date_Skey,-1) as PM_LastSTARTDATE_dateskey,
a1.Nextpmscheddate as PM_NEXTSCHEDULEDATE , 
nvl(dt5.Date_Skey,-1) as PM_NextSchedule_dateskey ,
nvl(a1.Originalcost,'-1') as ORIGINAL_COST ,
nvl(trim(a1.Parkingstall),'-1') as PARKING_STALL ,
nvl(trim(a1.Slastatus),'-1') as SLA_STATUS ,
nvl(trim(a1.Workordersok),'-1') as WORK_ORDERS_OK ,
nvl(trim(a1.Workorderstatus),'-1') as WORK_ORDER_STATUS ,
nvl(trim(a1.Procstprocstatus),'-1') as Proc_Status , 
nvl(a1.Year,'-1') as YEAR  ,
a1.Assetworks_InsertDate as Assetworks_InsertDate ,
a1.Assetworks_UpdateDate as Assetworks_UpdateDate,
nvl(trim(c1.Costcenter),'-1') as Costcenter ,
nvl(trim(c1.ContractCode),'-1') as ContractCode ,
a1.load_date
from unifi_hr_bronze.gse_equipment a1
Left outer join unifi_hr_gold.DimDate dt on(to_date(substring(a1.Dateadded,1,8),'yyyyMMdd')=dt.Date)
Left outer join unifi_hr_gold.DimDate  dt1 on(to_date(substring(a1.Deliverydate,1,8),'yyyyMMdd')=dt1.Date)
Left outer join unifi_hr_gold.DimDate  dt2 on(to_date(substring(a1.Inservicedate,1,8),'yyyyMMdd')=dt2.Date)
Left outer join unifi_hr_gold.DimDate  dt3 on(to_date(substring(a1.Lastpmscheddate,1,8),'yyyyMMdd')=dt3.Date)
Left outer join unifi_hr_gold.DimDate  dt4 on(to_date(substring(a1.Lastpmstartdate,1,8),'yyyyMMdd')=dt4.Date)
Left outer join unifi_hr_gold.DimDate  dt5 on(to_date(substring(a1.Nextpmscheddate,1,8),'yyyyMMdd')=dt5.Date)
Left outer join unifi_hr_gold.DimEquipmentToContract c1 on
(trim(a1.Eqequipno) = trim(c1.EQUIPMENT_NUMBER) 
and to_date(substring(a1.Assetworks_InsertDate,1,8),'yyyyMMdd') between c1.EffectiveFromDate and c1.EffectiveToDate
and to_date(substring(a1.Assetworks_InsertDate,1,8),'yyyyMMdd') < c1.EffectiveToDate
)
where 
a1.load_date ={run_date} and a1.Eqequipno is not null 


""").createOrReplaceTempView('equiptemp')


# COMMAND ----------

stage_df=spark.sql(f"""
SELECT
 {key} + monotonically_increasing_id() +1 EquipmentType_Skey,
trim(t.ASSET_ID) as ASSET_ID , 
trim(t.EQUIPMENT_NUMBER) as EQUIPMENT_NUMBER  ,
nvl(trim(t.ASSET_TYPE),'-1') as ASSET_TYPE ,
nvl(A1.AssetType_skey,'-1') as AssetType_skey,
trim(t.ASSET_COLOR) as ASSET_COLOR  ,
t.ADDED_DATE as ADDED_DATE  ,
t.Added_dateskey as Added_dateskey,
t.DELIVERY_DATE as DELIVERY_DATE ,
t.Delivery_dateskey as Delivery_dateskey,
trim(t.EQUIPMENT_CATEGORY) as EQUIPMENT_CATEGORY  ,
trim(t.EQUIPMENT_TYPE) as EQUIPMENT_TYPE ,
t.SERVICEIN_DATE as SERVICEIN_DATE,
t.ServiceIn_dateskey as ServiceIn_dateskey,
t.PM_LASTSCHEDULEDATE as PM_LASTSCHEDULEDATE ,
t.PM_LastSchedule_dateskey as PM_LastSchedule_dateskey ,
t.LAST_PM_SLOT as LAST_PM_SLOT ,
t.PM_LASTSTARTDATE as PM_LASTSTARTDATE  ,
t.PM_LastSTARTDATE_dateskey as PM_LastSTARTDATE_dateskey ,
t.PM_NEXTSCHEDULEDATE as PM_NEXTSCHEDULEDATE , 
t.PM_NextSchedule_dateskey as PM_NextSchedule_dateskey ,
t.ORIGINAL_COST ,
trim(t.PARKING_STALL) as PARKING_STALL ,
trim(t.SLA_STATUS) as SLA_STATUS ,
trim(t.WORK_ORDERS_OK) as WORK_ORDERS_OK ,
trim(t.WORK_ORDER_STATUS) as WORK_ORDER_STATUS ,
t.Proc_Status as Proc_Status ,
t.YEAR  ,
t.Assetworks_InsertDate ,
t.Assetworks_UpdateDate ,
t.ContractCode as ContractCode,
trim(t.Costcenter) as Costcenter,
current_timestamp as CreatedDate,
cast(null as timestamp) UpdatedDate,
t.load_date,
case
    when 
    
    nvl(trim(eq.ASSET_TYPE),'-1') = nvl(trim(t.ASSET_TYPE),'-1')
    and nvl(trim(eq.EQUIPMENT_NUMBER), '-1') = nvl(trim(t.EQUIPMENT_NUMBER), '-1')
    --and nvl(eq.ASSET_COLOR, '-1') = nvl(trim(t.ASSET_COLOR), '-1')  
    --and nvl(eq.ADDED_DATE, '-1') = nvl(trim(t.ADDED_DATE), '-1')  
   -- and nvl(eq.DELIVERY_DATE, '-1') = nvl(trim(t.DELIVERY_DATE), '-1') 
    -- and nvl(eq.SERVICEIN_DATE, '-1') = nvl(trim(t.SERVICEIN_DATE), '-1') 
    --and nvl(eq.PM_LASTSCHEDULEDATE, '-1') = nvl(trim(t.PM_LASTSCHEDULEDATE), '-1') 
   -- and nvl(eq.LAST_PM_SLOT, '-1') = nvl(trim(t.LAST_PM_SLOT), '-1')  
   -- and nvl(eq.PARKING_STALL, '-1') = nvl(trim(t.PARKING_STALL), '-1')
   
    --and nvl(trim(eq.EQUIPMENT_CATEGORY), '-1') = nvl(trim(t.EQUIPMENT_CATEGORY), '-1') 
   -- and nvl(trim(eq.EQUIPMENT_TYPE), '-1') = nvl(trim(t.EQUIPMENT_TYPE), '-1')  
    and nvl(trim(eq.SLA_STATUS), '-1') = nvl(trim(t.SLA_STATUS), '-1') 
    and nvl(trim(eq.Proc_Status), '-1') = nvl(trim(t.Proc_Status), '-1') 
    and nvl(trim(eq.WORK_ORDERS_OK), '-1') = nvl(trim(t.WORK_ORDERS_OK), '-1')
    and nvl(trim(eq.Costcenter), '-1') = nvl(trim(t.Costcenter), '-1')
    and nvl(trim(eq.WORK_ORDER_STATUS), '-1') = nvl(trim(t.WORK_ORDER_STATUS), '-1') 
    and nvl(trim(eq.YEAR), '-1') = nvl(trim(t.YEAR), '-1')
    and nvl(trim(eq.Assetworks_InsertDate), '-1') = nvl(trim(t.Assetworks_InsertDate), '-1')
    and nvl(eq.Assetworks_UpdateDate, '-1') = nvl(trim(t.Assetworks_UpdateDate), '-1')
    
    
    then 1 
    else 0
  end as update_status
from 
equiptemp t left outer join
( select * from unifi_hr_gold.DimGSEEquipmentMain where EffectiveToDate = to_date('2199-12-31')) eq  on 
(
nvl(trim(t.ASSET_ID),'-1') = nvl(trim(eq.ASSET_ID),'-1')
and nvl(trim(t.EQUIPMENT_NUMBER),'-1') = nvl(trim(eq.EQUIPMENT_NUMBER),'-1') 
and nvl(trim(eq.CostCenter),'-1')=nvl(trim(t.CostCenter),'-1')
)
left outer join unifi_hr_gold.DimGSEAssetType A1 on (nvl(trim(A1.ASSET_TYPE),'-1') = nvl(trim(t.ASSET_TYPE),'-1') )

""").createOrReplaceTempView('equiptemp1')




# COMMAND ----------

delete_df=spark.sql(f"""
delete from unifi_hr_gold.DimGSEEquipmentMain
 where to_date(createdDate) = to_date (CURRENT_TIMESTAMP) AND load_date = {run_date}
""")

display(delete_df)

revert_df=spark.sql(f"""
update unifi_hr_gold.DimGSEEquipmentMain 
  SET EffectiveToDate = to_date('2199-12-31'),
      UpdatedDate = CURRENT_TIMESTAMP
      where  to_date(UpdatedDate) = to_date (CURRENT_TIMESTAMP) AND EffectiveToDate = date_add (to_date(CAST({run_date} AS string),'yyyyMMdd'),-1)
""")

display(revert_df)

# COMMAND ----------

update_df=spark.sql(f"""
MERGE INTO unifi_hr_gold.DimGSEEquipmentMain eq
USING equiptemp1 t
ON ( 
t.ASSET_ID = eq.ASSET_ID 
and t.EQUIPMENT_NUMBER = eq.EQUIPMENT_NUMBER 
and eq.CostCenter=t.CostCenter ) 

and to_date(eq.EffectiveToDate)=to_date('2199-12-31')
WHEN MATCHED and t.update_status=0 THEN
  UPDATE SET eq.IsLatest = 0,
  eq.EffectiveToDate = date_add(to_date(cast({run_date} as string),'yyyyMMdd'),-1)  ,
             eq.UpdatedDate=current_timestamp
""")

display(update_df)  

# COMMAND ----------

insert_df=spark.sql(f""" 
 insert into   unifi_hr_gold.DimGSEEquipmentMain 
select
t.EquipmentType_Skey,
trim(t.ASSET_ID) as ASSET_ID , 
trim(t.EQUIPMENT_NUMBER) as EQUIPMENT_NUMBER  ,
trim(t.ASSET_TYPE) as ASSET_TYPE ,
t.AssetType_skey as AssetType_skey,
trim(t.ASSET_COLOR) as ASSET_COLOR  ,
t.ADDED_DATE as ADDED_DATE ,
t.Added_dateskey as Added_dateskey,
t.DELIVERY_DATE as DELIVERY_DATE ,
t.Delivery_dateskey as Delivery_dateskey ,
trim(t.EQUIPMENT_CATEGORY) as EQUIPMENT_CATEGORY  ,
trim(t.EQUIPMENT_TYPE) as EQUIPMENT_TYPE ,
t.SERVICEIN_DATE as SERVICEIN_DATE ,
t.ServiceIn_dateskey as ServiceIn_dateskey ,
t.PM_LASTSCHEDULEDATE as PM_LASTSCHEDULEDATE  ,
t.PM_LastSchedule_dateskey as PM_LastSchedule_dateskey , 
t.LAST_PM_SLOT as LAST_PM_SLOT ,
t.PM_LASTSTARTDATE as PM_LASTSTARTDATE  ,
t.PM_LastSTARTDATE_dateskey as PM_LastSTARTDATE_dateskey ,
t.PM_NEXTSCHEDULEDATE as PM_NEXTSCHEDULEDATE , 
t.PM_NextSchedule_dateskey as PM_NextSchedule_dateskey ,
t.ORIGINAL_COST ,
trim(t.PARKING_STALL) as PARKING_STALL ,
trim(t.SLA_STATUS) as SLA_STATUS ,
t.WORK_ORDERS_OK as WORK_ORDERS_OK , 
trim(t.WORK_ORDER_STATUS) as WORK_ORDER_STATUS ,
t.Proc_Status , 
t.YEAR  ,
t.Assetworks_InsertDate ,
t.Assetworks_UpdateDate ,
t.ContractCode ,
trim(t.Costcenter) as Costcenter ,
1 as IsLatest ,
 
 case WHEN (eq.EffectiveToDate) IS null THEN '1900-01-01'
 ELSE (to_date(cast({run_date} as string),'yyyyMMdd')) 
  END AS EffectiveFromDate ,
 
  '2199-12-31' as EffectiveToDate,
  CreatedDate,
  UpdatedDate,
  t.load_date
from   equiptemp1 t
  LEFT OUTER JOIN (
    SELECT
      DISTINCT EQUIPMENT_NUMBER,CostCenter,
      MAX(EffectiveToDate) OVER (PARTITION BY EQUIPMENT_NUMBER) AS EffectiveToDate
    FROM
      unifi_hr_gold.DimGSEEquipmentMain
  ) eq ON (  t.EQUIPMENT_NUMBER = eq.EQUIPMENT_NUMBER and t.CostCenter= eq.CostCenter)
where
  t.update_status = 0 
  
                   """)


# COMMAND ----------

snowflaketable_df=spark.sql("select * from unifi_hr_gold.DimGSEEquipmentMain")

# COMMAND ----------

snowflaketable_df.write.format("snowflake").options(**scoptions).option("dbtable", "EDW.DimGSEEquipmentMain").mode("overwrite").save()