# Databricks notebook source
wf_id=dbutils.widgets.get("wf_id")
task_id=dbutils.widgets.get("task_id")

# COMMAND ----------

# MAGIC %run ./GenericFunctions

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC alter table unifi_hr_bronze.Famasset recover partitions;
# MAGIC REFRESH table unifi_hr_bronze.Famasset;

# COMMAND ----------

#run_date=20220314

run_date=get_run_date(wf_id)
print(run_date)
tracking_url=get_url()
update_tracking_url(task_id,run_date,tracking_url)


# COMMAND ----------

key=spark.sql("""select nvl(max(EquipmentToContract_skey),1000) as max_skey from unifi_hr_gold.DimEquipmentToContract""").first()['max_skey']

# COMMAND ----------

spark.sql(f"""

SELECT 
Distinct  
nvl(trim(a1.EquipmentNumber),'-1') as EQUIPMENT_NUMBER,
nvl(a1.InternalID,'-1') as InternalID ,
a1.CostCenter as CostCenter,
nvl(b1.StationCode,'-1') as StationCode,
nvl(b1.ServiceTypeCode,'-1') as ServiceTypeCode,
nvl(b1.CustomerCode,'-1')  as CustomerCode,
nvl(b1.ContractCode,'-1') as ContractCode,
b1.BS_Finance_Skey as BS_Finance_Skey,
nvl(a1.AssetName,'-1') as AssetName ,
nvl(a1.airco_unique_asset_type,'-1') as ASSET_TYPE,

case
    when nvl(trim(a1.InternalID),'-1') = nvl(trim(a2.InternalID),'-1')
    and nvl(trim(a1.EquipmentNumber),'-1') = nvl(trim(a2.EQUIPMENT_NUMBER),'-1')
    and nvl(trim(a1.CostCenter), '-1') = nvl(trim(a2.CostCenter), '-1')
    and nvl(trim(a1.AssetName), '-1') = nvl(trim(a2.AssetName), '-1')
    and nvl(trim(a1.airco_unique_asset_type), '-1') = nvl(trim(a2.ASSETTYPE), '-1')
    and nvl(b1.BS_Finance_Skey, '-1') = nvl(a2.BS_Finance_Skey, '-1')
    and nvl(trim(b1.StationCode), '-1') = nvl(trim(a2.StationCode), '-1')
    and nvl(trim(b1.ServiceTypeCode), '-1') = nvl(trim(a2.ServiceTypeCode), '-1')
    and nvl(trim(b1.CustomerCode), '-1') = nvl(trim(a2.CustomerCode), '-1')
    and nvl(trim(b1.ContractCode), '-1') = nvl(trim(a2.ContractCode), '-1')
     then 1 
    else 0
  end as update_status ,

current_timestamp() CreatedDate,
cast(null as timestamp) UpdatedDate,
a1.load_date

from unifi_hr_bronze.Famasset a1
Left outer join unifi_hr_gold.DimFinanceBusinessStructure b1 on (a1.CostCenter = b1.CostCenter  and b1.EffectiveToDate='2199-12-31')
Left outer join unifi_hr_gold.DimEquipmentToContract a2 
on(trim(a1.EquipmentNumber) = a2.EQUIPMENT_NUMBER and a1.CostCenter = a2.COSTCENTER 
and a1.InternalID =a2.InternalID
and b1.BS_Finance_Skey = a2.BS_Finance_Skey
and nvl(trim(b1.StationCode), '-1') = a2.StationCode 
and nvl(trim(b1.ServiceTypeCode), '-1') = a2.ServiceTypeCode
and nvl(trim(b1.CustomerCode), '-1') = a2.CustomerCode
and nvl(trim(b1.ContractCode), '-1') = a2.ContractCode
)

where a1.load_date={run_date} and a1.EquipmentNumber is not null

""").createOrReplaceTempView('eqcontracttemp')



# COMMAND ----------

delete_df=spark.sql(f"""
delete from unifi_hr_gold.DimEquipmentToContract
 where to_date(createdDate) = to_date (CURRENT_TIMESTAMP) AND load_date = {run_date}
""")

display(delete_df)

revert_df=spark.sql(f"""
update unifi_hr_gold.DimEquipmentToContract 
  SET EffectiveToDate = to_date('2199-12-31'),
      UpdatedDate = CURRENT_TIMESTAMP
      where  to_date(UpdatedDate) = to_date (CURRENT_TIMESTAMP) AND EffectiveToDate = date_add (to_date(CAST({run_date} AS string),'yyyyMMdd'),-1)
""")

display(revert_df)

# COMMAND ----------

update_df=spark.sql(f"""
MERGE INTO unifi_hr_gold.DimEquipmentToContract a2
USING eqcontracttemp a1 on ( a1.EQUIPMENT_NUMBER= a2.EQUIPMENT_NUMBER and a1.CostCenter = a2.COSTCENTER 
 and a1.InternalID = a2.InternalID and a2.BS_Finance_Skey = a1.BS_Finance_Skey
                         
AND to_date(a2.EffectiveToDate) = to_date ('2199-12-31')  )
WHEN MATCHED AND a1.update_status = 0 
THEN UPDATE
  SET a2.isLatest=0,
      a2.EffectiveToDate = date_add(to_date (CAST({run_date} AS string),'yyyyMMdd'),-1),
      a2.UpdatedDate = CURRENT_TIMESTAMP
""")

display(update_df) 

# COMMAND ----------

insert_df=spark.sql(f""" 

insert into unifi_hr_gold.DimEquipmentToContract
select
{key} + monotonically_increasing_id() +1 EquipmentToContract_skey ,
a1.EQUIPMENT_NUMBER ,
a1.InternalID ,
a1.CostCenter ,
a1.StationCode,
a1.ServiceTypeCode ,
a1.CustomerCode ,
a1.ContractCode ,
a1.BS_Finance_Skey ,
a1.AssetName ,
a1.ASSET_TYPE ,
1 as IsLatest ,
 case WHEN (a2.EffectiveToDate) IS null THEN '2021-01-01'
 ELSE (to_date(cast({run_date} as string),'yyyyMMdd')) 
  END AS EffectiveFromDate ,
 
  '2199-12-31' as EffectiveToDate,
  CreatedDate,
  UpdatedDate,
  a1.load_date
from   eqcontracttemp a1
  LEFT OUTER JOIN (
    SELECT
      DISTINCT EQUIPMENT_NUMBER,COSTCENTER ,InternalID ,
      MAX(EffectiveToDate) OVER (PARTITION BY EQUIPMENT_NUMBER) AS EffectiveToDate
    FROM
      unifi_hr_gold.DimEquipmentToContract
  ) a2 ON (a1.EQUIPMENT_NUMBER= a2.EQUIPMENT_NUMBER and a1.CostCenter = a2.COSTCENTER and a1.InternalID=a2.InternalID )
where
  a1.update_status = 0 
  
  """)

display(insert_df)

# COMMAND ----------

snowflaketable_df=spark.sql("select * from unifi_hr_gold.DimEquipmentToContract")

# COMMAND ----------

snowflaketable_df.write.format("snowflake").options(**scoptions).option("dbtable", "EDW.DimEquipmentToContract").mode("overwrite").save()