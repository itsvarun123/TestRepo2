# Databricks notebook source
wf_id= dbutils.widgets.get("wf_id")
task_id= dbutils.widgets.get("task_id")
table_name= dbutils.widgets.get("table_name")

# COMMAND ----------

# MAGIC %run ./AuditGenericFunctions

# COMMAND ----------

#run_date=20220308
run_date=get_run_date(wf_id)
batch_id= wf_id+str(run_date)

# COMMAND ----------


gold_table_name=str(table_name.split(",")[0])
bronze_table_name=str(table_name.split(",")[1])

load_frequency=sqlContext.read.format("net.snowflake.spark.snowflake").options(**scoptions).option("query" , f"SELECT LOAD_FREQUENCY from AUDIT.TASK_MASTER where GOLD_TABLE_NAME='{gold_table_name}'").load().first()['LOAD_FREQUENCY']

csvPath=sqlContext.read.format("net.snowflake.spark.snowflake").options(**scoptions).option("query" , f"SELECT FILE_DIRECTORY from AUDIT.FILE_MASTER where BRONZE_TABLE_NAME='{bronze_table_name}'").load().first()['FILE_DIRECTORY']  + f"/load_date={run_date}" 


if load_frequency!= 'DAILY' :
  try :
    dbutils.fs.fsutils.ls(csvPath)
  except: 
    dbutils.notebook.exit("0")
  
source_df=spark.read.option("header", "true").csv(csvPath)
#print(len(source_df.columns))

target_df=spark.table("unifi_hr_bronze."+bronze_table_name.lower()).schema.fieldNames()
target_df.remove('load_date')
#print(len(target_df))

# COMMAND ----------

if (column_sync_up(source_df,target_df)==0 or wf_id=='WF0020') :
#if True :
  sfUtils.runQuery(scoptions, f"""DELETE FROM AUDIT.WORKFLOW_TASK_DETAILS WHERE TASK_ID='$task_id' and RUN_DATE={run_date}""".replace("$task_id",task_id))
  sfUtils.runQuery(scoptions, f"""INSERT INTO AUDIT.WORKFLOW_TASK_DETAILS VALUES ('{wf_id}','{batch_id}','{task_id}',                 {run_date},null,null,null,null,current_timestamp,null,'INPROGRESS',null,current_timestamp,null)""")
else :
  raise Exception('Schema is not matching between source file and target tables')

