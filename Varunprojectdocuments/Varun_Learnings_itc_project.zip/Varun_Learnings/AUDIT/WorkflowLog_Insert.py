# Databricks notebook source
wf_id=dbutils.widgets.get("wf_id")

# COMMAND ----------

# MAGIC %run ./AuditGenericFunctions

# COMMAND ----------

run_date=get_run_date(wf_id)
batch_id= wf_id+str(run_date)

# COMMAND ----------

def get_bhoomi_status(wf_id):
      boomi_status_count=sqlContext.read.format("net.snowflake.spark.snowflake").options(**scoptions).option("query" , f"SELECT count(STATUS) as STATUS_COUNT from AUDIT.BOOMI_CONTROL_DETAILS where task_id in (select task_id from AUDIT.TASK_MASTER where task_id like '{wf_id}%') and STATUS = 'SUCCESS' and (to_char(created_date,'YYYYMMDD')={run_date} OR to_char(updated_date,'YYYYMMDD')={run_date})").load().first()['STATUS_COUNT']       
      if wf_id == 'WF0001' and boomi_status_count == 13 :
        return True
      elif wf_id == 'WF0002' and boomi_status_count == 3 :
        return True
      elif wf_id == 'WF0003' and boomi_status_count == 8 :
        return True
      elif wf_id == 'WF0004' and boomi_status_count == 1 :
        return True
      elif wf_id == 'WF0005' and boomi_status_count == 1 :
        return True
      elif wf_id == 'WF0006' and boomi_status_count == 1 :
        return True
      elif wf_id == 'WF0007' and boomi_status_count == 3 :
        return True
      elif wf_id == 'WF0008' and boomi_status_count == 1 :
        return True
      elif wf_id == 'WF0009' and boomi_status_count == 1 :
        return True
      elif wf_id == 'WF0010' :
        return True
      elif wf_id == 'WF0011' :
        return True
      elif wf_id == 'WF0012' :
        return True
      elif wf_id == 'WF0013' :
        return True
      elif wf_id == 'WF0021' :
        return True
      elif wf_id == 'WF0020' :
        return True
      elif wf_id == 'WF0022' :
        return True
      elif wf_id == 'WF0030' :
        return True
      elif wf_id == 'WF0032' :
        return True
      elif wf_id == 'WF0025' and boomi_status_count == 1 :
        return True
      elif wf_id == 'WF0050' and boomi_status_count == 2 :
        return True
      else :
        return False
      

print(get_bhoomi_status(wf_id))


#print(run_date)
#def get_bhoomi_status(wf_id):
   #return True

# COMMAND ----------

if get_bhoomi_status(wf_id) == True :
  sfUtils.runQuery(scoptions, f"""DELETE FROM AUDIT.WORKFLOW_LOG WHERE WF_ID='{wf_id}' and RUN_DATE={run_date}""")
  sfUtils.runQuery(scoptions, f"""INSERT INTO AUDIT.WORKFLOW_LOG VALUES 
('{wf_id}','{batch_id}',current_timestamp,null,'INPROGRESS',{run_date},current_timestamp,null)""")
else :
  sfUtils.runQuery(scoptions, f"""Update AUDIT.WORKFLOW_LOG  
  set RUN_STATUS='FAIL',END_TIME=current_timestamp,UPDATED_DATE=current_timestamp WHERE WF_ID='{wf_id}' and RUN_DATE={run_date}""")
  raise Exception("Depedent Jobs are not completed") 
  #dbutils.notebook.exit("0")
  