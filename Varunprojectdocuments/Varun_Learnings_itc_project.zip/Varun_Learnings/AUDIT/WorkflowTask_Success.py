# Databricks notebook source
wf_id= dbutils.widgets.get("wf_id")
task_id= dbutils.widgets.get("task_id")
table_name= dbutils.widgets.get("table_name")

# COMMAND ----------

# MAGIC %run ./AuditGenericFunctions

# COMMAND ----------

# run_date=20210111
run_date=get_run_date(wf_id)
batch_id= wf_id+str(run_date)

gold_table_name=str(table_name.split(",")[0])
bronze_table_name=str(table_name.split(",")[1])

#print(gold_table_name)

# COMMAND ----------

def get_counts(table_name,run_date):
  tablename=list(map(lambda _: f"unifi_hr_bronze.{_}",table_name.split(',',1).pop(1).split(',')))
  base_df= spark.createDataFrame(spark.sparkContext.emptyRDD(),spark.table(tablename[0]).schema)

  for tb in tablename:    
      df = spark.sql(f"select * from {tb} where load_date={run_date} ")
      base_df=base_df.union(df)
  
  countCheck=sqlContext.read.format("net.snowflake.spark.snowflake").options(**scoptions).option("query" , f"SELECT ENABLE_COUNTCHECK from AUDIT.TASK_MASTER where GOLD_TABLE_NAME='{table_name.split(',',1).pop(0)}'").load().first()['ENABLE_COUNTCHECK'] 

  print(countCheck)
  
  if(countCheck=='1') :
    bronze_count=base_df.count()
    gold_count=spark.sql(f"""select * from unifi_hr_gold.{table_name.split(',',1).pop(0)} where load_date={run_date} """).count()
    snowflake_count=sqlContext.read.format("net.snowflake.spark.snowflake").options(**scoptions).option("query" , f"SELECT count(*) as count from EDW.{table_name.split(',',1).pop(0)} where load_date={run_date}").load().first()['COUNT']
  else :
    bronze_count=0
    gold_count=0
    snowflake_count=0 

  return (bronze_count,gold_count,snowflake_count)


bronze_count,gold_count,snowflake_count=get_counts(table_name,run_date)


print(bronze_count)
print(gold_count)
print(snowflake_count)


# COMMAND ----------

sfUtils.runQuery(scoptions, f"""Update AUDIT.WORKFLOW_TASK_DETAILS  
set RUN_STATUS='SUCCESS',END_TIME=current_timestamp,TARGET_TABLE_NAME='{gold_table_name}',BRONZE_COUNT={bronze_count},GOLD_COUNT={gold_count},SNOWFLAKE_COUNT={snowflake_count},UPDATED_DATE=current_timestamp WHERE TASK_ID='{task_id}' and RUN_DATE={run_date}""")