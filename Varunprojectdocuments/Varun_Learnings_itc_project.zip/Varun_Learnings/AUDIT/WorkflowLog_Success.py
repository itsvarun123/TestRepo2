# Databricks notebook source
wf_id=dbutils.widgets.get("wf_id")
wf_id

# COMMAND ----------

# MAGIC %run ./AuditGenericFunctions

# COMMAND ----------

run_date=get_run_date(wf_id)

# COMMAND ----------

sfUtils.runQuery(scoptions, f"""Update AUDIT.WORKFLOW_LOG  
set RUN_STATUS='SUCCESS',END_TIME=current_timestamp,UPDATED_DATE=current_timestamp WHERE WF_ID='{wf_id}' and RUN_DATE={run_date}""")

# COMMAND ----------

sfUtils.runQuery(scoptions, f"""Update AUDIT.SNAPSHOT_CONTROL
set LAST_RUN_DATE=dateadd(day,1,LAST_RUN_DATE),UPDATED_DATE=current_timestamp WHERE WF_ID='{wf_id}'""")