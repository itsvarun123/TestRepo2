# Databricks notebook source
wf_id= dbutils.widgets.get("wf_id")
task_id= dbutils.widgets.get("task_id")
table_name= dbutils.widgets.get("table_name")

# COMMAND ----------

# MAGIC %run ./AuditGenericFunctions

# COMMAND ----------

# run_date=20210111
run_date=get_run_date(wf_id)
batch_id= wf_id+str(run_date)
sfUtils.runQuery(scoptions, f"""Update AUDIT.WORKFLOW_TASK_DETAILS
set RUN_STATUS='FAIL',END_TIME=current_timestamp,UPDATED_DATE=current_timestamp WHERE TASK_ID='{task_id}' and RUN_DATE={run_date}""")
sfUtils.runQuery(scoptions, f"""Update AUDIT.WORKFLOW_LOG  
set RUN_STATUS='FAIL',END_TIME=current_timestamp,UPDATED_DATE=current_timestamp WHERE WF_ID='{wf_id}' and RUN_DATE={run_date}""")