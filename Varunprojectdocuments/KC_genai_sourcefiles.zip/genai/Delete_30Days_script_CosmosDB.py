# Databricks notebook source
from azure.cosmos import CosmosClient,exceptions,PartitionKey
import pandas as pd 
import random
import datetime
from datetime import datetime,timedelta 

cosmosendpoint=dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cosmos-endpoint")
masterkey=dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cosmos-master-key")

database_name = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cosmos-database-name")
container_name = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "container-name-manufacturingmsglogs")

cosmos_client=CosmosClient(f"{cosmosendpoint}",{'masterKey':f"{masterkey};"}) 

database = cosmos_client.get_database_client(database_name)
print("database : ",database)
container=database.get_container_client(container_name)
print("container name : ",container) 

cosdb_connString = f"AccountEndpoint={cosmosendpoint};AccountKey={masterkey};Database={database_name};"

print(cosdb_connString)
for char in cosdb_connString:
    print(char, end=" ")

# COMMAND ----------

max_date=spark.sql(""" select max(timestamp) as max_timestamp from cosmosdb_data """)
display(max_date)
min_date=spark.sql(""" select min(timestamp) as min_timestamp from cosmosdb_data """)
display(min_date) 
diff_days= spark.sql(""" select date_diff(max(timestamp),min(timestamp)) from cosmosdb_data """)
display(diff_days) 
current_date=datetime.utcnow()
print(current_date)
cuttoff_date=current_date-timedelta(days=77)
print(cuttoff_date)


# COMMAND ----------

# MAGIC %md ##  Delete query using Maximum date in Cosmos table

# COMMAND ----------

max_ts_query="select TOP 1 c._ts from c order by c._ts DESC"
max_ts_result=container.query_items(query=max_ts_query,enable_cross_partition_query=True)
max_ts=next(max_ts_result,None)
if max_ts is not None:
    max_ts=max_ts['_ts']
else:
    max_ts=0

print(max_ts)
max_date=cutoff_date=datetime.utcfromtimestamp(max_ts)
print(max_date)
cutoff_date1=datetime.utcfromtimestamp(max_ts)-timedelta(days=40)
print(cutoff_date1)

documents_to_delete=container.query_items(
    query=f"SELECT * from c where c._ts < {cutoff_date1.timestamp()}",
    enable_cross_partition_query=True
)
for document in documents_to_delete:
    container.delete_item(item=document['id'],partition_key=document['user_id'])

# COMMAND ----------

# MAGIC %md ##  Delete Query using Current Date as max date in Cosmos table (Current_date -30 days)

# COMMAND ----------



#### Main Script ####

# current_date=datetime.utcnow()
# print(current_date)
# cuttoff_date=current_date-timedelta(days=76)
# print(cuttoff_date)

# documents_to_delete=container.query_items(
#     query=f"SELECT * from c where c._ts < {cuttoff_date.timestamp()}",
#     enable_cross_partition_query=True
# )
# for document in documents_to_delete:
#     container.delete_item(item=document['id'],partition_key=document['user_id'])