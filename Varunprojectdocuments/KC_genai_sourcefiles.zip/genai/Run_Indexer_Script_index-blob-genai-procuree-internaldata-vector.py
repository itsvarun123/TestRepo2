# Databricks notebook source
searchservice_url = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-url")
searchservice_apiKey = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-apikey")

COG_SERVICES_NAME= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cog-service-name")  
COG_SERVICES_KEY= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cog-service-key")    
#COG_SERVICE_ENDPOINT= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-url")  
OPENAI_SERVICE_NAME= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "openai-service-name") 
OpenAI_Service_Key= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "openai-service-key")     
DATASOURCE_CONNECTION_STRING= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "procuree-datasource-string")

datasource_name = "datasource-blob-genai-procuree-internaldata-vector"
skillset_name = "skillset-blob-genai-procuree-internaldata-vector"
index_name ="index-blob-genai-procuree-internaldata-vector"  
indexer_name = "indexer-blob-genai-procuree-internaldata-vector"

for char in DATASOURCE_CONNECTION_STRING:
    print(char, end=" ")

BLOB_CONTAINER_NAME = "stpknowledgebaseinternal"   
print(BLOB_CONTAINER_NAME)

AZURE_SEARCH_ENDPOINT=f"{searchservice_url}"
AZURE_SEARCH_KEY=f"{searchservice_apiKey}"
AZURE_SEARCH_API_VERSION="2023-10-01-Preview"
headers = {'Content-Type': 'application/json','api-key': AZURE_SEARCH_KEY}
params = {'api-version': AZURE_SEARCH_API_VERSION}

##################
print(searchservice_url)
url = f"{searchservice_url}/datasources?api-version=2023-10-01-Preview"   # 2023-07-01-Preview
print(url)

api_key = f'{searchservice_apiKey}'
print(api_key)

#credentials = f"{cosdb_connString}"
#print(credentials)

datasrc_name= f"{datasource_name}"
print(datasrc_name)
print(skillset_name)
ind_name= f"{index_name}"
print(ind_name)
indexer_name= f"{indexer_name}"
print(indexer_name)

print (headers)
print(params)
print("Datasource conn string : " f"{DATASOURCE_CONNECTION_STRING}")

import requests
import json
import os

# COMMAND ----------

import requests

# Replace these placeholders with your actual values
searchservice_url = f"{searchservice_url}"
indexer_name = f"{indexer_name}"
api_key = f'{searchservice_apiKey}'

url = f"{searchservice_url}/indexers/{indexer_name}/run?api-version=2023-10-01-Preview"

headers = {
    'Content-Type': 'application/json',
    'api-key': f'{searchservice_apiKey}'
}

response = requests.post(url, headers=headers)

if response.status_code == 202:
    print(f"Indexer '{indexer_name}' is running.")
else:
    print(f"Failed to run indexer '{indexer_name}'. Status code: {response.status_code}, Error: {response.text}")