# Databricks notebook source
from azure.cosmos import CosmosClient,exceptions,PartitionKey
import pandas as pd 
import random
import datetime
from datetime import datetime,timedelta 

cosmosendpoint=dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cosmos-endpoint")
masterkey=dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cosmos-master-key")

database_name = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cosmos-database-name")
container_name = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "container-name-manufacturingmsglogs")

cosmos_client=CosmosClient(f"{cosmosendpoint}",{'masterKey':f"{masterkey};"}) 

database = cosmos_client.get_database_client(database_name)
print("database : ",database)
container=database.get_container_client(container_name)
print("container name : ",container) 

cosdb_connString = f"AccountEndpoint={cosmosendpoint};AccountKey={masterkey};Database={database_name};"

print(cosdb_connString)
for char in cosdb_connString:
    print(char, end=" ")

# COMMAND ----------

from azure.cosmos import CosmosClient,exceptions,PartitionKey
import pandas as pd 
import random
import datetime
from datetime import datetime,timedelta 

masterkey=dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cosmos-master-key")
cosmosendpoint=dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cosmos-endpoint")

cosmos_client=CosmosClient(f"{cosmosendpoint}",{'masterKey':f"{masterkey};"})

database = cosmos_client.get_database_client(database_name)
print("database : ",database)
container=database.get_container_client(container_name)
print("container name : ",container) 

cosdb_connString = f"AccountEndpoint={cosmosendpoint};AccountKey={masterkey};Database={database_name}"

searchservice_url = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-url")
searchservice_apiKey = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-apikey")

datasource_name = "datasource-genai-cosmos-manufacturingv2"
skillset_name = "skillset-genai-cosmos-manufacturingv2"
index_name ="index-genai-cosmos-manufacturingv2"
indexer_name = "indexer-genai-cosmos-manufacturingv2"

AZURE_SEARCH_ENDPOINT=f"{searchservice_url}"
AZURE_SEARCH_KEY=f"{searchservice_apiKey}"
AZURE_SEARCH_API_VERSION="2023-10-01-Preview"
headers = {'Content-Type': 'application/json','api-key': AZURE_SEARCH_KEY}
params = {'api-version': AZURE_SEARCH_API_VERSION}

COG_SERVICES_NAME = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cog-service-name")
COG_SERVICES_KEY = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cog-service-key")

OpenAI_Service_Key = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "openai-service-key")
OPENAI_SERVICE_NAME = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "openai-service-name")


# COMMAND ----------

# MAGIC %md # Drop Cosmos Index , datasource ,Skillset, Indexer in Azure Search Service

# COMMAND ----------

import requests

# Replace these placeholders with your actual values
searchservice_url = f"{searchservice_url}"
data_source_name=f"{datasource_name}"
skillset_name=f"{skillset_name}"
index_name=f"{index_name}"
indexer_name = f"{indexer_name}"
api_key = f'{searchservice_apiKey}'

headers = {
    'Content-Type': 'application/json',
    'api-key': f'{searchservice_apiKey}'
}

url_datasource = f"{searchservice_url}/datasources/{data_source_name}?api-version=2023-10-01-Preview" 
url_skillset = f"{searchservice_url}/skillsets/{skillset_name}?api-version=2023-10-01-Preview" 
url_index = f"{searchservice_url}/indexes/{index_name}?api-version=2023-10-01-Preview" 
url_indexer = f"{searchservice_url}/indexers/{indexer_name}?api-version=2023-10-01-Preview"

response_datasource = requests.delete(url_datasource, headers=headers)
response_skillset = requests.delete(url_skillset, headers=headers)
response_index = requests.delete(url_index, headers=headers)
response_indexer = requests.delete(url_indexer, headers=headers)

# if response.status_code == 202:
#     print(f"Indexer '{data_source_name}' Deleted Succesfully.")
# else:
#     print(f"Failed to delete indexer '{data_source_name}'. Status code: {response.status_code}, Error: {response.text}")

# COMMAND ----------

# MAGIC %md # Re-Create Cosmos DataSource, skillset ,Index and Indexer

# COMMAND ----------

import requests
import json
url = f"{searchservice_url}/datasources?api-version=2023-10-01-Preview" 
payload = json.dumps({
  "name": f"{datasource_name}",
  "type": "cosmosdb",
  "credentials": {
    "connectionString": f"{cosdb_connString};Database={database_name};"
  },
  "container": {
    "name": f"{container_name}",
       "query": f"SELECT  t1.id AS id,t1.user_id as userid,humanMessage.data.content AS human,aiMessage.data.content AS content,t1.docs as chunks,t1.queryType as querytype,t1._ts as _ts FROM {container_name} t1 JOIN humanMessage IN t1.messages JOIN aiMessage IN t1.messages WHERE humanMessage.type = 'human' AND aiMessage.type = 'ai' and t1._ts>@HighWaterMark ORDER BY t1._ts DESC  "
  }

})

headers = {
  'Content-Type': 'application/json',
  'api-key': f'{searchservice_apiKey}'
}
response = requests.request("POST", url, headers=headers, data=payload)
print(response.text)

# COMMAND ----------

# Create an index
# Queries operate over the searchable fields and filterable fields in the index
index_payload = {
    "name": index_name,
    "fields": [
        {"name": "id", "type": "Edm.String", "key": "true", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false"},
        {"name": "title", "type": "Edm.String", "searchable": "true", "retrievable": "true", "facetable": "false", "filterable": "true", "sortable": "false"},
        #{"name": "id", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true","facetable": "false"},
        {"name": "userid", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true","facetable": "false"},
        {"name": "human", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true","facetable": "false"},        
        {"name": "content", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false"},        
        {"name": "querytype", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false"},
        {"name": "score", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false"},
        {"name": "comment", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false"},
        {"name": "chunks","type": "Collection(Edm.String)", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "language", "type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "true", "filterable": "true", "facetable": "true"},
        {"name": "name", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "location", "type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "images_text", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "keyPhrases", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "true"},
        {"name": "persons", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "locations", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "true"},
        {"name": "organizations", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "true"},
        {"name": "dateTimes", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "urls", "type": "Collection(Edm.String)", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "emails", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "false"}
    ],
    "semantic": {
      "configurations": [
        {
          "name": "my-semantic-config",
          "prioritizedFields": {
            "titleField": 
                {
                    "fieldName": "id"
                },
            "prioritizedContentFields": [
                {
                    "fieldName": "content"
                }
                ]
          }
        }
      ]
    }
}

r = requests.put(AZURE_SEARCH_ENDPOINT + "/indexes/" + index_name,
                 data=json.dumps(index_payload), headers=headers, params=params)
print(r.status_code)
print(r.ok)

# COMMAND ----------

import requests
import json

url = f"{searchservice_url}/indexers/{indexer_name}?api-version=2023-10-01-Preview"
payload = json.dumps({
  "name": f"{indexer_name}",
  "dataSourceName": f"{datasource_name}",
  "targetIndexName": f"{index_name}",
  "schedule" : { "interval" : "PT5M"},  
  "parameters": {
        "configuration": {"assumeOrderByHighWaterMarkColumn" : True}
        },
  "fieldMappings": [
    {
      "sourceFieldName": "id",
      "targetFieldName": "id",
      "mappingFunction": {
       "name": "base64Encode"
      }
    },
    
    {
      "sourceFieldName": "userid",
      "targetFieldName": "userid"
    },    
    {
      "sourceFieldName": "human",
      "targetFieldName": "human"
    },        
    {
      "sourceFieldName": "content",
      "targetFieldName": "content"
    },
    {
      "sourceFieldName": "chunks",
      "targetFieldName": "chunks"
    },   
    {
      "sourceFieldName": "querytype",
      "targetFieldName": "querytype"
    }


  ]
})
headers = {
  'Content-Type': 'application/json',
  'api-key': f'{searchservice_apiKey}'
}

response = requests.request("PUT", url, headers=headers, data=payload)
print(response.text)

# COMMAND ----------

