# Databricks notebook source
pip install openai==0.28.1 azure-search-documents==11.4.0b8 python-dotenv backoff python-docx openai[datalib] pandas azure-storage-blob


# COMMAND ----------

searchservice_url = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-url")
searchservice_apiKey = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-apikey")

COG_SERVICES_NAME= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cog-service-name")  
COG_SERVICES_KEY= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cog-service-key")    
#COG_SERVICE_ENDPOINT= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-url")  
OPENAI_SERVICE_NAME= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "openai-service-name") 
OpenAI_Service_Key= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "openai-service-key")     
DATASOURCE_CONNECTION_STRING= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "manufacturing-datasource-string")
AZURE_SEARCH_ENDPOINT=f"{searchservice_url}"
AZURE_SEARCH_KEY=f"{searchservice_apiKey}"
AZURE_SEARCH_API_VERSION="2023-10-01-Preview"
headers = {'Content-Type': 'application/json','api-key': AZURE_SEARCH_KEY}
params = {'api-version': AZURE_SEARCH_API_VERSION}

# COMMAND ----------

import os
import io
from dotenv import load_dotenv 
import docx,openai,backoff
import re,time
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from  azure.storage.blob  import  BlobClient

searchservice_url = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-url")
searchservice_apiKey = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-apikey")
COG_SERVICES_NAME= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cog-service-name")  
COG_SERVICES_KEY= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cog-service-key")    
OPENAI_SERVICE_NAME= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "openai-service-name") 
OpenAI_Service_Key= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "openai-service-key")     
DATASOURCE_CONNECTION_STRING= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "manufacturing-datasource-string") 

COGAI_URL= dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cogai-url")  
COGAIAPI_KEY = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cogaiapi-key")
MANUFACTURING_INTENT_FILEPATH = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "manufacturing-intent-filepath")
PROCUREE_INTENT_FILEPATH = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "procuree-intent-filepath")
searchservice_url = f"{searchservice_url}" 

#Dev
openai.api_type = "azure" 
openai.api_base = f"{COGAI_URL}" 
openai.api_version = "2023-07-01-preview"
openai.api_key = f"{COGAIAPI_KEY}" 
search_endpoint = f"{searchservice_url}" 
search_key = AzureKeyCredential(f"{searchservice_apiKey}")
index_name = "index-genai-manufacturing-intent-vector"
file_path = f"{MANUFACTURING_INTENT_FILEPATH}"


# COMMAND ----------

# MAGIC %md ## Drop Intent Index 

# COMMAND ----------

import requests

# Construct URL path

url_index = f"{searchservice_url}/indexes/{index_name}?api-version={AZURE_SEARCH_API_VERSION}" 
# Delete Operations
response_index = requests.delete(url_index, headers=headers)

# COMMAND ----------

# MAGIC %md ## Create Intent Index 

# COMMAND ----------

# Create an index
# Queries operate over the searchable fields and filterable fields in the index
import requests
import json
index_payload = {
    "name": index_name,
    "fields": [
        {"name": "id", "type": "Edm.String", "key": "true", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false","analyzer":"keyword"},       
        {"name": "chunk","type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "type", "type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "true", "filterable": "true", "facetable": "true"},        
        {"name": "chunkVector", "type": "Collection(Edm.Single)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false","dimensions":1536,"vectorSearchProfile":"myHnswProfile"},
        
    ],
    "semantic": {
      "configurations": [
        {
          "name": "my-semantic-config",
          "prioritizedFields": {
            "titleField": 
                {
                    "fieldName": "id"
                },
            "prioritizedContentFields": [
                {
                    "fieldName": "chunk"
                }
                ]
          }
        }
      ]
    },
  "vectorSearch": {
    "algorithms": [
      {
        "name": "myHnsw",
        "kind": "hnsw",
        "hnswParameters": {
          "metric": "cosine",
          "m": 4,
          "efConstruction": 400,
          "efSearch": 100
        },
        "exhaustiveKnnParameters": None
      },
      {
        "name": "myExhaustiveKnn",
        "kind": "exhaustiveKnn",
        "hnswParameters": None,
        "exhaustiveKnnParameters": {
          "metric": "cosine"
        }
      }
    ],
    "profiles": [
      {
        "name": "myHnswProfile",
        "algorithm": "myHnsw",
        "vectorizer": "myOpenAI"
      },
      {
        "name": "myExhaustiveKnnProfile",
        "algorithm": "myExhaustiveKnn",
        "vectorizer": "myOpenAI"
      }
    ],
    "vectorizers": [
      {
        "name": "myOpenAI",
        "kind": "azureOpenAI",
        "azureOpenAIParameters": {
          "resourceUri": OPENAI_SERVICE_NAME,
          "deploymentId": "text-embedding-ada-002",
          "apiKey": OpenAI_Service_Key,
          "authIdentity": None
        },
        "customWebApiParameters": None
      }
    ]
  }
}

r = requests.put(AZURE_SEARCH_ENDPOINT + "/indexes/" + index_name,
                 data=json.dumps(index_payload), headers=headers, params=params)
print(r.status_code)
# print(r.content)
print(r.ok)
#print(r.text)

# COMMAND ----------

import os
from dotenv import load_dotenv 
import docx,openai,backoff
import re,time
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient

from azure.storage.blob import BlobServiceClient, BlobClient
import io

load_dotenv()
# #QA
# openai.api_type = "azure"
# openai.api_base = "https://cogai-platformqeaca1.openai.azure.com/"
# openai.api_version = "2023-07-01-preview"
# openai.api_key = "7be43c7915db43ae86b7d66b2a532147"
# search_endpoint = "https://search-ai-platform-q-1.search.windows.net"
# search_key = AzureKeyCredential("JCsGhVp8ZjdybOoOK7Vvktdj1ZSCxoz6Ly1D151SiWAzSeAg2vQw")
# index_name = "index-genai-procuree-intent-vector"
# file_path = "https://ststpchatbotqncus1.blob.core.windows.net/procureechatbot-genai-q/Procuree%20Intents.docx?sp=r&st=2024-01-12T11:11:23Z&se=2026-12-30T19:11:23Z&spr=https&sv=2022-11-02&sr=b&sig=Nu3q%2B094QHwolEtY%2Bj5Ty%2FyQaZj7Q20a3WTsMSKaSlg%3D"

#Dev
# openai.api_type = "azure"
# openai.api_base = "https://cogai-platformdeus21.openai.azure.com/"
# openai.api_version = "2023-07-01-preview"
# openai.api_key = "26bb5489177f49c285ead060b32f00fe"
# search_endpoint = "https://search-ai-platform-d-1.search.windows.net"
# search_key = AzureKeyCredential("11eBB7I8vxMxNnb2ChiG6LYrvXdY4uDqwYLKxKubCKAzSeBN1G1u")
# index_name = "index-genai-procuree-intent-vector"
# file_path = "https://staiplatformdeus21.blob.core.windows.net/intentcontainer/Procuree%20Intents.docx?sp=r&st=2023-12-12T08:49:26Z&se=2026-12-12T16:49:26Z&spr=https&sv=2022-11-02&sr=b&sig=znaDaoI%2BKWWQ3%2BZCdR1KzOrkup8kwQArW0oW3vh2KO4%3D"

#Dev
openai.api_type = "azure" 
openai.api_base = f"{COGAI_URL}" 
openai.api_version = "2023-07-01-preview"
openai.api_key = f"{COGAIAPI_KEY}" 
search_endpoint = f"{searchservice_url}" 
search_key = AzureKeyCredential(f"{searchservice_apiKey}")
index_name =  f"{index_name}"  # "index-genai-procuree-intent-vector"
file_path = f"{MANUFACTURING_INTENT_FILEPATH}"

search_client = SearchClient(endpoint=search_endpoint,
                                    index_name=index_name,
                                    credential=search_key)

EMBEDDING_MODEL = "text-embedding-ada-002"

@backoff.on_exception(backoff.expo, openai.error.RateLimitError)

def get_embedding(text: str, model: str=EMBEDDING_MODEL) -> list[float]:

    result = openai.Embedding.create(

      engine=model,

      input=text

    )

    return result["data"][0]["embedding"]

def remove_from_index(filename,search_client:SearchClient):
    while True:
        filter = None if filename == None else f"type eq '{filename}'"
        r = search_client.search("", filter=filter, top=1000, include_total_count=True)
        if r.get_count() == 0:
            break
        r = search_client.delete_documents(documents=[{ "id": d["id"] } for d in r])
        print(f"\tRemoved {len(r)} sections from index")
        # It can take a few seconds for search results to reflect changes, so wait a bit
        time.sleep(2)


def read_docx(file_path):
    blob_client = BlobClient.from_blob_url(file_path)
    blob_data = blob_client.download_blob()
    blob_content = blob_data.readall()
    byte_stream = io.BytesIO(blob_content)
    doc = docx.Document(byte_stream)
    return doc

def extract_all_sections_text(file_path):
    doc = read_docx(file_path)
    section_wise_text = []
    section_text = ""

    for paragraph in doc.paragraphs:
        if "##ENDOFFEATURE##" in paragraph.text:
            section_wise_text.append(section_text)
            section_text = ""
        else:
            section_text += paragraph.text + " "

    # Append the last section
    section_wise_text.append(section_text)
    return section_wise_text

page_wise_text = extract_all_sections_text(file_path)

remove_from_index(None,search_client=search_client)

batch = []
j = 0


for i,row in enumerate(page_wise_text):
    batch.append({
        "id": re.sub("[^0-9a-zA-Z_-]","_",f"{file_path}-{i}"),
        "chunk": row,
        "chunkVector": get_embedding(row)
    })
    j += 1
    if j % 1000 == 0:
        results = search_client.upload_documents(documents=batch)
        succeeded = sum([1 for r in results if r.succeeded])
        print(f"\tIndexed {len(results)} sections, {succeeded} succeeded")
        batch = []

if len(batch) > 0:
        results = search_client.upload_documents(documents=batch)
        succeeded = sum([1 for r in results if r.succeeded])
        print(f"\tIndexed {len(results)} sections, {succeeded} succeeded")

# COMMAND ----------

# import os
# import io
# from dotenv import load_dotenv 
# import docx,openai,backoff
# import re,time
# from azure.core.credentials import AzureKeyCredential
# from azure.search.documents import SearchClient
# from  azure.storage.blob  import  BlobClient
# load_dotenv()
# #QA
# # openai.api_type = "azure"
# # openai.api_base = "https://cogai-platformqeaca1.openai.azure.com/"
# # openai.api_version = "2023-07-01-preview"
# # openai.api_key = "7be43c7915db43ae86b7d66b2a532147"
# # search_endpoint = "https://search-ai-platform-q-1.search.windows.net"
# # search_key = AzureKeyCredential("JCsGhVp8ZjdybOoOK7Vvktdj1ZSCxoz6Ly1D151SiWAzSeAg2vQw")
# # index_name = "index-genai-procuree-intent-vector"
# # file_path = "https://ststpchatbotqncus1.blob.core.windows.net/procureechatbot-genai-q/Procuree%20Intents.docx?sp=r&st=2024-01-12T11:11:23Z&se=2026-12-30T19:11:23Z&spr=https&sv=2022-11-02&sr=b&sig=Nu3q%2B094QHwolEtY%2Bj5Ty%2FyQaZj7Q20a3WTsMSKaSlg%3D"

# #Dev
# # openai.api_type = "azure"
# # openai.api_base = "https://cogai-platformdeus21.openai.azure.com/"  
# # openai.api_version = "2023-07-01-preview"
# # openai.api_key = "26bb5489177f49c285ead060b32f00fe"
# # search_endpoint = "https://search-ai-platform-d-1.search.windows.net"
# # search_key = AzureKeyCredential("11eBB7I8vxMxNnb2ChiG6LYrvXdY4uDqwYLKxKubCKAzSeBN1G1u")
# # index_name = "index-genai-manufacturing-intent-vector"
# # file_path = "https://staiplatformdeus21.blob.core.windows.net/manufacturing-intent/Manufacturing%20Intents.docx?sp=r&st=2024-02-26T13:54:54Z&se=2026-02-27T21:54:54Z&spr=https&sv=2022-11-02&sr=b&sig=G42G4uvlot46WahDRIWGK9j%2Bze9sfZjEHP8M6mZcL6g%3D"

# #Dev
# openai.api_type = "azure" 
# openai.api_base = f"{COGAI_URL}" 
# openai.api_version = "2023-07-01-preview"
# openai.api_key = f"{COGAIAPI_KEY}" 
# search_endpoint = f"{searchservice_url}" 
# search_key = AzureKeyCredential(f"{searchservice_apiKey}")
# index_name =  f"{index_name}"  # "index-genai-manufacturing-intent-vector-v1" 
# file_path = f"{MANUFACTURING_INTENT_FILEPATH}"


# search_client = SearchClient(endpoint=search_endpoint,
#                                     index_name=index_name,
#                                     credential=search_key)

# EMBEDDING_MODEL = "text-embedding-ada-002"

# @backoff.on_exception(backoff.expo, openai.error.RateLimitError)

# def get_embedding(text: str, model: str=EMBEDDING_MODEL) -> list[float]:

#     result = openai.Embedding.create(

#       engine=model,

#       input=text

#     )

#     return result["data"][0]["embedding"]


# def remove_from_index(filename,search_client:SearchClient):
#     while True:
#         filter = None if filename == None else f"type eq '{filename}'"
#         r = search_client.search("", filter=filter, top=1000, include_total_count=True)
#         if r.get_count() == 0:
#             break
#         r = search_client.delete_documents(documents=[{ "id": d["id"] } for d in r])
#         print(f"\tRemoved {len(r)} sections from index")
#         # It can take a few seconds for search results to reflect changes, so wait a bit
#         time.sleep(2)

# def read_docx(file_path):
#     blob_client = BlobClient.from_blob_url(file_path)
#     blob_data = blob_client.download_blob()
#     blob_content = blob_data.readall()
#     byte_stream = io.BytesIO(blob_content)
#     doc = docx.Document(byte_stream)
#     return doc
    
    
# def extract_all_pages_text(file_path):
#     doc = read_docx(file_path)
#     page_wise_text = []

#     current_page = 1
#     page_text = ""


#     for paragraph in doc.paragraphs:
#         if paragraph._element.xpath(".//w:lastRenderedPageBreak"):
#             page_wise_text.append(page_text)
#             page_text = ""
#             current_page += 1
#         page_text += paragraph.text + " "

#     # Append the last page
#     page_wise_text.append(page_text)
#     return page_wise_text




# page_wise_text = extract_all_pages_text(file_path)


# remove_from_index(None,search_client=search_client)


# batch = []
# j = 0


# for i,row in enumerate(page_wise_text):
#     batch.append({
#         "id": re.sub("[^0-9a-zA-Z_-]","_",f"{file_path}-{i}"),
#         "chunk": row,
#         "chunkVector": get_embedding(row)
        
#     })
#     j += 1
#     if j % 1000 == 0:
#         results = search_client.upload_documents(documents=batch)
#         succeeded = sum([1 for r in results if r.succeeded])
#         print(f"\tIndexed {len(results)} sections, {succeeded} succeeded")
#         batch = []

# if len(batch) > 0:
#         results = search_client.upload_documents(documents=batch)
#         succeeded = sum([1 for r in results if r.succeeded])
#         print(f"\tIndexed {len(results)} sections, {succeeded} succeeded")