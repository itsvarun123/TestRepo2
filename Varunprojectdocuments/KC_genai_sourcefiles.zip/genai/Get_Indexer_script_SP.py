# Databricks notebook source
searchservice_apiKey = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-apikey")


# COMMAND ----------

import requests
import json
searchservice_apiKey = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-apikey")
searchservice_url = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-url")

url = f"{searchservice_url}/indexers/indexer-genai-sp-manufacturing-vector/status?api-version=2023-10-01-Preview"   # 2020-06-30-Preview 2023-07-01-Preview  # 2023-10-01-Preview
payload = ""
headers = {
  'Content-Type': 'application/json',
  'api-key': f'{searchservice_apiKey}'
}
response = requests.request("GET", url, headers=headers, data=payload) 
print(response.text) 
