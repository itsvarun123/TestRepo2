# Databricks notebook source
# Set up Azure Cosmos DB SDK - Run only if necessary
# TODO:
# - Move it to Compute library

%pip install --upgrade azure-cosmos
%pip install azure.identity
%pip install azure-search-documents==11.6.0b1 #required to run AzureOpenAIVectorizer

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pull Key Vault Secrets, Azure Credentials and Cosmos DB info

# COMMAND ----------

from azure.cosmos import CosmosClient,exceptions,PartitionKey
from azure.identity import DefaultAzureCredential
from azure.core.credentials import AzureKeyCredential

# Access secrets from Azure KeyVault
## Cosmos DB Secrets
masterkey=dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cosmos-master-key")
cosmosendpoint=dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cosmos-endpoint")
database_name = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cosmos-database-name")
container_name = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "container-name-manufacturingmsglogs") # container_name = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "container-name-manufacturingmsglogs")
## Azure Search AI Secrets
searchservice_url = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-url")
searchservice_apiKey = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "search-service-apikey")
COG_SERVICES_NAME = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cog-service-name")
COG_SERVICES_KEY = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "cog-service-key")
## Azure Open AI Secrets
OpenAI_Service_Key = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "openai-service-key")
OPENAI_SERVICE_NAME = dbutils.secrets.get(scope = "scope-key-vault-genai", key = "openai-service-name")

# Initialize CosmosDB Client
cosmos_client=CosmosClient(f"{cosmosendpoint}",{'masterKey':f"{masterkey};"})

# Load Cosmos DB Collection and Container
database = cosmos_client.get_database_client(database_name)
print("database : ",database)
container=database.get_container_client(container_name)
print("container name : ",container)
# Construct Cosmos DB Connection String
cosdb_connString = f"AccountEndpoint={cosmosendpoint};AccountKey={masterkey};Database={database_name}"

# Initialize Azure Credentials
credential = AzureKeyCredential(searchservice_apiKey) if len(searchservice_apiKey) > 0 else DefaultAzureCredential()

# Set environment variables for Search AI
datasource_name = "datasource-genai-cosmos-manufacturing-vector"
skillset_name = "skillset-genai-cosmos-manufacturing-vector"
index_name ="index-genai-cosmos-manufacturing-vector"
indexer_name = "indexer-genai-cosmos-manufacturing-vector"

AZURE_SEARCH_ENDPOINT=f"{searchservice_url}"
AZURE_SEARCH_KEY=f"{searchservice_apiKey}"
AZURE_SEARCH_API_VERSION="2023-10-01-Preview"
OPENAI_DEPLOYMENT_ID="text-embedding-ada-002"

#Set API variables
headers = {'Content-Type': 'application/json', 'api-key': f'{searchservice_apiKey}'}
params = {'api-version': AZURE_SEARCH_API_VERSION}


# COMMAND ----------

# MAGIC %md # Drop Cosmos Container and Re-Create Container

# COMMAND ----------

database.delete_container(container_name)
print(f"Container {container_name} deleted.")
database.create_container(id=container_name,partition_key=PartitionKey(path="/user_id"))
print(f"Container {container_name} Recreated.")



# COMMAND ----------

# MAGIC %md
# MAGIC ## Drop Cosmos Index , datasource ,Skillset, Indexer

# COMMAND ----------

import requests

# Construct URL path
url_datasource = f"{searchservice_url}/datasources/{datasource_name}?api-version={AZURE_SEARCH_API_VERSION}" 
url_skillset = f"{searchservice_url}/skillsets/{skillset_name}?api-version={AZURE_SEARCH_API_VERSION}" 
url_index = f"{searchservice_url}/indexes/{index_name}?api-version={AZURE_SEARCH_API_VERSION}" 
url_indexer = f"{searchservice_url}/indexers/{indexer_name}?api-version={AZURE_SEARCH_API_VERSION}"

# Delete Operations
response_datasource = requests.delete(url_datasource, headers=headers)
response_skillset = requests.delete(url_skillset, headers=headers)
response_index = requests.delete(url_index, headers=headers)
response_indexer = requests.delete(url_indexer, headers=headers)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Connect Cosmos DB to a data source in Azure AI Search

# COMMAND ----------

from azure.search.documents.indexes import SearchIndexerClient
from azure.search.documents.indexes.models import (
    SearchIndexerDataContainer,
    SearchIndexerDataSourceConnection,
    HighWaterMarkChangeDetectionPolicy
)

# Create Cosmos DB data source 
indexer_client = SearchIndexerClient(AZURE_SEARCH_ENDPOINT, credential)
container = SearchIndexerDataContainer(
    name= container_name, 
    query=f"SELECT  t1.id AS chunk_id,t1.user_id as userid,humanMessage.data.content AS human,aiMessage.data.content AS content,t1.docs as chunks,t1.queryType as querytype,t1.fromCache as fromCache,t1._ts as _ts FROM  {container_name} t1 JOIN humanMessage IN t1.messages JOIN aiMessage IN t1.messages WHERE t1.queryType='QnA' and t1.fromCache=false and (humanMessage.type = 'human' AND aiMessage.type = 'ai')  ORDER BY t1._ts DESC")
data_source_connection = SearchIndexerDataSourceConnection(
    name=f"{datasource_name}",
    type="cosmosdb",
    connection_string=f"{cosdb_connString};Database={database_name};",
    container=container
)
data_source = indexer_client.create_or_update_data_source_connection(data_source_connection)

print(f"Data source '{data_source.name}' created or updated")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create a search index

# COMMAND ----------

from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchField,
    SearchFieldDataType,
    VectorSearch,
    HnswAlgorithmConfiguration,
    HnswParameters,
    VectorSearchAlgorithmMetric,
    ExhaustiveKnnAlgorithmConfiguration,
    ExhaustiveKnnParameters,
    VectorSearchProfile,
    AzureOpenAIVectorizer,
    AzureOpenAIParameters,
    SemanticConfiguration,
    SemanticSearch,
    SemanticPrioritizedFields,
    SemanticField,
    SearchIndex
)

# Create a search index definition
index_client = SearchIndexClient(endpoint=AZURE_SEARCH_ENDPOINT, credential=credential)  
fields = [  
    SearchField(name="id", type=SearchFieldDataType.String, sortable=True, filterable=True, facetable=True),  
    SearchField(name="userid", type=SearchFieldDataType.String, searchable=True, sortable=False, filterable=True, facetable=False),
    SearchField(name="human", type=SearchFieldDataType.String, searchable=True, sortable=False, filterable=True, facetable=False),
    SearchField(name="language", type=SearchFieldDataType.String, searchable=True, sortable=False, filterable=True, facetable=False),
    SearchField(name="content", type=SearchFieldDataType.String, searchable=True, sortable=False, filterable=False, facetable=False),
    SearchField(name="querytype", type=SearchFieldDataType.String, searchable=True, sortable=False, filterable=False, facetable=False),
    SearchField(name="chunks", type=SearchFieldDataType.Collection(SearchFieldDataType.String), searchable=False, sortable=False, filterable=False, facetable=False),  
    SearchField(name="chunk_id", type=SearchFieldDataType.String, key=True, sortable=True, filterable=True, facetable=True, analyzer_name="keyword"),  
    SearchField(name="chunk", type=SearchFieldDataType.String, sortable=False, filterable=False, facetable=False),  
    SearchField(name="vector", type=SearchFieldDataType.Collection(SearchFieldDataType.Single), vector_search_dimensions=1536, vector_search_profile_name="myHnswProfile"),  
]  
  
# Configure the vector search configuration  
vector_search = VectorSearch(  
    algorithms=[  
        HnswAlgorithmConfiguration(  
            name="myHnsw",  
            parameters=HnswParameters(  
                m=4,  
                ef_construction=400,  # Review parameter
                ef_search=500,  # Review parameter
                metric=VectorSearchAlgorithmMetric.COSINE,  
            ),  
        ),  
        ExhaustiveKnnAlgorithmConfiguration(  
            name="myExhaustiveKnn",  
            parameters=ExhaustiveKnnParameters(  
                metric=VectorSearchAlgorithmMetric.COSINE,  
            ),  
        ),  
    ],  
    profiles=[  
        VectorSearchProfile(  
            name="myHnswProfile",  
            algorithm_configuration_name="myHnsw",  
            vectorizer="myOpenAI",  
        ),  
        VectorSearchProfile(  
            name="myExhaustiveKnnProfile",  
            algorithm_configuration_name="myExhaustiveKnn",  
            vectorizer="myOpenAI",  
        ),  
    ],  
    vectorizers=[  
        AzureOpenAIVectorizer(  
            name="myOpenAI",  
            kind="azureOpenAI",  
            azure_open_ai_parameters=AzureOpenAIParameters(  
                resource_uri=OPENAI_SERVICE_NAME,  
                deployment_id=OPENAI_DEPLOYMENT_ID,  
                api_key=OpenAI_Service_Key,
            ),  
        ),  
    ],  
)  
  
semantic_config = SemanticConfiguration(  
    name="my-semantic-config",  
    prioritized_fields=SemanticPrioritizedFields(  
        content_fields=[SemanticField(field_name="human")] # This allows for the semantic search to use the question rather than the answe from cache.
    ),  
)  
  
# Create the semantic search with the configuration  
semantic_search = SemanticSearch(configurations=[semantic_config])  
  
# Create the search index
index = SearchIndex(name=index_name, fields=fields, vector_search=vector_search, semantic_search=semantic_search)  
result = index_client.create_or_update_index(index)  
print(f"{result.name} created")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Create a skillset

# COMMAND ----------

from azure.search.documents.indexes import SearchIndexerClient
from azure.search.documents.indexes.models import (
    SplitSkill,
    LanguageDetectionSkill,
    InputFieldMappingEntry,
    OutputFieldMappingEntry,
    AzureOpenAIEmbeddingSkill,
    SearchIndexerIndexProjections,
    SearchIndexerIndexProjectionSelector,
    SearchIndexerIndexProjectionsParameters,
    IndexProjectionMode,
    SearchIndexerSkillset,
    CognitiveServicesAccount,
    CognitiveServicesAccountKey
)

# Create a skillset
language_skill = LanguageDetectionSkill(
    description="Language detection skill to detect language code",
    context="/document",
    inputs=[  
        InputFieldMappingEntry(name="text", source="/document/human"), # Detects the human question language
    ],
    outputs=[  
        OutputFieldMappingEntry(name="languageCode", target_name="language")
    ],
)

split_skill = SplitSkill(  
    description="Split skill to chunk documents",  
    text_split_mode="pages",  
    context="/document",  
    maximum_page_length=5000, #5k recommended by Giorgio (MSFT) to reduce number of chunks on caching
    page_overlap_length=0,  # No overlap required to split Cosmos DB records that are used for caching answer results (they are not fed to LLMs for text completion task)
    inputs=[  
        InputFieldMappingEntry(name="text", source="/document/human"), # Chunks the human question for embedding
    ],  
    outputs=[  
        OutputFieldMappingEntry(name="textItems", target_name="pages")
    ],  
)  
  
embedding_skill = AzureOpenAIEmbeddingSkill(  
    description="Skill to generate embeddings via Azure OpenAI",  
    context="/document/pages/*",  
    resource_uri=OPENAI_SERVICE_NAME,  
    deployment_id=OPENAI_DEPLOYMENT_ID,  
    api_key=OpenAI_Service_Key,  
    inputs=[  
        InputFieldMappingEntry(name="text", source="/document/pages/*"),  
    ],  
    outputs=[  
        OutputFieldMappingEntry(name="embedding", target_name="vector")  
    ],  
)

cognitive_search = CognitiveServicesAccountKey(
        key=COG_SERVICES_KEY, 
        description=COG_SERVICES_NAME )



  
index_projections = SearchIndexerIndexProjections(  
    selectors=[  
        SearchIndexerIndexProjectionSelector(  
            target_index_name=index_name,  
            parent_key_field_name="id",  
            source_context="/document/pages/*",  
            mappings=[
                InputFieldMappingEntry(name="userid", source="/document/userid"),
                InputFieldMappingEntry(name="human", source="/document/human"),
                InputFieldMappingEntry(name="content", source="/document/content"),
                InputFieldMappingEntry(name="language", source="/document/language"),
                InputFieldMappingEntry(name="querytype", source="/document/querytype"),
                InputFieldMappingEntry(name="chunks", source="/document/chunks"),
                InputFieldMappingEntry(name="chunk", source="/document/pages/*"),  
                InputFieldMappingEntry(name="vector", source="/document/pages/*/vector"),
            ],  
        ),  
    ],  
    parameters=SearchIndexerIndexProjectionsParameters(  
        projection_mode=IndexProjectionMode.SKIP_INDEXING_PARENT_DOCUMENTS  
    ),  
)  
  
skillset = SearchIndexerSkillset(  
    name=skillset_name,  
    description="Skillset to chunk documents and generating embeddings",  
    skills=[language_skill, split_skill, embedding_skill],  
    index_projections=index_projections,
    cognitive_services_account=cognitive_search
)  
  
client = SearchIndexerClient(AZURE_SEARCH_ENDPOINT, credential)  
client.create_or_update_skillset(skillset)  
print(f"{skillset.name} created")  


# COMMAND ----------

# MAGIC %md
# MAGIC ## Create an indexer

# COMMAND ----------

from azure.search.documents.indexes.models import (
    SearchIndexer,
    FieldMapping,
    IndexingParameters,
    IndexingParametersConfiguration,
    HighWaterMarkChangeDetectionPolicy
)

# Create an indexer  
indexer = SearchIndexer(  
    name=indexer_name,  
    description="Indexer to index documents and generate embeddings",  
    skillset_name=skillset_name,  
    target_index_name=index_name,  
    data_source_name=data_source.name,
    schedule= { "interval" : "PT30M"},
    parameters=IndexingParameters(
      configuration=IndexingParametersConfiguration(execution_environment="private", parsing_mode=None, excluded_file_name_extensions=None, indexed_file_name_extensions=None, fail_on_unsupported_content_type=None, fail_on_unprocessable_document=None, index_storage_metadata_only_for_oversized_documents=None, first_line_contains_headers=None, data_to_extract=None, image_action=None, allow_skillset_to_read_file_data=None, pdf_text_rotation_algorithm=None)
      ),
    # Map the metadata_storage_name field to the title field in the index to display the PDF title in the search results  
    # field_mappings=[FieldMapping(source_field_name="metadata_storage_name", target_field_name="title")]  
)  
  
indexer_result = indexer_client.create_or_update_indexer(indexer)
  
# Run the indexer  
indexer_client.run_indexer(indexer_name)  
print(f' {indexer_name} created')
