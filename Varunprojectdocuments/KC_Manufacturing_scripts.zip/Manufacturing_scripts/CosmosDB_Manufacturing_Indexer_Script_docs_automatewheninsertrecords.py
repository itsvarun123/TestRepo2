# Databricks notebook source
searchservice_url = "https://search-ai-platform-d-1.search.windows.net"
searchservice_apiKey = "11eBB7I8vxMxNnb2ChiG6LYrvXdY4uDqwYLKxKubCKAzSeBN1G1u"

datasource_name = "datasource-genai-cosmos-manufacturingv1"
skillset_name = "skillset-genai-cosmos-manufacturingv1"
index_name ="index-genai-cosmos-manufacturingv1"
indexer_name = "indexer-genai-cosmos-manufacturingv1"

database="ApiGenAIQnADB"
container="ManufacturingMsgLogs"

database_name="ApiGenAIQnADB"
container_name="ManufacturingMsgLogs"

cosdb_connString = f"AccountEndpoint=https://cosdb-ai-platform-d-eus2-1.documents.azure.com:443/;AccountKey=DWkYzVkVPSJDlHjwcKUruVf6b8dBbqKC1rt1N7U6yLP9IaEVFpKDFNrSEI3trI775Op6M6MQTqNLACDbBOZiIQ==;Database={database};"


AZURE_SEARCH_ENDPOINT="https://search-ai-platform-d-1.search.windows.net"
AZURE_SEARCH_KEY="11eBB7I8vxMxNnb2ChiG6LYrvXdY4uDqwYLKxKubCKAzSeBN1G1u"
AZURE_SEARCH_API_VERSION="2023-07-01-Preview"
headers = {'Content-Type': 'application/json','api-key': AZURE_SEARCH_KEY}
params = {'api-version': AZURE_SEARCH_API_VERSION}

COG_SERVICES_NAME="cogai-platformdeus22"
COG_SERVICES_KEY="e5a5d0724a0a42dc843309be64019b1e"


##################
print(database)
print(container)
print(searchservice_url)
url = f"{searchservice_url}/datasources?api-version=2020-06-30-Preview" 
print(url)

api_key = f'{searchservice_apiKey}'
print(api_key)

credentials = f"{cosdb_connString}"
print(credentials)

datasrc_name= f"{datasource_name}"
print(datasrc_name)
print(skillset_name)
ind_name= f"{index_name}"
print(ind_name)
indxr_name= f"{indexer_name}"
print(indxr_name)

print(database)
container_name=f"{container}"
print(container_name) 


# COMMAND ----------

# MAGIC %md Datasource script creation

# COMMAND ----------

import requests
import json
url = f"{searchservice_url}/datasources?api-version=2020-06-30-Preview" 
payload = json.dumps({
  "name": f"{datasource_name}",
  "type": "cosmosdb",
  "credentials": {
    "connectionString": f"{cosdb_connString};Database={database};"
  },
  "container": {
    "name": f"{container}",
    "query": "SELECT distinct t1.id AS id,m.type AS messagetype, m.data.content AS content,t1.docs as chunks,t1.queryType as querytype,t1._ts as _ts FROM ManufacturingMsgLogs t1 join m IN t1.messages where  t1._ts>@HighWaterMark ORDER BY t1._ts DESC   "
  },
  "dataChangeDetectionPolicy": {
    "@odata.type": "#Microsoft.Azure.Search.HighWaterMarkChangeDetectionPolicy",
    "highWaterMarkColumnName": "_ts"
  }
  ,
  "dataDeletionDetectionPolicy": {
        "@odata.type": "#Microsoft.Azure.Search.SoftDeleteColumnDeletionDetectionPolicy", #SoftDeleteColumnDeletionDetectionPolicy  SoftDeleteTombstonePolicy
        "softDeleteColumnName": "content",
        "softDeleteMarkerValue": "true"
    }
})

headers = {
  'Content-Type': 'application/json',
  'api-key': f'{searchservice_apiKey}'
}
response = requests.request("POST", url, headers=headers, data=payload)
print(response.text)

# COMMAND ----------

# MAGIC %md Skillset script Creation

# COMMAND ----------

# Create a skillset
skillset_payload = {
    "name": skillset_name,
    "description": "Extract entities, detect language and extract key-phrases",
    "skills":
    [
        {
            "@odata.type": "#Microsoft.Skills.Vision.OcrSkill",
            "description": "Extract text (plain and structured) from image.",
            "context": "/document/normalized_images/*",
            "defaultLanguageCode": "en",
            "detectOrientation": True,
            "inputs": [
                {
                  "name": "image",
                  "source": "/document/normalized_images/*"
                }
            ],
                "outputs": [
                {
                  "name": "text",
                  "targetName" : "images_text"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.MergeSkill",
            "description": "Create merged_text, which includes all the textual representation of each image inserted at the right location in the content field. This is useful for PDF and other file formats that supported embedded images.",
            "context": "/document",
            "insertPreTag": " ",
            "insertPostTag": " ",
            "inputs": [
                {
                  "name":"text", "source": "/document/content"
                },
                {
                  "name": "itemsToInsert", "source": "/document/normalized_images/*/images_text"
                },
                {
                  "name":"offsets", "source": "/document/normalized_images/*/contentOffset"
                }
            ],
            "outputs": [
                {
                  "name": "mergedText", 
                  "targetName" : "merged_text"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.LanguageDetectionSkill",
            "context": "/document",
            "description": "If you have multilingual content, adding a language code is useful for filtering",
            "inputs": [
                {
                  "name": "text",
                  "source": "/document/content"
                }
            ],
            "outputs": [
                {
                  "name": "languageCode",
                  "targetName": "language"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.SplitSkill",
            "context": "/document",
            "textSplitMode": "pages",
            "maximumPageLength": 5000, # 5000 is default
            "defaultLanguageCode": "en",
            "inputs": [
                {
                    "name": "text",
                    "source": "/document/merged_text"
                },
                {
                    "name": "languageCode",
                    "source": "/document/language"
                }
            ],
            "outputs": [
                {
                    "name": "textItems",
                    "targetName": "pages"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.KeyPhraseExtractionSkill",
            "context": "/document/pages/*",
            "maxKeyPhraseCount": 2,
            "defaultLanguageCode": "en",
            "inputs": [
                {
                    "name": "text", 
                    "source": "/document/pages/*"
                },
                {
                    "name": "languageCode",
                    "source": "/document/language"
                }
            ],
            "outputs": [
                {
                    "name": "keyPhrases",
                    "targetName": "keyPhrases"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.V3.EntityRecognitionSkill",
            "context": "/document/pages/*",
            "categories": ["Person", "Location", "Organization", "DateTime", "URL", "Email"],
            "minimumPrecision": 0.5, 
            "defaultLanguageCode": "en",
            "inputs": [
                {
                    "name": "text", 
                    "source":"/document/pages/*"
                },
                {
                    "name": "languageCode",
                    "source": "/document/language"
                }
            ],
            "outputs": [
                {
                    "name": "persons", 
                    "targetName": "persons"
                },
                {
                    "name": "locations", 
                    "targetName": "locations"
                },
                {
                    "name": "organizations", 
                    "targetName": "organizations"
                },
                {
                    "name": "dateTimes", 
                    "targetName": "dateTimes"
                },
                {
                    "name": "urls", 
                    "targetName": "urls"
                },
                {
                    "name": "emails", 
                    "targetName": "emails"
                }
            ]
        }
    ],
    "cognitiveServices": {
        "@odata.type": "#Microsoft.Azure.Search.CognitiveServicesByKey",
        "description": COG_SERVICES_NAME,
        "key": COG_SERVICES_KEY
    }
}

r = requests.put(AZURE_SEARCH_ENDPOINT + "/skillsets/" + skillset_name,
                 data=json.dumps(skillset_payload), headers=headers, params=params)
print(r.status_code)
print(r.ok)

print(r.text)

# COMMAND ----------

# MAGIC %md Index and Semantic script creation

# COMMAND ----------

# Create an index
# Queries operate over the searchable fields and filterable fields in the index
index_payload = {
    "name": index_name,
    "fields": [
        {"name": "id", "type": "Edm.String", "key": "true", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false"},
        {"name": "title", "type": "Edm.String", "searchable": "true", "retrievable": "true", "facetable": "false", "filterable": "true", "sortable": "false"},
        {"name": "content", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false"},
        {"name": "messagetype", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "true", "filterable": "true","facetable": "false"},
        {"name": "querytype", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "true", "filterable": "true","facetable": "false"},
        {"name": "score", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false"},
        {"name": "comment", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false"},
        {"name": "chunks","type": "Collection(Edm.String)", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "language", "type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "true", "filterable": "true", "facetable": "true"},
        {"name": "name", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "location", "type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "images_text", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "keyPhrases", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "true"},
        {"name": "persons", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "locations", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "true"},
        {"name": "organizations", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "true"},
        {"name": "dateTimes", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "urls", "type": "Collection(Edm.String)", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "emails", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "false"}
    ],
    "semantic": {
      "configurations": [
        {
          "name": "my-semantic-config",
          "prioritizedFields": {
            "titleField": 
                {
                    "fieldName": "id"
                },
            "prioritizedContentFields": [
                {
                    "fieldName": "content"
                }
                ]
          }
        }
      ]
    }
}

r = requests.put(AZURE_SEARCH_ENDPOINT + "/indexes/" + index_name,
                 data=json.dumps(index_payload), headers=headers, params=params)
print(r.status_code)
print(r.ok)

# COMMAND ----------

# MAGIC %md Indexer Script Creation

# COMMAND ----------

import requests
import json

url = f"{searchservice_url}/indexers/{indexer_name}?api-version=2020-06-30-Preview"
payload = json.dumps({
  "name": f"{indexer_name}",
  "dataSourceName": f"{datasource_name}",
  "targetIndexName": f"{index_name}",
  "schedule" : { "interval" : "PT5M"},  
  "parameters": {
        "configuration": {"assumeOrderByHighWaterMarkColumn" : True}
        },
  "fieldMappings": [
    {
      "sourceFieldName": "id",
      "targetFieldName": "id",
      "mappingFunction": {
       "name": "base64Encode"
      }
    },
    {
      "sourceFieldName": "content",
      "targetFieldName": "content"
    },
    {
      "sourceFieldName": "chunks",
      "targetFieldName": "chunks"
    },
    {
      "sourceFieldName": "messagetype",
      "targetFieldName": "messagetype"
    },
    {
      "sourceFieldName": "querytype",
      "targetFieldName": "querytype"
    }


  ]
})
headers = {
  'Content-Type': 'application/json',
  'api-key': f'{searchservice_apiKey}'
}

response = requests.request("PUT", url, headers=headers, data=payload)
print(response.text)