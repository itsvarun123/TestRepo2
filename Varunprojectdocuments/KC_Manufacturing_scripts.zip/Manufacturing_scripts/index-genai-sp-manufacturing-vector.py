# Databricks notebook source
searchservice_url = "https://search-ai-platform-d-1.search.windows.net"
searchservice_apiKey = "11eBB7I8vxMxNnb2ChiG6LYrvXdY4uDqwYLKxKubCKAzSeBN1G1u"

datasource_name = "datasource-genai-sp-manufacturing-vector1"
skillset_name = "skillset-genai-sp-manufacturing-vector1"
index_name ="index-genai-sp-manufacturing-vector1"
indexer_name = "indexer-genai-sp-manufacturing-vector1"

blob_connString =f"DefaultEndpointsProtocol=https;AccountName=staiplatformdeus21;AccountKey=2t4+4Tb8k4DlhrY3MTadKu86a9xrOpMlFXHV/Q8dsrw2zoeGJz5sb4f4oCF2A4ghmS9+ND4ibt5o+ASt1/IwiQ==;EndpointSuffix=core.windows.net"

DATASOURCE_CONNECTION_STRING ="DefaultEndpointsProtocol=https;AccountName=staiplatformdeus21;AccountKey=2t4+4Tb8k4DlhrY3MTadKu86a9xrOpMlFXHV/Q8dsrw2zoeGJz5sb4f4oCF2A4ghmS9+ND4ibt5o+ASt1/IwiQ==;EndpointSuffix=core.windows.net"

DATASOURCE_SAS_TOKEN = "?sv=2022-11-02&ss=bfqt&srt=sco&sp=rwlacupx&se=2023-10-09T15:29:58Z&st=2023-10-09T07:29:58Z&spr=https&sig=cJ99fJkjEFwy7G%2ByBZPF%2FG%2BM0X4xOALgDdPhDJVkYxg%3D"

BLOB_CONTAINER_NAME = "manufacturing"

AZURE_SEARCH_ENDPOINT="https://search-ai-platform-d-1.search.windows.net"
AZURE_SEARCH_KEY="11eBB7I8vxMxNnb2ChiG6LYrvXdY4uDqwYLKxKubCKAzSeBN1G1u"
AZURE_SEARCH_API_VERSION="2023-10-01-Preview"


headers = {'Content-Type': 'application/json','api-key': AZURE_SEARCH_KEY}
params = {'api-version': AZURE_SEARCH_API_VERSION}

COG_SERVICES_NAME="cogai-platformdeus22"
COG_SERVICES_KEY="e5a5d0724a0a42dc843309be64019b1e"

ApplicationId="0578a586-4ed5-42c9-b1b9-1a055534beae"

OpenAI_Service_Key= "181c1dd05bbe474c9a5004b3bbcc39af"
OPENAI_SERVICE_NAME="https://cogai-platformdeaca3.openai.azure.com"

##################
# print(searchservice_url)
# url = f"{searchservice_url}/datasources?api-version=2020-06-30-Preview" 
# print(url)

api_key = f'{searchservice_apiKey}'
print(api_key)

#credentials = f"{cosdb_connString}"
#print(credentials)

datasrc_name= f"{datasource_name}"
print(datasrc_name)
print(skillset_name)
ind_name= f"{index_name}"
print(ind_name)
indexer_name= f"{indexer_name}"
print(indexer_name)

print (headers)
print(params)

import os
import json
import requests
#from dotenv import load_dotenv
#load_dotenv("credentials.env") 


# COMMAND ----------

import requests
import json

url=f"{searchservice_url}/datasources?api-version=2023-10-01-Preview"    #  2020-06-30-Preview
payload = json.dumps({
  "name": datasource_name,
  "type": "sharepoint",
  "credentials": {   
    "connectionString": f"SharepointOnlineEndpoint=https://kimberlyclark.sharepoint.com/teams/a693;ApplicationId={ApplicationId}"
  },
  "container": {
    "name": "useQuery",
    "query" : "includeLibrary=https://kimberlyclark.sharepoint.com/teams/a693/P2015BestPractices/Forms/AllItems.aspx"
  }
})
headers = {
  'Content-Type': 'application/json',
  'api-key': '11eBB7I8vxMxNnb2ChiG6LYrvXdY4uDqwYLKxKubCKAzSeBN1G1u'
}
response = requests.request("POST", url, headers=headers, data=payload)

print(response.text)


# COMMAND ----------

# Create an index
# Queries operate over the searchable fields and filterable fields in the index
index_payload = {
    "name": index_name,
    "fields": [
        {"name": "id", "type": "Edm.String", "key": "true", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false","analyzer":"keyword"},
        {"name": "title", "type": "Edm.String", "searchable": "true", "retrievable": "true", "facetable": "false", "filterable": "true", "sortable": "false"},
        {"name": "content", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false"},
        {"name": "chunk","type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "language", "type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "true", "filterable": "true", "facetable": "true"},
        {"name": "name", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "location", "type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "vectorized", "type": "Edm.Boolean", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "images_text", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "keyPhrases", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "true"},
        {"name": "persons", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "urls", "type": "Collection(Edm.String)", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "organizations", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "true"},
        {"name": "emails", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "false"},
        {"name": "chunkVector", "type": "Collection(Edm.Single)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false","dimensions":1536,"vectorSearchProfile":"myHnswProfile"},
        
    ],
    "semantic": {
      "configurations": [
        {
          "name": "my-semantic-config",
          "prioritizedFields": {
            "titleField": 
                {
                    "fieldName": "title"
                },
            "prioritizedContentFields": [
                {
                    "fieldName": "content"
                }
                ]
          }
        }
      ]
    },
  "vectorSearch": {
    "algorithms": [
      {
        "name": "myHnsw",
        "kind": "hnsw",
        "hnswParameters": {
          "metric": "cosine",
          "m": 4,
          "efConstruction": 400,
          "efSearch": 100
        },
        "exhaustiveKnnParameters": None
      },
      {
        "name": "myExhaustiveKnn",
        "kind": "exhaustiveKnn",
        "hnswParameters": None,
        "exhaustiveKnnParameters": {
          "metric": "cosine"
        }
      }
    ],
    "profiles": [
      {
        "name": "myHnswProfile",
        "algorithm": "myHnsw",
        "vectorizer": "myOpenAI"
      },
      {
        "name": "myExhaustiveKnnProfile",
        "algorithm": "myExhaustiveKnn",
        "vectorizer": "myOpenAI"
      }
    ],
    "vectorizers": [
      {
        "name": "myOpenAI",
        "kind": "azureOpenAI",
        "azureOpenAIParameters": {
          "resourceUri": OPENAI_SERVICE_NAME,
          "deploymentId": "text-embedding-ada-002",
          "apiKey": OpenAI_Service_Key,
          "authIdentity": None
        },
        "customWebApiParameters": None
      }
    ]
  }
}

r = requests.put(AZURE_SEARCH_ENDPOINT + "/indexes/" + index_name,
                 data=json.dumps(index_payload), headers=headers, params=params)
print(r.status_code)
# print(r.content)
print(r.ok)
#print(r.text) 

# COMMAND ----------

# Edit the null value in the skillset payload
# Replcae "null" with None in the last few lines of code

# Create a skillset
skillset_payload = {
    "name": skillset_name,
    "description": "Extract entities, detect language and extract key-phrases",
    "skills":
    [
        {
            "@odata.type": "#Microsoft.Skills.Vision.OcrSkill",
            "description": "Extract text (plain and structured) from image.",
            "context": "/document/normalized_images/*",
            "defaultLanguageCode": "en",
            "detectOrientation": True,
            "inputs": [
                {
                  "name": "image",
                  "source": "/document/normalized_images/*"
                }
            ],
                "outputs": [
                {
                  "name": "text",
                  "targetName" : "images_text"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.MergeSkill",
            "description": "Create merged_text, which includes all the textual representation of each image inserted at the right location in the content field. This is useful for PDF and other file formats that supported embedded images.",
            "context": "/document",
            "insertPreTag": " ",
            "insertPostTag": " ",
            "inputs": [
                {
                  "name":"text", "source": "/document/content"
                },
                {
                  "name": "itemsToInsert", "source": "/document/normalized_images/*/images_text"
                },
                {
                  "name":"offsets", "source": "/document/normalized_images/*/contentOffset"
                }
            ],
            "outputs": [
                {
                  "name": "mergedText", 
                  "targetName" : "merged_text"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.LanguageDetectionSkill",
            "context": "/document",
            "description": "If you have multilingual content, adding a language code is useful for filtering",
            "inputs": [
                {
                  "name": "text",
                  "source": "/document/content"
                }
            ],
            "outputs": [
                {
                  "name": "languageCode",
                  "targetName": "language"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.SplitSkill",
            "context": "/document",
            "textSplitMode": "pages",
            "maximumPageLength": 5000, # 5000 is default
            "pageOverlapLength": 200,
            "defaultLanguageCode": "en",
            "inputs": [
                {
                    "name": "text",
                    "source": "/document/merged_text"
                },
                {
                    "name": "languageCode",
                    "source": "/document/language"
                }
            ],
            "outputs": [
                {
                    "name": "textItems",
                    "targetName": "pages"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.KeyPhraseExtractionSkill",
            "context": "/document/pages/*",
            "maxKeyPhraseCount": 2,
            "defaultLanguageCode": "en",
            "inputs": [
                {
                    "name": "text", 
                    "source": "/document/pages/*"
                },
                {
                    "name": "languageCode",
                    "source": "/document/language"
                }
            ],
            "outputs": [
                {
                    "name": "keyPhrases",
                    "targetName": "keyPhrases"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.V3.EntityRecognitionSkill",
            "context": "/document/pages/*",
            "categories": ["Person", "URL", "Email"],
            "minimumPrecision": 0.5, 
            "defaultLanguageCode": "en",
            "inputs": [
                {
                    "name": "text", 
                    "source":"/document/pages/*"
                },
                {
                    "name": "languageCode",
                    "source": "/document/language"
                }
            ],
            "outputs": [
                {
                    "name": "persons", 
                    "targetName": "persons"
                },                
                {
                    "name": "locations",
                    "targetName": "locations"
                },
                {
                    "name": "organizations",
                    "targetName": "organizations"
                },
                {
                    "name": "dateTimes",
                    "targetName": "dateTimes"
                },
                {
                    "name": "urls", 
                    "targetName": "urls"
                },
                {
                    "name": "emails", 
                    "targetName": "emails"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.AzureOpenAIEmbeddingSkill",
            "name": "EmbeddingSkill",
            "description": "Skill to generate embeddings via Azure OpenAI",
            "context": "/document/pages/*",
            "resourceUri": OPENAI_SERVICE_NAME,
            "apiKey": OpenAI_Service_Key,
            "deploymentId": "text-embedding-ada-002",
            "inputs": [
                {
                    "name": "text",
                    "source": "/document/pages/*"
                }
            ],
                "outputs": [
                    {
                        "name": "embedding",
                        "targetName": "embedding"
                    }
                ],
            "authIdentity": None
        },
    
    ],
    "cognitiveServices": {
        "@odata.type": "#Microsoft.Azure.Search.CognitiveServicesByKey",
        "description": COG_SERVICES_NAME,
        "key": COG_SERVICES_KEY
    },

  "knowledgeStore": None,
  "indexProjections": {
    "selectors": [
      {
        "targetIndexName": index_name,
        "parentKeyFieldName": "title",
        "sourceContext": "/document/pages/*",
        "mappings": [
          {
            "name": "content",
            "source": "/document/merged_text",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "chunkVector",
            "source": "/document/pages/*/embedding",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "chunk",
            "source": "/document/pages/*",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "images_text",
            "source": "/document/normalized_images/*/images_text",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "language",
            "source": "/document/language",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "keyPhrases",
            "source": "/document/pages/*/keyPhrases/*",
            "sourceContext": None,
            "inputs": []
          },{
            "name": "persons",
            "source": "/document/pages/*/persons/*",
            "sourceContext": None,
            "inputs": []
          },{
            "name": "urls",
            "source": "/document/pages/*/urls/*",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "emails",
            "source": "/document/pages/*/emails/*",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "name",
            "source": "/document/metadata_spo_item_name", #/document/pages/*   , metadata_storage_name , metadata_spo_item_name
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "location",
            "source": "/document/metadata_spo_item_weburi",  #  /document/pages/* ,  metadata_storage_path  , metadata_spo_item_weburi
            "sourceContext": None,
            "inputs": []
          },
        ]
      }
    ],
    "parameters": {
      "projectionMode": "skipIndexingParentDocuments"
    }
  },
  "encryptionKey": None
}

r = requests.put(AZURE_SEARCH_ENDPOINT + "/skillsets/" + skillset_name,
                 data=json.dumps(skillset_payload), headers=headers, params=params)
print(r.status_code)
# print(r.content)
print(r.ok) 
#print(r.text)


# COMMAND ----------

# Create an indexer
indexer_payload = {
    "name": indexer_name,
    "dataSourceName": datasource_name,
    "targetIndexName": index_name,
    "skillsetName": skillset_name,
    #"schedule" : { "interval" : "PT24H"}, # How often do you want to check for new content in the data source
    "fieldMappings": [
        {
          "sourceFieldName" : "metadata_spo_site_library_item_id",  #  metadata_spo_site_library_item_id , metadata_storage_path
          "targetFieldName" : "id",
          "mappingFunction" : { "name" : "base64Encode" }
        },
        {
          "sourceFieldName" : "metadata_title",
          "targetFieldName" : "title"
        },
        {
          "sourceFieldName" : "metadata_spo_item_name", #   metadata_storage_name , metadata_spo_item_name
          "targetFieldName" : "name"
        },
        {
          "sourceFieldName" : "metadata_spo_item_weburi", #   metadata_storage_path , metadata_spo_item_weburi
          "targetFieldName" : "locations"
        }
    ],
    "outputFieldMappings":
    [
      
        
    ],
    "parameters":
    {
        "maxFailedItems": -1,
        "maxFailedItemsPerBatch": -1,
        "configuration":
        {
            "dataToExtract": "contentAndMetadata",
            "indexedFileNameExtensions" : ".csv,.txt,.pdf,.docx,.pptx,.png,.jpg",
            "imageAction": "generateNormalizedImages",
            "executionEnvironment": "private"
        }
    }
}

r = requests.put(AZURE_SEARCH_ENDPOINT+ "/indexers/" + indexer_name,
                 data=json.dumps(indexer_payload), headers=headers, params=params)
print(r.status_code)
print(r.ok)
print(r.text)


# COMMAND ----------

# Optionally, get indexer status to confirm that it's running
r = requests.get(AZURE_SEARCH_ENDPOINT + "/indexers/" + indexer_name +
                 "/status", headers=headers, params=params)
# pprint(json.dumps(r.json(), indent=1))
print(r.status_code)
print("Status:",r.json().get('lastResult').get('status'))
print("Items Processed:",r.json().get('lastResult').get('itemsProcessed'))
print(r.ok)

# COMMAND ----------

index_payload = {
    "name": index_name + "-vector",
    "fields": [
        {"name": "id", "type": "Edm.String", "key": "true", "filterable": "true" },
        {"name": "title","type": "Edm.String","searchable": "true","retrievable": "true"},
        {"name": "chunk","type": "Edm.String","searchable": "true","retrievable": "true"},
        {"name": "chunkVector","type": "Collection(Edm.Single)","searchable": "true","retrievable": "true","dimensions": 1536,"vectorSearchConfiguration": "vectorConfig"},
        {"name": "name", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "location", "type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},

    ],
    "vectorSearch": {
        "algorithmConfigurations": [
            {
                "name": "vectorConfig",
                "kind": "hnsw"
            }
        ]
    },
    "semantic": {
        "configurations": [
            {
                "name": "my-semantic-config",
                "prioritizedFields": {
                    "titleField": {
                        "fieldName": "title"
                    },
                    "prioritizedContentFields": [
                        {
                            "fieldName": "chunk"
                        }
                    ],
                    "prioritizedKeywordsFields": []
                }
            }
        ]
    }
}

r = requests.put(AZURE_SEARCH_ENDPOINT + "/indexes/" + index_name + "-vector",
                 data=json.dumps(index_payload), headers=headers, params=params)
print(r.status_code)
print(r.ok)

# COMMAND ----------

