# Databricks notebook source
searchservice_url = "https://search-ai-platform-d-1.search.windows.net"
searchservice_apiKey = "11eBB7I8vxMxNnb2ChiG6LYrvXdY4uDqwYLKxKubCKAzSeBN1G1u"

datasource_name = "datasource-genai-procuree-qna"
skillset_name = "skillset-genai-procuree-qna"
index_name ="index-genai-procuree-qna"
indexer_name = "indexer-genai-procuree-qna"

# blob_connString = f"DefaultEndpointsProtocol=https;AccountName=staiplatformseus21;AccountKey=1LbBUZggT/GymhaTpHbjfKDC+89rm+Bvt/e55OHdz66oMe1dllyeedAFre3O5Pz0Q+GXMrWGLmVh+AStYQe8Iw==;EndpointSuffix=core.windows.net"

# DATASOURCE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=staiplatformseus21;AccountKey=1LbBUZggT/GymhaTpHbjfKDC+89rm+Bvt/e55OHdz66oMe1dllyeedAFre3O5Pz0Q+GXMrWGLmVh+AStYQe8Iw==;EndpointSuffix=core.windows.net"

# DATASOURCE_SAS_TOKEN = "?sv=2022-11-02&ss=bfqt&srt=sco&sp=rwlacupx&se=2023-10-09T15:45:50Z&st=2023-10-09T07:45:50Z&spr=https&sig=bIHmso6g5FrJNk8eX4YueCvpOcBsuMXpyJIFzNwD8gg%3D"

DATASOURCE_CONNECTION_STRING = "ResourceId=/subscriptions/a29c0d4f-2a26-414f-9dab-e9aa8479fa5c/resourceGroups/STP-Chatbot-d/providers/Microsoft.Storage/storageAccounts/ststpchatbotdncus1;"

BLOB_CONTAINER_NAME = "stpqnadump"  
print(BLOB_CONTAINER_NAME)

AZURE_SEARCH_ENDPOINT="https://search-ai-platform-d-1.search.windows.net"
AZURE_SEARCH_KEY="11eBB7I8vxMxNnb2ChiG6LYrvXdY4uDqwYLKxKubCKAzSeBN1G1u"
AZURE_SEARCH_API_VERSION="2023-10-01-Preview"

headers = {'Content-Type': 'application/json','api-key': AZURE_SEARCH_KEY}
params = {'api-version': AZURE_SEARCH_API_VERSION}

COG_SERVICES_NAME="cogai-platformdeus22"
COG_SERVICES_KEY="e5a5d0724a0a42dc843309be64019b1e"

OpenAI_Service_Key= "181c1dd05bbe474c9a5004b3bbcc39af"
OPENAI_SERVICE_NAME="https://cogai-platformdeaca3.openai.azure.com"

##################
print(searchservice_url)
url = f"{searchservice_url}/datasources?api-version=2020-06-30-Preview" 
print(url)

api_key = f'{searchservice_apiKey}'
print(api_key)

#credentials = f"{cosdb_connString}"
#print(credentials)

datasrc_name= f"{datasource_name}"
print(datasrc_name)
print(skillset_name)
ind_name= f"{index_name}"
print(ind_name)
indexer_name= f"{indexer_name}"
print(indexer_name)

print (headers)
print(params)

import os
import json
import requests
#from dotenv import load_dotenv
#load_dotenv("credentials.env")

# COMMAND ----------

import requests
import json
import os
datasource_payload = {
    "name": datasource_name,
    "description": "Demo files to demonstrate cognitive search capabilities of one-to-many.",
    "type": "azureblob",
    "credentials": {
        "connectionString": DATASOURCE_CONNECTION_STRING
    },
    "container": {
        "name": BLOB_CONTAINER_NAME
    }
}
r = requests.put(AZURE_SEARCH_ENDPOINT + "/datasources/" + datasource_name,
                 data=json.dumps(datasource_payload), headers=headers, params=params)
print(r.status_code)
print(r.ok)

# COMMAND ----------

# Create a skillset
skillset_payload = {
    "name": skillset_name,
    "description": "Splits Text and detect language",
    "skills":
    [
        {
            "@odata.type": "#Microsoft.Skills.Text.LanguageDetectionSkill",
            "description": "If you have multilingual content, adding a language code is useful for filtering",
            "context": "/document",
            "inputs": [
                {
                  "name": "text",
                  "source": "/document/Answer"
                }
            ],
            "outputs": [
                {
                  "name": "languageCode",
                  "targetName": "language"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.SplitSkill",
            "context": "/document",
            "textSplitMode": "pages",
            "maximumPageLength": 5000, # 5000 is default
            "defaultLanguageCode": "en",
            "inputs": [
                {
                    "name": "text",
                    "source": "/document/Answer"
                },
                {
                    "name": "languageCode",
                    "source": "/document/language"
                }
            ],
            "outputs": [
                {
                    "name": "textItems",
                    "targetName": "pages"
                }
            ]
        }
    ],
    "cognitiveServices": {
        "@odata.type": "#Microsoft.Azure.Search.CognitiveServicesByKey",
        "description": COG_SERVICES_NAME,
        "key": COG_SERVICES_KEY
    }
}

r = requests.put(AZURE_SEARCH_ENDPOINT + "/skillsets/" + skillset_name,
                 data=json.dumps(skillset_payload), headers=headers, params=params)
print(r.status_code)
print(r.ok)

# COMMAND ----------

index_payload = {
    "name": index_name,  
    "fields": [
        {"name": "id", "type": "Edm.String", "key": "true", "searchable": "false", "retrievable": "true", "facetable": "false", "filterable": "false", "sortable": "false"},
        {"name": "title", "type": "Edm.String", "searchable": "true", "retrievable": "true", "facetable": "false", "filterable": "true", "sortable": "false"},
        {"name": "content", "type": "Edm.String", "searchable": "true", "retrievable": "true", "facetable": "false", "filterable": "false", "sortable": "false"},
        {"name": "chunks","type": "Collection(Edm.String)", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "language", "type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "true", "filterable": "true", "facetable": "true"},
        {"name": "name", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "location", "type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "vectorized", "type": "Edm.Boolean", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "authors", "type": "Edm.String", "searchable": "true", "retrievable": "true", "facetable": "false", "filterable": "false", "sortable": "false"},
        {"name": "metadata_storage_name", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "metadata_storage_path", "type":"Edm.String", "searchable": "false", "retrievable": "true", "filterable": "false", "sortable": "false"},
        {"name": "metadata_storage_last_modified", "type":"Edm.DateTimeOffset", "searchable": "false", "retrievable": "false", "filterable": "false", "sortable": "false"}
        
    ],
    "semantic": {
        "configurations": [
            {
                "name": "my-semantic-config",
                "prioritizedFields": {
                    "titleField": 
                        {
                            "fieldName": "title"
                        },
                    "prioritizedContentFields": [
                        { 
                            "fieldName":"content" 
                        }
                    ]
                }
            }
        ]
    }
}

r = requests.put(AZURE_SEARCH_ENDPOINT + "/indexes/" + index_name,
                 data=json.dumps(index_payload), headers=headers, params=params)
print(r.status_code)
print(r.ok)
#print(r.text)

# COMMAND ----------

indexer_payload = {
    "name": indexer_name,
    "dataSourceName": datasource_name,
    "targetIndexName": index_name,
    "skillsetName": skillset_name,
    "schedule" : { "interval" : "PT2H"},
    "fieldMappings": [
        {
          "sourceFieldName" : "QnaId",
          "targetFieldName" : "id"
        },        
        {
          "sourceFieldName" : "Question",
          "targetFieldName" : "title"
        },
        {
          "sourceFieldName" : "Answer",
          "targetFieldName" : "content" 
        },        
        {
          "sourceFieldName" : "metadata_storage_path",
          "targetFieldName" : "location"
        },
        {
          "sourceFieldName" : "metadata_storage_name",
          "targetFieldName" : "name"
        }
    ],
    "outputFieldMappings":
    [
        {
            "sourceFieldName": "/document/language",
            "targetFieldName": "language"
        },
        {
            "sourceFieldName": "/document/pages/*",
            "targetFieldName": "chunks"
        }
    ],
    "parameters" : { 
        "configuration" : { 
            "dataToExtract": "contentAndMetadata",
            "parsingMode" : "delimitedText", 
            "firstLineContainsHeaders" : True,
            "delimitedTextDelimiter": ",",
            "executionEnvironment": "private"
        } 
    }
}
r = requests.put(AZURE_SEARCH_ENDPOINT + "/indexers/" + indexer_name,
                 data=json.dumps(indexer_payload), headers=headers, params=params)
print(r.status_code)
print(r.ok)

if r.status_code==200:
    print("Created Succesfully")
else :
    print(r.status_code)
    print(r.content.decode("utf-8"))

# COMMAND ----------

# Optionally, get indexer status to confirm that it's running
r = requests.get(AZURE_SEARCH_ENDPOINT + "/indexers/" + indexer_name +
                 "/status", headers=headers, params=params)
# pprint(json.dumps(r.json(), indent=1))
print(r.status_code)
print("Status:",r.json().get('lastResult').get('status'))
print("Items Processed:",r.json().get('lastResult').get('itemsProcessed'))
print(r.ok)

# COMMAND ----------

index_payload = {
    "name": index_name + "-vector",
    "fields": [
        {"name": "id", "type": "Edm.String", "key": "true", "filterable": "true" },
        {"name": "title","type": "Edm.String","searchable": "true","retrievable": "true"},
        {"name": "chunk","type": "Edm.String","searchable": "true","retrievable": "true"},
        {"name": "chunkVector","type": "Collection(Edm.Single)","searchable": "true","retrievable": "true","dimensions": 1536,"vectorSearchConfiguration": "vectorConfig"},
        {"name": "name", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "location", "type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},

    ],
    "vectorSearch": {
        "algorithmConfigurations": [
            {
                "name": "vectorConfig",
                "kind": "hnsw"
            }
        ]
    },
    "semantic": {
        "configurations": [
            {
                "name": "my-semantic-config",
                "prioritizedFields": {
                    "titleField": {
                        "fieldName": "title"
                    },
                    "prioritizedContentFields": [
                        {
                            "fieldName": "chunk"
                        }
                    ],
                    "prioritizedKeywordsFields": []
                }
            }
        ]
    }
}

r = requests.put(AZURE_SEARCH_ENDPOINT + "/indexes/" + index_name + "-vector",
                 data=json.dumps(index_payload), headers=headers, params=params)
print(r.status_code)
print(r.ok)
print(r.text)

# COMMAND ----------

