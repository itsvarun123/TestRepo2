# Databricks notebook source
# MAGIC %sql
# MAGIC create database GenaiqnaDB

# COMMAND ----------

# MAGIC %sql
# MAGIC Create table GenaiqnaDB.DimManufacturingLogs (
# MAGIC MANUFACTURING_Skey	BIGINT ,
# MAGIC id STRING ,
# MAGIC user_id STRING ,
# MAGIC message_type STRING,
# MAGIC message_content STRING,
# MAGIC manufacturing_timestamp TIMESTAMP,
# MAGIC CreatedDate   TIMESTAMP
# MAGIC ) 

# COMMAND ----------

# MAGIC %md # Snowflake DDL Scripts

# COMMAND ----------

# MAGIC %sql
# MAGIC -- snowflake Table Structure
# MAGIC create or replace TABLE DimManufacturingLogs (
# MAGIC 	Manufacturing_Skey VARCHAR(100),
# MAGIC 	Session_Id VARCHAR(400),
# MAGIC 	User_Id VARCHAR(400),
# MAGIC 	Message_Type VARCHAR(4000),
# MAGIC 	Message_Content TEXT,
# MAGIC 	Manufacturing_Timestamp TIMESTAMP_NTZ(9) NOT NULL ,	
# MAGIC     Created_Date TIMESTAMP_NTZ(9) NOT NULL
# MAGIC );
# MAGIC