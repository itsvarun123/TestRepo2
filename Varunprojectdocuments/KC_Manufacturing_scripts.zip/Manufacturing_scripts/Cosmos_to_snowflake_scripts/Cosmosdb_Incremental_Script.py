# Databricks notebook source
pip install azure-cosmos

# COMMAND ----------

from azure.cosmos import CosmosClient,exceptions
import pandas as pd 
import random
import datetime
cosmos_client=CosmosClient("https://cosdb-ai-platform-d-eus2-1.documents.azure.com:443/",{'masterKey':"DWkYzVkVPSJDlHjwcKUruVf6b8dBbqKC1rt1N7U6yLP9IaEVFpKDFNrSEI3trI775Op6M6MQTqNLACDbBOZiIQ==;"}) 

database_name="GenAIQnADB"
container_name="ManufacturingMsgLogsV1"

database = cosmos_client.get_database_client(database_name)
print("database : ",database)
container=database.get_container_client(container_name)
print("container name : ",container) 


# COMMAND ----------

cosmos_query2 = """ SELECT t1.id as Session_Id,t1.user_id as User_Id ,t1._ts,TimestampToDateTime(t1._ts*1000) as Manufacturing_Timestamp,m.type AS Message_Type,m.data.content AS Message_Content
 FROM ManufacturingMessageLogs t1 join m IN t1.messages """
cosmos_results = container.query_items(query=cosmos_query2, enable_cross_partition_query=True)
df1 = spark.createDataFrame(cosmos_results)
#df1.show()
df1.createOrReplaceTempView('stg_cosmosdb_data') 

# COMMAND ----------

key=spark.sql("""select nvl(max(Manufacturing_Skey),1000) as max_skey from GenaiqnaDB.DimManufacturingLogs""").first()['max_skey']

# COMMAND ----------

insert_df= spark.sql(f"""
                     
insert into GenaiqnaDB.DimManufacturingLogs
select  
{key} + monotonically_increasing_id() +1 Manufacturing_Skey ,
s1.Session_Id as Session_Id ,
s1.User_Id as User_Id ,
s1.Message_Type as Message_Type ,
s1.Message_Content as Message_Content ,
s1.Manufacturing_Timestamp as Manufacturing_Timestamp ,
current_timestamp() Created_Date
from stg_cosmosdb_data s1

left outer join GenaiqnaDB.DimManufacturingLogs m1  on 
(
    trim(s1.Session_Id)=m1.Session_Id and    
    trim(s1.User_Id)=m1.User_Id and
    trim(s1.Manufacturing_Timestamp)=m1.Manufacturing_Timestamp
)
where m1.Session_Id is NULL 

""")

display(insert_df)


# COMMAND ----------

# MAGIC %sql
# MAGIC select  
# MAGIC distinct
# MAGIC s1.Session_Id as s1_sesion_id,
# MAGIC m1.Session_Id as m1_session_id,
# MAGIC s1.User_Id,
# MAGIC s1.Message_Type,
# MAGIC s1.Message_Content,
# MAGIC s1.Manufacturing_Timestamp,
# MAGIC current_timestamp() Created_Date
# MAGIC from stg_cosmosdb_data s1
# MAGIC left outer join GenaiqnaDB.DimManufacturingLogs m1  on 
# MAGIC (
# MAGIC     trim(s1.Session_Id)=m1.Session_Id and    
# MAGIC     trim(s1.User_Id)=m1.User_Id and
# MAGIC     trim(s1.Manufacturing_Timestamp)=m1.Manufacturing_Timestamp
# MAGIC )
# MAGIC where m1.Session_Id is NULL  
# MAGIC

# COMMAND ----------

# MAGIC %md # Writing to Storage Account Container

# COMMAND ----------

output_df= spark.sql(f"""
                     select Manufacturing_Skey,Session_Id,User_Id,Message_Type,Message_Content,Manufacturing_Timestamp,
Created_Date from GenaiqnaDB.DimManufacturingLogs order by Manufacturing_Timestamp desc 
""")
#display(output_df)
output_df.write.csv(f'/mnt/sample/Output_CosmosManufacturingLogs.csv',sep='|', mode='overwrite',header=True )

# COMMAND ----------

# MAGIC %sql
# MAGIC -- truncate table GenaiqnaDB.DimManufacturingLogs  ;
# MAGIC select * from GenaiqnaDB.DimManufacturingLogs

# COMMAND ----------

dbutils.fs.mount(
  source = "wasbs://cosmos-output@staiplatformdeus21.blob.core.windows.net",
  mount_point = "/mnt/sample",
  extra_configs = {"fs.azure.account.key.staiplatformdeus21.blob.core.windows.net":"qUE2GlOs/UC4Kbm7MjlzQOuN+p3quxKAZau7MeeKSoi1vjwvX8jKGqxekWEDYM6cnz7KaxksODf4+ASt9uXBjA=="})

# COMMAND ----------

# MAGIC %md ##  Load to snowflake table

# COMMAND ----------

import snowflake.connector

# COMMAND ----------

import snowflake.connector
url = 'https://devkcc.east-us-2.azure.snowflakecomputing.com'
user = 'APP_AZURE_IRIS_D'
password = 'FiL1jNosElfOHQv7'
db = 'ADHOC_KCNA_IRIS'
schema = 'STAGING'
warehouse = 'ADHOC_KCNA_IRIS_WH'

sfOptions = {
    "sfURL": url,
    "sfUser":user,
    "sfPassword":password,
    "sfDatabase":db,
    "sfSchema":schema,
    "sfWarehouse":warehouse
}

account = 'devkcc.east-us-2.azure'
account = account.replace('https://','').replace('.snowflakecomputing.com/','')

con = snowflake.connector.connect(user=user,password=password,warehouse=warehouse,database=db,schema=schema,account=account)


# COMMAND ----------

snowflaketable_df=spark.sql("select * from GenaiqnaDB.DimManufacturingLogs")

# COMMAND ----------

snowflaketable_df.write.format("snowflake")\
        .options(**sfOptions)\
        .option("dbtable","DIMMANUFACTURINGLOGS")\
        .mode("Overwrite")\
        .save() 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from GenaiqnaDB.DimManufacturingLogs