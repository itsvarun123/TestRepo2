# Databricks notebook source
from azure.cosmos import CosmosClient,exceptions
import pandas as pd 
import random
import datetime
from datetime import datetime,timedelta 

cosmos_client=CosmosClient("https://cosdb-ai-platform-d-eus2-1.documents.azure.com:443/",{'masterKey':"DWkYzVkVPSJDlHjwcKUruVf6b8dBbqKC1rt1N7U6yLP9IaEVFpKDFNrSEI3trI775Op6M6MQTqNLACDbBOZiIQ==;"}) 

database_name="GenAIQnADB"
container_name="ManufacturingMessageLogs"

database = cosmos_client.get_database_client(database_name)
print("database : ",database)
container=database.get_container_client(container_name)
print("container name : ",container) 


# COMMAND ----------

max_date=spark.sql(""" select max(timestamp) as max_timestamp from cosmosdb_data """)
display(max_date)
min_date=spark.sql(""" select min(timestamp) as min_timestamp from cosmosdb_data """)
display(min_date) 
diff_days= spark.sql(""" select date_diff(max(timestamp),min(timestamp)) from cosmosdb_data """)
display(diff_days) 
current_date=datetime.utcnow()
print(current_date)
cuttoff_date=current_date-timedelta(days=77)
print(cuttoff_date)


# COMMAND ----------

# MAGIC %md ##  Delete Query using Current Date as max date in Cosmos table (Current_date -30 days)

# COMMAND ----------



#### Main Script ####

current_date=datetime.utcnow()
print(current_date)
cuttoff_date=current_date-timedelta(days=76)
print(cuttoff_date)

documents_to_delete=container.query_items(
    query=f"SELECT * from c where c._ts < {cuttoff_date.timestamp()}",
    enable_cross_partition_query=True
)
for document in documents_to_delete:
    container.delete_item(item=document['id'],partition_key=document['user_id'])

# COMMAND ----------

# MAGIC %md ##  Delete query using Maximum date in Cosmos table

# COMMAND ----------

max_ts_query="select TOP 1 c._ts from c order by c._ts DESC"
max_ts_result=container.query_items(query=max_ts_query,enable_cross_partition_query=True)
max_ts=next(max_ts_result,None)
if max_ts is not None:
    max_ts=max_ts['_ts']
else:
    max_ts=0

print(max_ts)
max_date=cutoff_date=datetime.utcfromtimestamp(max_ts)
print(max_date)
cutoff_date1=datetime.utcfromtimestamp(max_ts)-timedelta(days=40)
print(cutoff_date1)

documents_to_delete=container.query_items(
    query=f"SELECT * from c where c._ts < {cutoff_date1.timestamp()}",
    enable_cross_partition_query=True
)
for document in documents_to_delete:
    container.delete_item(item=document['id'],partition_key=document['user_id'])

# COMMAND ----------

# MAGIC %md ## Testing for above Deleting scripts

# COMMAND ----------

from azure.cosmos import CosmosClient,exceptions
import pandas as pd 
import random
import datetime
from datetime import datetime,timedelta 

cosmos_client=CosmosClient("https://cosdb-ai-platform-d-eus2-1.documents.azure.com:443/",{'masterKey':"DWkYzVkVPSJDlHjwcKUruVf6b8dBbqKC1rt1N7U6yLP9IaEVFpKDFNrSEI3trI775Op6M6MQTqNLACDbBOZiIQ==;"}) 

database_name="GenAIQnADB"
container_name="ManufacturingMessageLogs"

database = cosmos_client.get_database_client(database_name)
print("database : ",database)
container=database.get_container_client(container_name)
print("container name : ",container) 

cosmos_query2 = """ SELECT t1.id,t1.user_id,t1._ts,TimestampToDateTime(t1._ts*1000) as timestamp,m.type AS message_type,m.data.content AS message_content,t1.score,t1.comment as comment
 FROM ManufacturingMessageLogs t1 join m IN t1.messages """

cosmos_results = container.query_items(query=cosmos_query2, enable_cross_partition_query=True)
df1 = spark.createDataFrame(cosmos_results)
#df1.show()
df1.createOrReplaceTempView('cosmosdb_data') 

# COMMAND ----------

# MAGIC %md ##  Before Result of Deleting

# COMMAND ----------

# MAGIC %sql 
# MAGIC select min(timestamp) as min_timestamp, max(timestamp) as max_timestamp, date_diff(max(timestamp),min(timestamp)) as difference_time from cosmosdb_data 

# COMMAND ----------

# MAGIC %md ##  After Result of Deleting

# COMMAND ----------

# MAGIC %sql 
# MAGIC select min(timestamp) as min_timestamp, max(timestamp) as max_timestamp, date_diff(max(timestamp),min(timestamp)) as difference_time from cosmosdb_data 