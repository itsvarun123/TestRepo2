# Databricks notebook source
dbutils.fs.mount(
  source = "wasbs://cosmos-output@staiplatformdeus21.blob.core.windows.net",
  mount_point = "/mnt/",
  extra_configs = {"fs.azure.account.key.staiplatformdeus21.blob.core.windows.net":"qUE2GlOs/UC4Kbm7MjlzQOuN+p3quxKAZau7MeeKSoi1vjwvX8jKGqxekWEDYM6cnz7KaxksODf4+ASt9uXBjA=="})