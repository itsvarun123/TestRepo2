# Databricks notebook source
searchservice_url = "https://search-ai-platform-d-1.search.windows.net"
searchservice_apiKey = "11eBB7I8vxMxNnb2ChiG6LYrvXdY4uDqwYLKxKubCKAzSeBN1G1u"

datasource_name = "datasource-genai-cosmos-manufacturingt1"
skillset_name = "skillset-genai-cosmost1"
index_name ="index-genai-cosmos-manufacturingt1"
indexer_name = "indexer-genai-cosmos-manufacturingt1"

database="GenAIQnADB"
container="ManufacturingMessageLogs1"

cosdb_connString = f"AccountEndpoint=https://cosdb-ai-platform-d-eus2-1.documents.azure.com:443/;AccountKey=DWkYzVkVPSJDlHjwcKUruVf6b8dBbqKC1rt1N7U6yLP9IaEVFpKDFNrSEI3trI775Op6M6MQTqNLACDbBOZiIQ==;Database={database};"

AZURE_SEARCH_ENDPOINT="https://search-ai-platform-d-1.search.windows.net"
AZURE_SEARCH_KEY="11eBB7I8vxMxNnb2ChiG6LYrvXdY4uDqwYLKxKubCKAzSeBN1G1u"
AZURE_SEARCH_API_VERSION="2023-07-01-Preview"
headers = {'Content-Type': 'application/json','api-key': AZURE_SEARCH_KEY}
params = {'api-version': AZURE_SEARCH_API_VERSION}

COG_SERVICES_NAME="cogai-platformdeus22"
COG_SERVICES_KEY="e5a5d0724a0a42dc843309be64019b1e"


##################
print(database)
print(container)
print(searchservice_url)
url = f"{searchservice_url}/datasources?api-version=2020-06-30-Preview" 
print(url)

api_key = f'{searchservice_apiKey}'
print(api_key)

credentials = f"{cosdb_connString}"
print(credentials)

datasrc_name= f"{datasource_name}"
print(datasrc_name)
print(skillset_name)
ind_name= f"{index_name}"
print(ind_name)
indxr_name= f"{indexer_name}"
print(indxr_name)

print(database)
container_name=f"{container}"
print(container_name)


# COMMAND ----------

# MAGIC %md #For Deleting the Datasource,skillset,Indexer,Index

# COMMAND ----------

import requests

# Replace these placeholders with your actual values
searchservice_url = f"{searchservice_url}"
data_source_name=f"{datasource_name}"
skillset_name=f"{skillset_name}"
index_name=f"{index_name}"
indexer_name = f"{indexer_name}"
api_key = f'{searchservice_apiKey}'

headers = {
    'Content-Type': 'application/json',
    'api-key': f'{searchservice_apiKey}'
}

url_datasource = f"{searchservice_url}/datasources/{data_source_name}?api-version=2020-06-30-Preview" 
url_skillset = f"{searchservice_url}/skillsets/{skillset_name}?api-version=2020-06-30-Preview" 
url_index = f"{searchservice_url}/indexes/{index_name}?api-version=2020-06-30-Preview" 
url_indexer = f"{searchservice_url}/indexers/{indexer_name}?api-version=2020-06-30-Preview"

response_datasource = requests.delete(url_datasource, headers=headers)
response_skillset = requests.delete(url_skillset, headers=headers)
response_index = requests.delete(url_index, headers=headers)
response_indexer = requests.delete(url_indexer, headers=headers)

# if response.status_code == 202:
#     print(f"Indexer '{data_source_name}' Deleted Succesfully.")
# else:
#     print(f"Failed to delete indexer '{data_source_name}'. Status code: {response.status_code}, Error: {response.text}")