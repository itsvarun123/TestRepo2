# Databricks notebook source
pip install azure-cosmos

# COMMAND ----------

from azure.cosmos import CosmosClient,exceptions
import pandas as pd 
import random
import datetime
cosmos_client=CosmosClient("https://cosdb-ai-platform-d-eus2-1.documents.azure.com:443/",{'masterKey':"DWkYzVkVPSJDlHjwcKUruVf6b8dBbqKC1rt1N7U6yLP9IaEVFpKDFNrSEI3trI775Op6M6MQTqNLACDbBOZiIQ==;"}) 


# COMMAND ----------

# database_name="GenAIQnADB"
# container_name="ManufacturingMsgLogsV1"

database_name="ApiGenAIQnADB"
container_name="ProcureeMsgLogs"

database = cosmos_client.get_database_client(database_name)
print("database : ",database)
container=database.get_container_client(container_name)
print("container name : ",container) 

# COMMAND ----------

cosmos_query2 = """ SELECT t1.id,t1.session_id,t1.user_id,t1._ts,TimestampToDateTime(t1._ts*1000) as timestamp,m.type AS message_type,m.data.content AS message_content,t1.prevContextUsed,t1.newContext,t1.fromVectorIndex,t1.fromCache,t1.sessionType,t1.queryType FROM ProcureeMsgLogs t1 join m IN t1.messages where  t1._ts>=1707299351  order by t1._ts desc """

cosmos_results = container.query_items(query=cosmos_query2, enable_cross_partition_query=True)
df1 = spark.createDataFrame(cosmos_results)
#df1.show()
#df1.createOrReplaceTempView('cosmosdb_data') 

# COMMAND ----------

1710508140 , 1710508140 , 1707299351
SELECT t1.id,t1.session_id,t1.user_id,t1._ts,TimestampToDateTime(t1._ts*1000) as timestamp,m.type AS message_type,m.data.content AS message_content,t1.prevContextUsed,t1.newContext,t1.fromVectorIndex,t1.fromCache,t1.sessionType,t1.queryType FROM ProcureeMsgLogs t1 join m IN t1.messages where t1._ts>1707299351 order by t1._ts desc

# COMMAND ----------

# MAGIC %sql
# MAGIC -- select 1707299351 as Unix_timestamp,from_unixtime(1707299351) as readable_timestamp; 
# MAGIC select 1707299351 as Unix_timestamp,from_unixtime(1707299351) as readable_timestamp; 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from cosmosdb_data  order by _ts asc-- 13864 14008

# COMMAND ----------

CASE
    WHEN m.data.content LIKE '%References:%' THEN
      SUBSTRING(m.data.content, CHARINDEX('References:', m.data.content) + LEN('References: ') + 1, CHARINDEX('<sup>', m.data.content) - (CHARINDEX('References:', m.data.content) + LEN('References: ') + 1))
    ELSE 'No reference link found'
  END AS reference_links


# Agent-Test-Session832

cosmos_query2 = """ SELECT t1.id, m.data.content AS message_content ,CASE
    WHEN m.data.content LIKE '%References:%' THEN
      SUBSTRING(m.data.content, CHARINDEX('References:', m.data.content) + LEN('References: ') + 1, CHARINDEX('<sup>', m.data.content) - (CHARINDEX('References:', m.data.content) + LEN('References: ') + 1))
    ELSE 'No reference link found'
  END AS reference_links
 FROM ManufacturingMessageLogs t1 join m IN t1.messages """

 cosmos_query2 = """ SELECT t1.id,t1.user_id,t1._ts,TimestampToDateTime(t1._ts*1000) as timestamp,m.type AS message_type,m.data.content AS message_content,t1.score,t1.comment as comment
 FROM ManufacturingMessageLogs t1 join m IN t1.messages where  m.type ='ai' """

# COMMAND ----------

cosmos_query2 = """ SELECT t1.id,t1.user_id,t1._ts,TimestampToDateTime(t1._ts*1000) as timestamp,m.type AS message_type,m.data.content AS message_content,t1.score,t1.comment as comment
 FROM ManufacturingMessageLogs t1 join m IN t1.messages """

# cosmos_query2 = " SELECT t1.id,t1.user_id,t1.timestamp,m.type AS message_type,m.data.content AS message_content FROM Container1 t1 join m IN t1.messages where not IS_DEFINED(t1.timestamp)"
# cosmos_query2 = " SELECT t1.id,t1.user_id,t1._ts,TimestampToDateTime(t1._ts*1000) as timestamp,m.type AS message_type,m.data.content AS message_content FROM ManufacturingMessageLogs t1 join m IN t1.messages "

cosmos_results = container.query_items(query=cosmos_query2, enable_cross_partition_query=True)
df1 = spark.createDataFrame(cosmos_results)
#df1.show()
df1.createOrReplaceTempView('cosmosdb_data') 

# COMMAND ----------

cosmos_query2 = """SELECT distinct t1.id AS id, m.data.content AS content,t1.docs as chunks,t1.score as score,t1.coment as comment FROM ProcureeMsgLogs t1 join m IN t1.messages  """

# cosmos_query2 = " SELECT t1.id,t1.user_id,t1.timestamp,m.type AS message_type,m.data.content AS message_content FROM Container1 t1 join m IN t1.messages where not IS_DEFINED(t1.timestamp)"
# cosmos_query2 = " SELECT t1.id,t1.user_id,t1._ts,TimestampToDateTime(t1._ts*1000) as timestamp,m.type AS message_type,m.data.content AS message_content FROM ManufacturingMessageLogs t1 join m IN t1.messages "

cosmos_results = container.query_items(query=cosmos_query2, enable_cross_partition_query=True)
df1 = spark.createDataFrame(cosmos_results)
#df1.show()
df1.createOrReplaceTempView('cosmosdb_data') 

# COMMAND ----------

SELECT distinct t1.id AS id, m.data.content AS content,t1.docs as chunks,t1.score as score,t1.coment as comment FROM ProcureeMsgLogs t1 join m IN t1.messages

SELECT t1.id,t1.user_id,t1._ts,TimestampToDateTime(t1._ts*1000) as timestamp,m.type AS message_type,m.data.content AS message_content FROM ProcureeMsgLogs t1 join m IN t1.messages 

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from cosmosdb_data 
# MAGIC --order by timestamp desc
# MAGIC --where message_content like '%creping%' 

# COMMAND ----------

# MAGIC %sql
# MAGIC /* select id,user_id,_ts,timestamp,message_type,message_content from cosmosdb_data ; */
# MAGIC
# MAGIC -- select id,_ts,message_content,length(message_content),timestamp  from cosmosdb_data where id ='Agent-Test-Session832' order by timestamp desc ;
# MAGIC -- and t1.id in ('Agent-Test-Session832','Agent-Test-Session76') 
# MAGIC
# MAGIC select id,_ts,timestamp,message_content,  CASE
# MAGIC     WHEN message_content LIKE '%References:%' THEN
# MAGIC       TRIM(
# MAGIC         REGEXP_REPLACE(
# MAGIC           SPLIT_PART(message_content, 'References:', 2),
# MAGIC           '</sup>',
# MAGIC           ''
# MAGIC         )
# MAGIC       )
# MAGIC     ELSE 'No reference links found'
# MAGIC   END AS reference_links
# MAGIC   from cosmosdb_data 
# MAGIC   -- where id in ('Agent-Test-Session832','Agent-Test-Session76')
# MAGIC   order by timestamp desc;
# MAGIC
# MAGIC -- select id,_ts,message_content,length(message_content),timestamp from cosmosdb_data where message_content like '%CM OPP 11%' order by timestamp desc ;

# COMMAND ----------

# cosmos_query3 = " SELECT t1.id,t1.user_id,t1._ts,TimestampToDateTime(t1._ts*1000) as timestamp,m.type AS message_type,m.data.content AS message_content FROM ManufacturingMessageLogs t1 join m IN t1.messages where m.type ='ai'"

cosmos_query3 = " SELECT distinct t1.id AS id, m.data.content AS content FROM ManufacturingMessageLogs t1 join m IN t1.messages where m.type ='ai'"



# cosmos_query2 = " SELECT t1.id,t1.user_id,t1.timestamp,m.type AS message_type,m.data.content AS message_content FROM Container1 t1 join m IN t1.messages where not IS_DEFINED(t1.timestamp)"
# cosmos_query2 = " SELECT t1.id,t1.user_id,t1._ts,TimestampToDateTime(t1._ts*1000) as timestamp,m.type AS message_type,m.data.content AS message_content FROM ManufacturingMessageLogs t1 join m IN t1.messages "

cosmos_results = container.query_items(query=cosmos_query3, enable_cross_partition_query=True)
df1 = spark.createDataFrame(cosmos_results)
#df1.show()
df1.createOrReplaceTempView('cosmosdb_data1') 


# COMMAND ----------

# MAGIC %sql
# MAGIC /* select id,user_id,_ts,timestamp,message_type,message_content from cosmosdb_data ; */
# MAGIC
# MAGIC select * from cosmosdb_data1 ;

# COMMAND ----------

cosmos_query1 = " SELECT * FROM ManufacturingMessageLogs "
existing_documents= container.query_items(query=cosmos_query1, enable_cross_partition_query=True)
existing_document_ids = {doc["id"] for doc in existing_documents}
print(existing_document_ids)

# COMMAND ----------

# data_to_load=[{"id":"7", "name":"sachin"},
#               {"id":"8", "name":"Rahul"}
#              ]

data_to_load=[
                {
    "id": "Agent-Test-Session856",
    "user_id": "Agent-Test-User267",
	"timestamp":datetime.datetime.utcnow().isoformat(),
    "messages": [
        {
            "type": "human",
            "data": {
                "content": "What is crepping",
                "additional_kwargs": {}                
            }
        },
        {
            "type": "ai",
            "data": {
                "content": "Crepping refers to a process in tissue manufacturing where a doctor blade is used to remove the tissue paper from the Yankee dryer cylinder. The doctor blade is responsible for creating the desired texture and properties on the tissue paper surface.",
                "additional_kwargs": {}                
            }
        },
        {
            "type": "human",
            "data": {
                "content": "Can you explain again?",
                "additional_kwargs": {}                
            }
        },
        {
            "type": "ai",
            "data": {
                "content": "Crepping is a process in tissue manufacturing where a doctor blade is used to remove the tissue paper from the Yankee dryer cylinder. The doctor blade is responsible for creating the desired texture and properties on the tissue paper surface.",
                "additional_kwargs": {}
            }
        }
    ],
    "_rid": "BL0hAMug9GIBAAAAAAAAAA=="
    
}

             ]
for item in data_to_load:
    container.upsert_item(item)

# COMMAND ----------


cosmos_query2 = " SELECT * from c"
new_items= container.query_items(query=cosmos_query2, enable_cross_partition_query=True)

for item in new_items:
    timestamp=datetime.datetime.utcnow().isoformat()
    item["timestamp"]=timestamp
    container.upsert_item(item)


# COMMAND ----------

data_file_path = "dbfs/path/to/data.csv"
data_df = pd.read_csv(data_file_path)

data_to_load = data_df.to_dict(orient="records")

for item in data_to_load:
    container.upsert_item(item)


# COMMAND ----------

# query = " SELECT t1.id,t1.user_id,t1.timestamp,m.type AS message_type,m.data.content AS message_content FROM Container1 t1 join m IN t1.messages"
query = " SELECT * from c"
items=container.query_items(query, enable_cross_partition_query=True)
for item in items:
    print(item)

# COMMAND ----------

# MAGIC %md ##  Reading Cosmosdb Data from databricks

# COMMAND ----------

# from pyspark.sql import SparkSession
from pyspark.sql.functions import col
# spark = SparkSession.builder.appName("CosmosDBReadEx").getOrCreate()

cosmosdb_config = {
    "spark.cosmos.accountEndpoint": "https://cosdb-ai-platform-d-eus2-1.documents.azure.com:443/",
    "spark.cosmos.accountKey": "DWkYzVkVPSJDlHjwcKUruVf6b8dBbqKC1rt1N7U6yLP9IaEVFpKDFNrSEI3trI775Op6M6MQTqNLACDbBOZiIQ==;",
    "spark.cosmos.database": "TestDatabase1",
    "spark.cosmos.container": "TestContainer1"
}

# COMMAND ----------

df = spark.read.format("cosmos.oltp").options(**cosmosdb_config).load()

# COMMAND ----------

connectionConfig = {
  "Endpoint" : "https://cosdb-ai-platform-d-eus2-1.documents.azure.com:443/",
  "Masterkey" : "DWkYzVkVPSJDlHjwcKUruVf6b8dBbqKC1rt1N7U6yLP9IaEVFpKDFNrSEI3trI775Op6M6MQTqNLACDbBOZiIQ==;",
  "Database" : "TestDatabase1",
  "Collection": "TestContainer1",
  "query_custom" : "SELECT * FROM c"
}

# COMMAND ----------

df = spark.read.format("com.microsoft.azure.cosmosdb.spark").options(**connectionConfig).load()

#df.createOrReplaceTempView("temp_table")


# COMMAND ----------

pip install --upgrade azure-cosmosdb-spark

# COMMAND ----------

query = "select * from c"
items=container.query_items(query, enable_cross_partition_query=True)
for item in items:
    print(item)

# COMMAND ----------

from azure.cosmos import CosmosClient, exceptions
import pandas as pd 
import random
import datetime
cosmos_client=CosmosClient("https://cosdb-ai-platform-d-eus2-1.documents.azure.com:443/",{'masterKey':"DWkYzVkVPSJDlHjwcKUruVf6b8dBbqKC1rt1N7U6yLP9IaEVFpKDFNrSEI3trI775Op6M6MQTqNLACDbBOZiIQ==;"})

# database_name1="cosmicworks"
# container_name1="products"

# database1 = cosmos_client.get_database_client(database_name1)
# print("database : ",database1)
# container1=database1.get_container_client(container_name1)
# print("container name : ",container1) 

database_name="cosmicworks"
container_name="Container1"

database = cosmos_client.get_database_client(database_name)
print("database : ",database)
container=database.get_container_client(container_name)
print("container name : ",container) 

# COMMAND ----------

# Define the item id you want to delete
item_id_to_delete = "Agent-Test-Session310"
pid="Agent-Test-User567"

try:
    # Use Cosmos DB's delete_item method to delete the item
    container.delete_item(item=item_id_to_delete,partition_key=pid)
    print(f"Item with ID '{item_id_to_delete}'  deleted successfully.")
    
except exceptions.CosmosResourceNotFoundError:
    print(f"Item with ID '{item_id_to_delete}' PID not found '{pid}' not found.")
except Exception as e:
    print(f"An error occurred: {str(e)}")

# COMMAND ----------

cosmos_query2 = " SELECT t1.id,t1.user_id,t1._ts,TimestampToDateTime(t1._ts*1000) as timestamp,m.type AS message_type,m.data.content AS message_content FROM ManufacturingMessageLogs t1 join m IN t1.messages "

# cosmos_query2 = " SELECT t1.id,t1.user_id,t1.timestamp,m.type AS message_type,m.data.content AS message_content FROM Container1 t1 join m IN t1.messages where not IS_DEFINED(t1.timestamp)"
# cosmos_query2 = " SELECT t1.id,t1.user_id,t1._ts,TimestampToDateTime(t1._ts*1000) as timestamp,m.type AS message_type,m.data.content AS message_content FROM ManufacturingMessageLogs t1 join m IN t1.messages "

cosmos_results = container.query_items(query=cosmos_query2, enable_cross_partition_query=True)
df1 = spark.createDataFrame(cosmos_results)
#df1.show()
df1.createOrReplaceTempView('cosmosdb_data') 

# COMMAND ----------

# MAGIC %sql
# MAGIC /* select id,user_id,_ts,timestamp,message_type,message_content from cosmosdb_data ; */
# MAGIC
# MAGIC select id,user_id,_ts,message_content,timestamp  from cosmosdb_data where id ="Agent-Test-Session310" order by timestamp desc ;

# COMMAND ----------

from datetime import datetime, timedelta
ninety_days_ago = (datetime.now() - timedelta(days=90)).timestamp()
print (ninety_days_ago)



# COMMAND ----------

# MAGIC %sql
# MAGIC select 1689332923 as Unix_timestamp,from_unixtime(1689332923) as readable_timestamp; 