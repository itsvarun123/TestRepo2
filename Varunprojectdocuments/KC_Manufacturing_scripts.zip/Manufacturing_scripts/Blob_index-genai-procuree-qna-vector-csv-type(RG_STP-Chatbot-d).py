# Databricks notebook source
searchservice_url = "https://search-ai-platform-d-1.search.windows.net"
searchservice_apiKey = "11eBB7I8vxMxNnb2ChiG6LYrvXdY4uDqwYLKxKubCKAzSeBN1G1u"

datasource_name = "datasource-genai-procuree-qna-vector"
skillset_name = "skillset-genai-procuree-qna-vector"
index_name ="index-genai-procuree-qna-vector"
indexer_name = "indexer-genai-procuree-qna-vector"

# blob_connString = f"DefaultEndpointsProtocol=https;AccountName=ststpchatbotdncus1;AccountKey=V+aiQJL+eu0pZDJJniLSFP3YSLINjNd5VsLzMSMAW6PBmz2meIeyduZQ/GELHZN9y7T6/2PGqSLk+ASt8cieag==;EndpointSuffix=core.windows.net"

# DATASOURCE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=ststpchatbotdncus1;AccountKey=V+aiQJL+eu0pZDJJniLSFP3YSLINjNd5VsLzMSMAW6PBmz2meIeyduZQ/GELHZN9y7T6/2PGqSLk+ASt8cieag==;EndpointSuffix=core.windows.net"

DATASOURCE_CONNECTION_STRING = "ResourceId=/subscriptions/a29c0d4f-2a26-414f-9dab-e9aa8479fa5c/resourceGroups/STP-Chatbot-d/providers/Microsoft.Storage/storageAccounts/ststpchatbotdncus1;"

BLOB_CONTAINER_NAME = "stpqnadump"  
print(BLOB_CONTAINER_NAME)

AZURE_SEARCH_ENDPOINT="https://search-ai-platform-d-1.search.windows.net"
AZURE_SEARCH_KEY="11eBB7I8vxMxNnb2ChiG6LYrvXdY4uDqwYLKxKubCKAzSeBN1G1u"
AZURE_SEARCH_API_VERSION="2023-10-01-Preview"

headers = {'Content-Type': 'application/json','api-key': AZURE_SEARCH_KEY}
params = {'api-version': AZURE_SEARCH_API_VERSION}

COG_SERVICES_NAME="cogai-platformdeus22"
COG_SERVICES_KEY="e5a5d0724a0a42dc843309be64019b1e"

OpenAI_Service_Key= "181c1dd05bbe474c9a5004b3bbcc39af"
OPENAI_SERVICE_NAME="https://cogai-platformdeaca3.openai.azure.com"

##################
print(searchservice_url)
#url = f"{searchservice_url}/datasources?api-version=2020-06-30-Preview" 
url = f"{searchservice_url}/datasources?api-version=2023-07-01-Preview" 
print(url)

api_key = f'{searchservice_apiKey}'
print(api_key)

#credentials = f"{cosdb_connString}"
#print(credentials)

datasrc_name= f"{datasource_name}"
print(datasrc_name)
print(skillset_name)
ind_name= f"{index_name}"
print(ind_name)
indexer_name= f"{indexer_name}"
print(indexer_name)

print (headers)
print(params)

import os
import json
import requests


# COMMAND ----------

# The following code sends the json paylod to Azure Search engine to create the Datasource
import requests
import json
import os
datasource_payload = {
    "name": datasource_name,
    "description": "Demo files to demonstrate cognitive search capabilities.",
    "type": "azureblob",
    "credentials": {
        "connectionString": DATASOURCE_CONNECTION_STRING
    },
    # "dataDeletionDetectionPolicy" : {
    #     "@odata.type" :"#Microsoft.Azure.Search.NativeBlobSoftDeleteDeletionDetectionPolicy" #this makes sure that if the item is deleted from the source,it will be deleted
    # },
    "container": {
        "name": BLOB_CONTAINER_NAME
    }
}
r = requests.put(AZURE_SEARCH_ENDPOINT + "/datasources/" + datasource_name,
                 data=json.dumps(datasource_payload), headers=headers, params=params)
print(r.status_code)
print(r.ok)

# COMMAND ----------

# Create an index
# Queries operate over the searchable fields and filterable fields in the index
index_payload = {
    "name": index_name,
    "fields": [
        {"name": "id", "type": "Edm.String", "key": "true", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false","analyzer":"keyword"},
        {"name": "title", "type": "Edm.String", "searchable": "true", "retrievable": "true", "facetable": "false", "filterable": "true", "sortable": "false"},
        {"name": "content", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false","facetable": "false"},
        {"name": "chunk","type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "language", "type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "true", "filterable": "true", "facetable": "true"},
        {"name": "name", "type": "Edm.String", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "location", "type": "Edm.String", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "vectorized", "type": "Edm.Boolean", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "images_text", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},        
        {"name": "keyPhrases", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "true"},
        {"name": "persons", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "urls", "type": "Collection(Edm.String)", "searchable": "false", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false"},
        {"name": "emails", "type": "Collection(Edm.String)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "true", "facetable": "false"},
        {"name": "chunkVector", "type": "Collection(Edm.Single)", "searchable": "true", "retrievable": "true", "sortable": "false", "filterable": "false", "facetable": "false","dimensions":1536,"vectorSearchProfile":"myHnswProfile"},
        
    ],
    "semantic": {
      "configurations": [
        {
          "name": "my-semantic-config",
          "prioritizedFields": {
            "titleField": 
                {
                    "fieldName": "title"
                },
            "prioritizedContentFields": [
                {
                    "fieldName": "content"
                }
                ]
          }
        }
      ]
    },
  "vectorSearch": {
    "algorithms": [
      {
        "name": "myHnsw",
        "kind": "hnsw",
        "hnswParameters": {
          "metric": "cosine",
          "m": 4,
          "efConstruction": 400,
          "efSearch": 100
        },
        "exhaustiveKnnParameters": None
      },
      {
        "name": "myExhaustiveKnn",
        "kind": "exhaustiveKnn",
        "hnswParameters": None,
        "exhaustiveKnnParameters": {
          "metric": "cosine"
        }
      }
    ],
    "profiles": [
      {
        "name": "myHnswProfile",
        "algorithm": "myHnsw",
        "vectorizer": "myOpenAI"
      },
      {
        "name": "myExhaustiveKnnProfile",
        "algorithm": "myExhaustiveKnn",
        "vectorizer": "myOpenAI"
      }
    ],
    "vectorizers": [
      {
        "name": "myOpenAI",
        "kind": "azureOpenAI",
        "azureOpenAIParameters": {
          "resourceUri": OPENAI_SERVICE_NAME,
          "deploymentId": "text-embedding-ada-002",
          "apiKey": OpenAI_Service_Key,
          "authIdentity": None
        },
        "customWebApiParameters": None
      }
    ]
  }
}

r = requests.put(AZURE_SEARCH_ENDPOINT + "/indexes/" + index_name,
                 data=json.dumps(index_payload), headers=headers, params=params)
print(r.status_code)
# print(r.content)
print(r.ok)
#print(r.text)

# COMMAND ----------

# Edit the null value in the skillset payload
# Replcae "null" with None in the last few lines of code

# Create a skillset
skillset_payload = {
    "name": skillset_name,
    "description": "Extract entities, detect language and extract key-phrases",
    "skills":
    [
        
        
        {
            "@odata.type": "#Microsoft.Skills.Text.LanguageDetectionSkill",
            "context": "/document",
            "description": "If you have multilingual content, adding a language code is useful for filtering",
            "inputs": [
                {
                  "name": "text",
                  "source": "/document/Answer"
                }
            ],
            "outputs": [
                {
                  "name": "languageCode",
                  "targetName": "language"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.SplitSkill",
            "context": "/document",
            "textSplitMode": "pages",
            "maximumPageLength": 1000, # 5000 is default
            "pageOverlapLength": 200,
            "defaultLanguageCode": "en",
            "inputs": [
                {
                    "name": "text",
                    "source": "/document/Question"
                },
                {
                    "name": "languageCode",
                    "source": "/document/language"
                }
            ],
            "outputs": [
                {
                    "name": "textItems",
                    "targetName": "pages"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.KeyPhraseExtractionSkill",
            "context": "/document/pages/*",
            "maxKeyPhraseCount": 2,
            "defaultLanguageCode": "en",
            "inputs": [
                {
                    "name": "text", 
                    "source": "/document/pages/*"
                },
                {
                    "name": "languageCode",
                    "source": "/document/language"
                }
            ],
            "outputs": [
                {
                    "name": "keyPhrases",
                    "targetName": "keyPhrases"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.V3.EntityRecognitionSkill",
            "context": "/document/pages/*",
            "categories": ["Person", "URL", "Email"],
            "minimumPrecision": 0.5, 
            "defaultLanguageCode": "en",
            "inputs": [
                {
                    "name": "text", 
                    "source":"/document/pages/*"
                },
                {
                    "name": "languageCode",
                    "source": "/document/language"
                }
            ],
            "outputs": [
                {
                    "name": "persons", 
                    "targetName": "persons"
                },
                {
                    "name": "urls", 
                    "targetName": "urls"
                },
                {
                    "name": "emails", 
                    "targetName": "emails"
                }
            ]
        },
        {
            "@odata.type": "#Microsoft.Skills.Text.AzureOpenAIEmbeddingSkill",
            "name": "EmbeddingSkill",
            "description": "Skill to generate embeddings via Azure OpenAI",
            "context": "/document/pages/*",
            "resourceUri": OPENAI_SERVICE_NAME,
            "apiKey": OpenAI_Service_Key,
            "deploymentId": "text-embedding-ada-002",
            "inputs": [
                {
                    "name": "text",
                    "source": "/document/pages/*"
                }
            ],
                "outputs": [
                    {
                        "name": "embedding",
                        "targetName": "embedding"
                    }
                ],
            "authIdentity": None
        },
    
    ],
    "cognitiveServices": {
        "@odata.type": "#Microsoft.Azure.Search.CognitiveServicesByKey",
        "description": COG_SERVICES_NAME,
        "key": COG_SERVICES_KEY
    },

  "knowledgeStore": None,
  "indexProjections": {
    "selectors": [
      {
        "targetIndexName": index_name,
        "parentKeyFieldName": "title",
        "sourceContext": "/document/pages/*",
        "mappings": [
          {
            "name": "content",
            "source": "/document/Answer",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "title",
            "source": "/document/Question",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "chunkVector",
            "source": "/document/pages/*/embedding",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "chunk",
            #"source": "/document/pages/*",
            "source": "/document/Answer_Concat",
            "sourceContext": None,
            "inputs": []
          },
          
          {
            "name": "language",
            "source": "/document/language",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "keyPhrases",
            "source": "/document/pages/*/keyPhrases/*",
            "sourceContext": None,
            "inputs": []
          },{
            "name": "persons",
            "source": "/document/pages/*/persons/*",
            "sourceContext": None,
            "inputs": []
          },{
            "name": "urls",
            "source": "/document/pages/*/urls/*",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "emails",
            "source": "/document/pages/*/emails/*",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "name",
            "source": "/document/metadata_storage_name",
            "sourceContext": None,
            "inputs": []
          },
          {
            "name": "location",
            "source": "/document/metadata_storage_path",
            "sourceContext": None,
            "inputs": []
          },
        ]
      }
    ],
    "parameters": {
      "projectionMode": "skipIndexingParentDocuments"
    }
  },
  "encryptionKey": None
}

r = requests.put(AZURE_SEARCH_ENDPOINT + "/skillsets/" + skillset_name,
                 data=json.dumps(skillset_payload), headers=headers, params=params)
print(r.status_code)
# print(r.content)
print(r.ok) 
#print(r.text)


# COMMAND ----------

# Create an indexer
indexer_payload = {
    "name": indexer_name,
    "dataSourceName": datasource_name,
    "targetIndexName": index_name,
    "skillsetName": skillset_name,
    "schedule" : { "interval" : "PT24H"}, # How often do you want to check for new content in the data source
    "fieldMappings": [
        {
          "sourceFieldName" : "Id",
          "targetFieldName" : "id",
          "mappingFunction": {
            "name": "base64Encode"
            }
        },              
        {
          "sourceFieldName" : "Answer",
          "targetFieldName" : "content"
        },
        {
          "sourceFieldName" : "Answer_Concat",
          "targetFieldName" : "chunk"
        },
        {
          "sourceFieldName" : "Question",
          "targetFieldName" : "title" 
        },      
        {
          "sourceFieldName" : "metadata_storage_path",
          "targetFieldName" : "location"
        },
        {
          "sourceFieldName" : "metadata_storage_name",
          "targetFieldName" : "name"
        }
    ],
    "outputFieldMappings":
    [
       {
            "sourceFieldName": "/document/language",
            "targetFieldName": "language"
        },
        {
            "sourceFieldName": "/document/Answer",  #/document/pages/*
            "targetFieldName": "chunk"
        } 
    ],
    "parameters" : { 
        "configuration" : { 
            "dataToExtract": "contentAndMetadata",
            "parsingMode" : "delimitedText", 
            "firstLineContainsHeaders" : True,
            "delimitedTextDelimiter": "|",
            "executionEnvironment": "private"
        } 
    }
}

r = requests.put(AZURE_SEARCH_ENDPOINT+ "/indexers/" + indexer_name,
                 data=json.dumps(indexer_payload), headers=headers, params=params)
print(r.status_code)
print(r.ok)
print(r.text)

# COMMAND ----------

# Optionally, get indexer status to confirm that it's running
r = requests.get(AZURE_SEARCH_ENDPOINT + "/indexers/" + indexer_name +
                 "/status", headers=headers, params=params)
# pprint(json.dumps(r.json(), indent=1))
print(r.status_code)
# print(r.json())
print("Status:",r.json().get('lastResult').get('status'))
print("Items Processed:",r.json().get('lastResult').get('itemsProcessed'))
print(r.ok)