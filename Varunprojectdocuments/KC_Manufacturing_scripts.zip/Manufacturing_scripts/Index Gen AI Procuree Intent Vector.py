# Databricks notebook source
pip install openai==0.28.1 azure-search-documents==11.4.0b8 python-dotenv backoff python-docx openai[datalib] pandas azure-storage-blob

# COMMAND ----------

import os
import io
from dotenv import load_dotenv 
import docx,openai,backoff
import re,time
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from  azure.storage.blob  import  BlobClient
load_dotenv()

openai.api_type = "azure"
openai.api_base = "https://cogai-platformqeaca1.openai.azure.com/"
openai.api_version = "2023-07-01-preview"
openai.api_key = "7be43c7915db43ae86b7d66b2a532147"

search_endpoint = "https://search-ai-platform-q-1.search.windows.net"
search_key = AzureKeyCredential("JCsGhVp8ZjdybOoOK7Vvktdj1ZSCxoz6Ly1D151SiWAzSeAg2vQw")
index_name = "index-genai-procuree-intent-vector"
search_client = SearchClient(endpoint=search_endpoint,
                                    index_name=index_name,
                                    credential=search_key)

EMBEDDING_MODEL = "text-embedding-ada-002"

@backoff.on_exception(backoff.expo, openai.error.RateLimitError)

def get_embedding(text: str, model: str=EMBEDDING_MODEL) -> list[float]:

    result = openai.Embedding.create(

      engine=model,

      input=text

    )

    return result["data"][0]["embedding"]



def remove_from_index(filename,search_client:SearchClient):
    while True:
        filter = None if filename == None else f"type eq '{filename}'"
        r = search_client.search("", filter=filter, top=1000, include_total_count=True)
        if r.get_count() == 0:
            break
        r = search_client.delete_documents(documents=[{ "id": d["id"] } for d in r])
        print(f"\tRemoved {len(r)} sections from index")
        # It can take a few seconds for search results to reflect changes, so wait a bit
        time.sleep(2)


def read_docx(file_path):
    blob_client = BlobClient.from_blob_url(file_path)
    blob_data = blob_client.download_blob()
    blob_content = blob_data.readall()
    byte_stream = io.BytesIO(blob_content)
    doc = docx.Document(byte_stream)
    return doc
    
    
def extract_all_pages_text(file_path):
    doc = read_docx(file_path)
    page_wise_text = []

    current_page = 1
    page_text = ""


    for paragraph in doc.paragraphs:
        if paragraph._element.xpath(".//w:lastRenderedPageBreak"):
            page_wise_text.append(page_text)
            page_text = ""
            current_page += 1
        page_text += paragraph.text + " "

    # Append the last page
    page_wise_text.append(page_text)
    return page_wise_text

file_path = "https://staiplatformqeus21.blob.core.windows.net/intentcontainer/Procuree%20Intents.docx?sp=r&st=2023-11-23T11:39:37Z&se=2026-11-23T19:39:37Z&spr=https&sv=2022-11-02&sr=b&sig=UcR%2BVez5QP9LskfsV9S4yISFHcNt%2FERBmd713r8xFpI%3D"

page_wise_text = extract_all_pages_text(file_path)
remove_from_index(None,search_client=search_client)

batch = []
j = 0

for i,row in enumerate(page_wise_text):
    batch.append({
        "id": re.sub("[^0-9a-zA-Z_-]","_",f"{file_path}-{i}"),
        "content": row,
        "contentVector": get_embedding(row)
        
    })
    j += 1
    if j % 1000 == 0:
        results = search_client.upload_documents(documents=batch)
        succeeded = sum([1 for r in results if r.succeeded])
        print(f"\tIndexed {len(results)} sections, {succeeded} succeeded")
        batch = []

if len(batch) > 0:
        results = search_client.upload_documents(documents=batch)
        succeeded = sum([1 for r in results if r.succeeded])
        print(f"\tIndexed {len(results)} sections, {succeeded} succeeded")