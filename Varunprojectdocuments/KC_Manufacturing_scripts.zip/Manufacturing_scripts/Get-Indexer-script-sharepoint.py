# Databricks notebook source
import requests
import json
url = "https://search-ai-platform-d-1.search.windows.net/indexers/indexer-genai-sp-manufacturing-vector1/status?api-version=2023-10-01-Preview"
payload = ""
headers = {
  'Content-Type': 'application/json',
  'api-key': '11eBB7I8vxMxNnb2ChiG6LYrvXdY4uDqwYLKxKubCKAzSeBN1G1u'
}
response = requests.request("GET", url, headers=headers, data=payload)
print(response.text)

# COMMAND ----------

import requests
import json
url = "https://search-ai-platform-s-1.search.windows.net/indexers/indexer-genai-sp-manufacturing/status?api-version=2020-06-30-Preview"
payload = ""
headers = {
  'Content-Type': 'application/json',
  'api-key': 'fmSjKXDvyfjh0T2V0JiMBq26DvqsmCeqi7kjmXEtM2AzSeCivvUz'
}
response = requests.request("GET", url, headers=headers, data=payload)
print(response.text)